﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
using System.Runtime.Serialization;
using System.Text;

namespace Maconomy.Utility
{
    public class JsonSerializerFactory
    {
        private static JavaScriptSerializer _jsonSerializer = null;
        private static JavaScriptSerializer JSONSerializer
        {
            get
            {
                if (_jsonSerializer == null)
                {
                    _jsonSerializer = new JavaScriptSerializer();
                    _jsonSerializer.MaxJsonLength = 999999999;
                }
                return _jsonSerializer;
            }
        }

        /// <summary>
        /// Serialize object to JSON format
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string SerializeList<T>(List<T> obj)
        {
            return JSONSerializer.Serialize(obj);
        }

        public static string SerializeObject<T>(T obj)
        {
            return JSONSerializer.Serialize(obj);
        }

        /// <summary>
        /// Deserialize JSON format to Object
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="jsonString"></param>
        /// <returns></returns>
        public static T DeserializeJson<T>(string jsonString)
        {
            return JSONSerializer.Deserialize<T>(jsonString);
        }

        /// <summary>
        /// Deserialize json parameters to dictionary
        /// </summary>
        /// <param name="jsonParameter"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetParameterAsDictionary(string jsonParameter)
        {
            return DeserializeJson<Dictionary<string, string>>(jsonParameter);
        }
    }
}
