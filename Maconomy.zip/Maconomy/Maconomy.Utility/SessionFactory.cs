﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;


namespace Maconomy.Utility
{
    [Serializable]
    public class SessionFactory
    {
             

        //Set Session as null
        public void SetSessionAsNull(string sessionId)
        {
            HttpContext.Current.Session[sessionId] = null;
        }

       
    

        /// <summary>
        /// Get session object by passing http context used for task based method.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="context"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public T GetSessionByContext<T>(HttpContext context, string key)
        {
            var obj = context.Session[key];
            if (obj == null)
            {
                obj = default(T);
            }
            return (T)obj;
        }

        /// <summary>
        /// Set session object by passing http context used for task based method.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="context"></param>
        /// <param name="key"></param>
        /// <param name="obj"></param>
        public void SetSessionByContext<T>(HttpContext context, string key, T obj)
        {
            context.Session[key] = obj;
        }


        // Get or Set Foam tree sequence ids list
      

        public bool IsBackPageNavigationClicked { get; set; }
        public bool IsPageNavigationSessionCleared { get; set; }

        public bool RememberSearchFoamTree { get; set; }
        public bool RememberSelectionOnNavigation { get; set; }

        // TODO - refactor in to service parameters.
        public int ActivityReportReleaseId { get; set; }
        public string ActivityReportFilter { get; set; }
        public string ActivityReportSearchText { get; set; }

        // TODO - refactor in to service parameters.
        public int MyReleaseFolderId { get; set; }
        public string MyReleaseSearchText { get; set; }
        public int MyReleaseFilterById { get; set; }


     
    }
}
