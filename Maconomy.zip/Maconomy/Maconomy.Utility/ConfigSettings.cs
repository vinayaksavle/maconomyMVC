﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using Maconomy.BusinessEntities.Constants;

namespace Maconomy.Utility
{
    public class ConfigSettings
    {
        

        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings[AppSettingsKey.MaconomyConnectionString] != null ? ConfigurationManager.ConnectionStrings[AppSettingsKey.MaconomyConnectionString].ConnectionString : string.Empty;
            }
        }


        public static int SqlCommandTimeout
        {
            get
            {
                return ConfigurationManager.AppSettings[AppSettingsKey.SqlCommandTimeout].ToInt32();
            }
        }


    }
}
