using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Threading.Tasks;
using System.Web.UI;
using System.Reflection;
using System.ComponentModel;
using System.Web;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;

namespace Maconomy.Utility
{
    public static class ExtensionMethods
    {
        public static KeyValuePair<K, V> CreateKeyValuePair<K, V>(K key, V value)
        {
            return new KeyValuePair<K, V>(key, value);
        }

        /// <summary>
        /// Convert To empty String IF NULL
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToStringEmpty(this object value)
        {
            return value == null ? string.Empty : Convert.ToString(value);
        }

        /// <summary>
        /// Convert string to Int32
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int ToInt32(this object value)
        {
            int i;
            int.TryParse(value == null ? string.Empty : value.ToString(), out i);
            return i;
        }

        /// <summary>
        /// Convert string to Int64
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static Int64 ToInt64(this object value)
        {
            Int64 i;
            Int64.TryParse(value == null ? string.Empty : value.ToString(), out i);
            return i;
        }

        /// <summary>
        /// Convert string to DateTime
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static DateTime ToDateTime(this object value)
        {
            DateTime dt;
            DateTime.TryParse(value == null ? string.Empty : value.ToString(), out dt);
            return dt;
        }

        /// <summary>
        /// Convert bit value 1 or 0 to boolean
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool ToBoolean(this object value)
        {
            bool returnResult = false;
            try
            {
                if (value.ToString() == "1" || value.ToString().ToLower() == "true")
                {
                    returnResult = true;
                }
                else
                {
                    returnResult = false;
                }
            }
            catch
            {
                returnResult = false;
            }
            return returnResult;
        }


        /// <summary>
        /// Get Id's seperated by comma for searching contact.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="splitCharacter"></param>
        /// <param name="splitByCategoryLevel"></param>
        /// <returns></returns>
        public static string ToCommaSeperatedIds(this string value, char splitCharacter, string splitByCategoryLevel)
        {
            string returnValue = string.Empty;
            if (!string.IsNullOrEmpty(value))
            {
                string[] splitCategories = value.Split(splitCharacter);
                foreach (string category in splitCategories)
                {
                    if (category.Contains(splitByCategoryLevel))
                    {
                        returnValue = category.Split('_')[1];
                        break;
                    }
                }
            }
            return returnValue;
        }

        /// <summary>
        /// Returns a list of ints from a comma seperated string.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="splitCharacter"></param>
        /// <returns></returns>
        public static string ListToString<T>(this IEnumerable<T> list, string separator = ",", bool terminate = false)
        {
            var returnValues = string.Empty;
            foreach (T item in list)
            {
                if (returnValues != string.Empty) returnValues += separator;
                returnValues += item;
            }
            if (terminate && returnValues != string.Empty) returnValues += separator;
            return returnValues;
        }

        /// <summary>
        /// Returns a list of ints from a comma seperated string.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="splitCharacter"></param>
        /// <returns></returns>
        public static List<T> StringToList<T>(this string value, string splitCharacters = ",") where T : struct
        {
            var returnValues = new List<T>();
            if (string.IsNullOrWhiteSpace(value)) return null;
            string[] splitIds = value.Split(splitCharacters.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            T id = default(T);
            foreach (string idStr in splitIds)
            {
                if (idStr.TryParse<T>(out id) && !returnValues.Contains(id))
                    returnValues.Add(id);
            }
            return returnValues;
        }

        /// <summary>
        /// Generic TryParse
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="text"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static bool TryParse<T>(this string text, out T result) where T : struct
        {
            if (typeof(T).IsEnum) return Enum.TryParse<T>(text, out result);

            var tryParse = typeof(T).GetMethod(
            "TryParse", new[] { typeof(string), typeof(T).MakeByRefType() });
            if (tryParse == null)
                throw new InvalidOperationException();

            result = default(T);
            var parameters = new object[] { text, result };
            var success = tryParse.Invoke(null, parameters);
            if ((bool)success)
            {
                result = (T)parameters[1];
                return true;
            }
            return false;
        }

      
        /// <summary>
        /// check if column name exist in the reader to avoid exception
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static bool HasColumn(this SqlDataReader reader, string fieldName)
        {
            return reader.GetSchemaTable().Rows.Cast<DataRow>().Select(row => row["ColumnName"].ToString()).ToList().Contains(fieldName);
        }

        /// <summary>
        /// Check column name in dataTable
        /// </summary>
        /// <param name="data"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public static bool HasColumn(this DataTable data, string columnName)
        {
            if (data == null || string.IsNullOrEmpty(columnName))
            {
                return false;
            }

            foreach (DataColumn column in data.Columns)
            {
                if (columnName.Equals(column.ColumnName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="record"></param>
        /// <param name="pageSize"></param>
        /// <param name="pageNo"></param>
        /// <returns></returns>
        public static IEnumerable<IDataRecord> TakeRecordByPaging(this IEnumerable<IDataRecord> record, int pageSize, int pageNo)
        {
            return record.Skip((pageNo - 1) * pageSize).Take(pageSize);
        }

        /// <summary>
        /// Log Task Exception
        /// </summary>
        /// <param name="task"></param>
        public static Task<T> HandleTaskExceptions<T>(this Task<T> task, HttpContext context = null)
        {
            return task.ContinueWith<T>((antecedent) =>
            {
                bool isError = false;
                if (antecedent.Exception != null)
                {
                    var aggException = antecedent.Exception.Flatten();
                    foreach (var exception in aggException.InnerExceptions)
                    {
                        isError = true;
                    }
                }
                if (isError)
                {
                    return default(T);
                }
                else
                {
                    return antecedent.Result;
                }
            });
        }


        /// <summary>
        /// Register javascript once page load completed
        /// </summary>
        /// <param name="page"></param>
        /// <param name="key"></param>
        /// <param name="script"></param>
        /// <param name="addScriptTag"></param>
        public static void RegisterJavascript(this Page page, Type type, string key, string script, bool addScriptTag)
        {
            ScriptManager.RegisterStartupScript(page, type, key, script, addScriptTag);
        }

        /// <summary>
        /// Set text to bold for upper case scenario
        /// </summary>
        /// <param name="text"></param>
        /// <param name="splitChar"></param>
        /// <returns></returns>
        public static string ToBold(this string text, string[] splitChar)
        {
            string textOriginal = text;
            string[] splitTextByLineBreak = text.Split(splitChar, StringSplitOptions.None);

            foreach (string str in splitTextByLineBreak)
            {
                string[] splitString = str.Split(' ');
                bool isAllCaps = false;
                foreach (string capsText in splitString)
                {
                    if (!string.IsNullOrEmpty(capsText) && capsText.All(c => char.IsLetter(c) ? char.IsUpper(c) : true))
                    {
                        isAllCaps = true;
                    }
                    else
                    {
                        isAllCaps = false;
                        break;
                    }
                }

                if (isAllCaps)
                {
                    string boldText = "<font style='font-weight:bold'>" + str + "</font>";
                    textOriginal = textOriginal.Replace(str, boldText);
                }

            }
            return textOriginal;
        }

        /// <summary>
        /// Convert to any generic list to data Table
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            DataTable table = new DataTable();

            //special handling for value types and string
            if (typeof(T).IsValueType || typeof(T).Equals(typeof(string)))
            {

                DataColumn dc = new DataColumn("Ids");
                table.Columns.Add(dc);
                foreach (T item in data)
                {
                    DataRow dr = table.NewRow();
                    dr[0] = item;
                    table.Rows.Add(dr);
                }
            }
            else
            {
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
                foreach (PropertyDescriptor prop in properties)
                {
                    table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
                }
                foreach (T item in data)
                {
                    DataRow row = table.NewRow();
                    foreach (PropertyDescriptor prop in properties)
                    {
                        try
                        {
                            row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                        }
                        catch
                        {
                            row[prop.Name] = DBNull.Value;
                        }
                    }
                    table.Rows.Add(row);
                }
            }
            return table;
        }

        /// <summary>
        /// Get decription value a string for the enum type selected
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToDescriptionFromEnum<T>(this T value)
        {
            var description = (DescriptionAttribute[])(value.GetType().GetField(value.ToString())).GetCustomAttributes(typeof(DescriptionAttribute), false);
            return description.Length > 0 ? description[0].Description : value.ToString();
        }

        /// <summary>
        /// Get enum from its description
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static T ToEnumFromDescription<T>(this string value)
        {
            var type = typeof(T);
            if (!type.IsEnum) throw new InvalidOperationException();
            foreach (var field in type.GetFields())
            {
                var attribute = Attribute.GetCustomAttribute(field,
                    typeof(DescriptionAttribute)) as DescriptionAttribute;
                if (attribute != null)
                {
                    if (attribute.Description == value)
                        return (T)field.GetValue(null);
                }
                else
                {
                    if (field.Name == value)
                        return (T)field.GetValue(null);
                }
            }
            throw new ArgumentException("Not found.", "description");
        }

        /// <summary>
        /// Get Enum type from the string selected.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        [DebuggerStepThrough]
        public static T TryParseEnum<T>(this string value)
        {
            try
            {
                return (T)Enum.Parse(typeof(T), value, true);
            }
            catch
            {
                return default(T);
            }
        }


        /// <summary>
        /// Trims leading and trailing spaces from multi line text.
        /// </summary>
        /// <param name="multiLineText"></param>
        /// <returns></returns>
        public static string TrimMultiLine(this string multiLineText)
        {
            return Regex.Replace(multiLineText, @"(^\s+|\s+$)", "", RegexOptions.Multiline);
        }


        /// <summary>
        /// Separates 1000s by comma.
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public static string ToCommaFormat(this long num)
        {
            return string.Format("{0:n0}", num);
        }


        /// <summary>
        /// Splits text in to words.
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static List<string> GetWords(this string text)
        {
            if (text == null)
            {
                throw new ArgumentNullException("text");
            }

            Regex extractWords = new Regex("(?<word>\\w+)", RegexOptions.Singleline);
            MatchCollection matches = extractWords.Matches(text);

            List<string> words = new List<string>((text.Length / 5) + 1);

            foreach (Match match in matches)
            {
                string oneWord = match.Result("${word}");
                words.Add(oneWord);
            }
            return words;
        }


        /// <summary>
        /// Uses html markup to highlight matching term.
        /// </summary>
        /// <param name="str"></param>
        /// <param name="term"></param>
        /// <returns></returns>
        public static string HighlightTerm(this string str, string term, string css = "term-hit")
        {
            string highlighted = str;
            if (!string.IsNullOrEmpty(term))
            {
                string cssClass = string.Empty;

                if (!string.IsNullOrEmpty(css))
                {
                    cssClass = string.Format(" class=\"{0}\"", css);
                }

                highlighted = Regex.Replace(str, string.Format("{0}", term.Trim()), string.Format("<span{0}>$0</span>", cssClass), RegexOptions.IgnoreCase);

            }
            return highlighted;
        }


        /// <summary>
        /// Uses html markup to highlight matching terms.
        /// </summary>
        /// <param name="str"></param>
        /// <param name="terms"></param>
        /// <param name="css"></param>
        /// <returns></returns>
        public static string HighlightTerms(this string str, IEnumerable<string> terms, string css = "term-hit")
        {
            string highlighted = str;

            string cssClass = string.Empty;

            if (!string.IsNullOrEmpty(css))
            {
                cssClass = string.Format(" class=\"{0}\"", css);
            }

            if (terms.Count() > 0)
            {
                highlighted = Regex.Replace(str, string.Format("({0})", string.Join("|", terms)), string.Format("<span{0}>$0</span>", cssClass), RegexOptions.IgnoreCase);
            }

            return highlighted;
        }


        /// <summary>
        /// Uses html markup to highlight matching terms present within html tags. Tags are not affected.
        /// </summary>
        /// <param name="html"></param>
        /// <param name="terms"></param>
        /// <param name="css"></param>
        /// <returns></returns>
        public static string HighlightTermsInHtml(this string html, IEnumerable<string> terms, string css = "term-hit")
        {
            StringBuilder result = new StringBuilder();

            if (string.IsNullOrEmpty(html))
            {
                // do nothing.
            }
            else if (terms == null || terms.Count() == 0)
            {
                result.Append(html);
            }
            else
            {
                string cssClass = string.Empty;

                if (!string.IsNullOrEmpty(css))
                {
                    cssClass = string.Format(" class=\"{0}\"", css);
                }

                char[] htmlChar = html.ToArray();
                bool inTag = false;
                int start = 0;
                int len = 0;

                for (int i = 0; i < htmlChar.Length; i++)
                {
                    if (htmlChar[i] == '<')
                    {
                        inTag = true;

                        result.Append(HighlightTerms(html.Substring(start, len), terms, css));
                        result.Append(htmlChar[i]);

                        start = 0;
                        len = 0;

                        continue;
                    }
                    else if (inTag && htmlChar[i] == '>')
                    {
                        inTag = false;

                        result.Append(htmlChar[i]);
                        start = i + 1;
                        len = 0;

                        continue;
                    }
                    else if (inTag)
                    {
                        result.Append(htmlChar[i]);
                        continue;
                    }
                    else
                    {
                        len++;
                    }
                }
                result.Append(HighlightTerms(html.Substring(start, len), terms, css));
            }
            return result.ToString();
        }

        public static string HighlightTermsInHtml(this string str, IEnumerable<string> terms, char separator, string css = "term-hit")
        {
            var arr = str.Split(separator);

            StringBuilder highlighted = new StringBuilder();

            for (int i = 0; i < arr.Length; i++)
            {
                if (i > 0)
                {
                    highlighted.Append(" " + separator + " ");
                }
                highlighted.Append(HighlightTermsInHtml(arr[i], terms, css));
            }

            return highlighted.ToString();
        }

        /// <summary>
        /// Strips xml/html tags from string.
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string StripTags(this string str)
        {
            return Regex.Replace(str, "<[^>]*>", " ", RegexOptions.Singleline);
        }

        public static SqlParameter Find(this SqlParameter[] list, string parameterName)
        {
            if (!parameterName.StartsWith("@")) parameterName = "@" + parameterName;

            for (int i = 0; i < list.Length; i++)
                if (list[i].ParameterName == parameterName) return list[i];

            return null;
        }

        /// <summary>
        /// Get property name as string 
        /// </summary>
        public static string GetNameAsString<T>(this string name)
        {
            PropertyInfo property = typeof(T).GetProperty(name);
            if (property == null)
            {
                return string.Empty;
            }
            return property.Name;
        }

      
        //Recusrively finds all controls of a specific type
        public static IEnumerable<T> GetControlsOfType<T>(this Control root) where T : Control
        {
            var t = root as T;
            if (t != null)
                yield return t;

            if (root != null)
                foreach (Control c in root.Controls)
                    foreach (var i in GetControlsOfType<T>(c))
                        yield return i;
        }

        /// <summary>
        /// Extension method to get dictionary value by its key.
        /// </summary>
        public static TValue TryGetValue<TKey, TValue>(this Dictionary<TKey, TValue> dict, TKey val)
        {
            if (dict == null)
            {
                throw new ArgumentNullException();
            }
            TValue value = default(TValue);
            dict.TryGetValue(val, out value);
            return value;
        }


        /// <summary>
        /// Merge Two list into one.
        /// var a = new List<int>{1,2,3"};
        /// var b = new List<int>{4,10,6};
        /// var c = a.Merge(b, (x,y) => x+y).ToList();
        /// </summary>
        public static IEnumerable<T> Merge<T>(this IEnumerable<T> first, IEnumerable<T> second, Func<T, T, T> operation)
        {
            using (var iterator1 = first.GetEnumerator())
            using (var iterator2 = second.GetEnumerator())
            {
                while (iterator1.MoveNext())
                {
                    if (iterator2.MoveNext())
                    {
                        yield return operation(iterator1.Current, iterator2.Current);
                    }
                    else
                    {
                        yield return iterator1.Current;
                    }
                }
                while (iterator2.MoveNext())
                {
                    yield return iterator2.Current;
                }
            }
        }

        /// <summary>
        /// Returns all distinct elements of the given source, where "distinctness"
        /// is determined via a projection and the default eqaulity comparer for the projected type.
        /// </summary>
        /// <remarks>
        /// This operator uses deferred execution and streams the results, although
        /// a set of already-seen keys is retained. If a key is seen multiple times,
        /// only the first element with that key is returned.
        /// </remarks>
        /// <typeparam name="TSource">Type of the source sequence</typeparam>
        /// <typeparam name="TKey">Type of the projected element</typeparam>
        /// <param name="source">Source sequence</param>
        /// <param name="keySelector">Projection for determining "distinctness"</param>
        /// <returns>A sequence consisting of distinct elements from the source sequence,
        /// comparing them by the specified key projection.</returns>

        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            return source.DistinctBy(keySelector, null);
        }

        ///<summary>
        /// return distinct list by key selector field.
        ///</summary>
        /// <typeparam name="TSource">Type of the source sequence</typeparam>
        /// <typeparam name="TKey">Type of the projected element</typeparam>
        /// <param name="source">Source sequence</param>
        /// <param name="keySelector">Projection for determining "distinctness"</param>
        /// <param name="comparer">The equality comparer to use to determine whether or not keys are equal.
        /// If null, the default equality comparer for <c>TSource</c> is used.</param>
        /// <returns>A sequence consisting of distinct elements from the source sequence,
        /// comparing them by the specified key projection.</returns>

        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector, IEqualityComparer<TKey> comparer)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (keySelector == null) throw new ArgumentNullException("keySelector");
            return DistinctByImpl(source, keySelector, comparer);
        }

        /// <summary>
        /// Private method for internal purpose only.
        /// </summary>
        private static IEnumerable<TSource> DistinctByImpl<TSource, TKey>(IEnumerable<TSource> source, Func<TSource, TKey> keySelector, IEqualityComparer<TKey> comparer)
        {
            var knownKeys = new HashSet<TKey>(comparer);
            foreach (var element in source)
            {
                if (knownKeys.Add(keySelector(element)))
                {
                    yield return element;
                }
            }
        }

        /// <summary>
        /// Returns comma seperated string value from selected column within IEnumerable list 
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string ToCommaSeperated<TSource>(this IEnumerable<TSource> source)
        {
            return string.Join(",", source.ToList());
        }

        /// <summary>
        /// Check if email string is valid or not.
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        static bool invalid = false;
        public static string TryGetValidEmail(this string email)
        {
            string validEmail = string.Empty;
            invalid = false;
            if (String.IsNullOrEmpty(email))
                return validEmail;

            // Use IdnMapping class to convert Unicode domain names. 
            try
            {
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None);
            }
            catch
            {
                return validEmail;
            }

            if (invalid)
                return validEmail;

            // Return true if strIn is in valid e-mail format. 
            try
            {
                var isMatch = Regex.IsMatch(email,
                                    @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                                    @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$",
                                    RegexOptions.IgnoreCase);
                if (isMatch)
                {
                    validEmail = email;
                }
                else
                {
                    validEmail = string.Empty;
                }
            }
            catch
            {
                validEmail = string.Empty;
            }
            return validEmail;
        }

        /// <summary>
        /// Check for valid domain
        /// </summary>
        /// <param name="match"></param>
        /// <returns></returns>
        private static string DomainMapper(Match match)
        {
            // IdnMapping class with default property values.
            IdnMapping idn = new IdnMapping();

            string domainName = match.Groups[2].Value;
            try
            {
                domainName = idn.GetAscii(domainName);
            }
            catch (ArgumentException)
            {
                invalid = true;
            }
            return match.Groups[1].Value + domainName;
        }

        /// <summary>
        /// Generic method to get any parent control
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target"></param>
        /// <returns></returns>
        public static T FindParent<T>(this Control target) where T : Control
        {
            if (target.Parent == null)
            {
                return null;
            }

            var parent = target.Parent as T;
            if (parent != null)
            {
                return parent;
            }

            return target.Parent.FindParent<T>();
        }

        /// <summary>
        /// Extension method to Format strings rather than calling string.Format("",""). 
        /// </summary>
        // Enable quick and more natural string.Format calls
        public static string FormatWith(this string s, params object[] args)
        {
            return string.Format(s, args);
        }

        /// <summary>
        /// Check if Twitter handle is valid
        /// </summary>
        /// <param name="twitterHandle"></param>
        /// <returns></returns>
        public static bool TryGetValidTwitterHandle(this string twitterHandle)
        {
            string[] charToRemove = new string[] { "@", "#" };
            try
            {
                foreach (var item in charToRemove)
                {
                    twitterHandle = twitterHandle.Replace(item, string.Empty);
                }
                string url = "http://twitter.com/" + twitterHandle;
                var httpRequest = (HttpWebRequest)WebRequest.Create(url);
                httpRequest.Method = "HEAD";
                httpRequest.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
                var response = Task.Factory.FromAsync<WebResponse>(httpRequest.BeginGetResponse, httpRequest.EndGetResponse, httpRequest);
                response.Wait();
                return ((HttpWebResponse)response.Result).StatusCode == HttpStatusCode.OK;    
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Check if email address is valid
        /// </summary>
        /// <param name="emailAddress"></param>
        /// <returns>true if email is valid, false otherwise</returns>
        public static bool IsEmailValid(this string emailAddress)
        {
            try
            {
                var parseEmail = new ParseEmailAddress();

                return (parseEmail.IsValidEmail(emailAddress));
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Strips new line and tab (identation) characters from first/last name string
        /// </summary>
        /// <param name="strName"></param>
        /// <returns>the original string with no special characters</returns>
        public static string RemoveSpecialCharactersFromName(this string strName)
        {
            string newName = string.Empty;

            strName = strName.Replace(Environment.NewLine, string.Empty);
            strName = strName.Replace(@"\r\n", string.Empty);
            strName = strName.Replace(@"\n", string.Empty);
            strName = strName.Replace(@"\t", string.Empty);
            strName = strName.Replace(@"<b />", string.Empty);

            newName = strName;

            return (newName);
        }

        public static void CopyFile(this string destinationPath, string fileName)
        {
            using (WebClient client = new WebClient())
            {
                client.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
                client.UploadFile(destinationPath, fileName);
            }
        }

        public static void RemoveAll<K, V>(this IDictionary<K, V> dict, Func<K, V, bool> match)
        {
            foreach (var key in dict.Keys.ToArray().Where(key => match(key, dict[key])))
            {
                dict.Remove(key);
            }
        }

        public static string GetFileExtension(this string fileName)
        {
            return Path.GetExtension(fileName);
        }

        public static string GetFileName(this string fileName)
        {
            return Path.GetFileNameWithoutExtension(fileName);
        }

        public static string ToPngExtention(this string photoFileName)
        {
            if (photoFileName.IndexOf(".png") == -1)
            {
                return photoFileName + ".png";
            }
            return photoFileName;
        }


        public static void AppendBody(this StringBuilder sb, string tagName, string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                sb.Append(string.Format("<b>{0}</b> :{1}<br />", tagName, value));
            }            
        }
        
    }
}
