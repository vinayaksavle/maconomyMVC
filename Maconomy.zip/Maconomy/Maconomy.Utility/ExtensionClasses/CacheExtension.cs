﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Caching;

namespace Maconomy.Utility.ExtensionClasses
{
    public static class CacheExtension
    {
        static bool ItemRemoved = false;
        static CacheItemRemovedReason OnCacheRemovedReason;
        static CacheItemRemovedCallback OnCacheRemove = null;

        public static void RemovedCallback(String k, Object v, CacheItemRemovedReason r)
        {
            ItemRemoved = true;
            OnCacheRemovedReason = r;
        }

        public static void Remove<T>(this Cache cache) where T : class
        {
            cache.Remove(typeof(T).Name);
        }

        public static void AddToCache<T>(this Cache cache, object item, string key, int duration = 5) where T : class
        {
            ItemRemoved = false;
            OnCacheRemove = new CacheItemRemovedCallback(RemovedCallback);

            cache.Insert(key,
                    item,
                    null,
                    DateTime.Now.AddMinutes(duration),
                    System.Web.Caching.Cache.NoSlidingExpiration,
                    System.Web.Caching.CacheItemPriority.AboveNormal,
                    OnCacheRemove);
        }

        public static T TryGetItemFromCache<T>(this Cache cache, string key) where T : class
        {
            T item;
            item = cache.Get(key) as T;
            return item;
        }

        public static bool Exists<T>(this Cache cache, string key) where T : class
        {
            return cache.Get(key) != null;
        }
    }
}
