﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace Maconomy.Utility.ExtensionClasses
{
    public static class DateTimeExtensions
    {
        /// <summary>
        /// Gets the date for the first day of this week from today.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <param name="startOfWeek"></param>
        /// <returns></returns>
        public static DateTime FirstDayOfThisWeek(this DateTime dateTime)
        {
            return new GregorianCalendar().AddDays(dateTime, -((int)dateTime.DayOfWeek) + 1);
        }

        /// <summary>
        /// Gets the date for last day of the this week from today.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime LastDayOfThisWeek(this DateTime dateTime)
        {
            return new GregorianCalendar().AddDays(dateTime, -((int)dateTime.DayOfWeek) + 7);
        }

        /// <summary>
        /// Gets the date for the first day of this month from today
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime FirstDayOfThisMonth(this DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, 1);
        }

        /// <summary>
        /// Gets the date for the last of this month from today.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime LastDayOfThisMonth(this DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, 1).AddMonths(1).AddDays(-1);
        }

        /// <summary>
        /// Gets the date for the first day of last month from the first day of this month date time.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime FirstDayOfLastMonth(this DateTime dateTime)
        {
            return dateTime.FirstDayOfThisMonth().AddMonths(-1);
        }


        /// <summary>
        /// Gets the date for the last day of last month from the first day of this month datetime.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime LastDayOfLastMonth(this DateTime dateTime)
        {
            return dateTime.FirstDayOfThisMonth().AddDays(-1);
        }

        /// <summary>
        /// Gets the date for the first day of last week from today.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime FirstDayOfLastWeek(this DateTime dateTime)
        {
            return dateTime.AddDays(-(int)dateTime.DayOfWeek - 6);
        }

        /// <summary>
        /// Gets the date for the last day of last week from today date time
        /// </summary>
        /// <param name="firstDayOfLastWeek">pass the current date time</param>
        /// <returns></returns>
        public static DateTime LastDayOfLastWeek(this DateTime dateTime)
        {
            return dateTime.FirstDayOfLastWeek().AddDays(-((int)dateTime.FirstDayOfLastWeek().DayOfWeek) + 7);
        }

        /// <summary>
        /// Gets the date for the first of last six months incluing this month from today date time.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime FirstDayOfLastSixMonths(this DateTime dateTime)
        {
            return dateTime.FirstDayOfThisMonth().AddMonths(-5);
        }

        /// <summary>
        /// Gets the date for the first day of next week from the todays date time.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime FirstDayOfNextWeek(this DateTime dateTime)
        {
            return dateTime.AddDays((int)dateTime.DayOfWeek + 6).FirstDayOfThisWeek();
        }

        /// <summary>
        /// Gets the date for the last day of next week from todays date time.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime LastDayOfNextWeek(this DateTime dateTime)
        {
            return dateTime.FirstDayOfNextWeek().AddDays(-((int)dateTime.FirstDayOfNextWeek().DayOfWeek) + 7);
        }


        /// <summary>
        /// Gets the first day of next month from today date time.
        /// </summary>
        /// <param name="dateTime">pass the current date time</param>
        /// <returns></returns>
        public static DateTime FirstDayOfNextMonth(this DateTime dateTime)
        {
            return dateTime.FirstDayOfThisMonth().AddMonths(1);
        }
        

        /// <summary>
        /// Gets the last day of next month from today date time.
        /// </summary>
        /// <param name="dateTime">pass the current date time.</param>
        /// <returns></returns>
        public static DateTime LastDayOfNextMonth(this DateTime dateTime)
        {
            return new DateTime(dateTime.FirstDayOfNextMonth().Year, dateTime.FirstDayOfNextMonth().Month, 1).AddMonths(1).AddDays(-1);
        }

        /// <summary>
        /// Gets the date for the last day of next six months including this month from today date time.
        /// </summary>
        /// <param name="firstDayOfThisMonth">pass the current date time</param>
        /// <returns></returns>
        public static DateTime LastDayOfNextSixMonths(this DateTime dateTime)
        {
            return dateTime.FirstDayOfThisMonth().AddMonths(5).LastDayOfThisMonth();
        }
        
        /// <summary>
        /// Gets the start day of today.
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static DateTime BeginningOfDay(this DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, dateTime.Day);
        }


    }
}
