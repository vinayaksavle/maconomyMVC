﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.Utility.ExtensionClasses
{
    public static class EnumerableExtensions
    {
        /// <summary>
        /// Check for null list and return Empty list if null.
        /// </summary>
        /// <usage>
        /// List<Item> items = null;
        /// items.EmptyIfNull().Where(w=>w.Id == 1);
        /// </usage>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static IEnumerable<T> EmptyIfNull<T>(this IEnumerable<T> obj)
        {
            return obj ?? Enumerable.Empty<T>();
        }

        /// <summary>
        /// For each extension for IEnumerable as ForEach is only available for List object
        /// </summary>
        /// <usage>
        /// IEnumerable<item> items = new List<item>();
        /// items.ForEach(f=> f.Id = 1);
        /// </usage>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <param name="mapEntity"></param>
        public static void ForEach<T>(this IEnumerable<T> obj, Action<T> mapEntity)
        {
            foreach (var item in obj) mapEntity(item);
        }
    }
}
