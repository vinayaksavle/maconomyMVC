﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using System.Data.SqlTypes;

namespace Maconomy.Utility.ExtensionClasses
{
    public static class SqlParameterExtension
    {
        private static readonly List<KeyValuePair<SqlDbType, Type>> LookupSqlDbType = new List<KeyValuePair<SqlDbType, Type>>
        {
            new KeyValuePair<SqlDbType,Type>(SqlDbType.BigInt, typeof (long)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.VarBinary, typeof (byte[])),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Bit, typeof (bool)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Char, typeof (char)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.VarChar, typeof (string)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.DateTime, typeof (DateTime)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.DateTime, typeof (DateTime?)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Decimal, typeof (decimal)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Float, typeof (double)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Int, typeof (int)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Real, typeof (float)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.UniqueIdentifier, typeof (Guid)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.SmallInt, typeof (short)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.TinyInt, typeof (byte)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Variant, typeof (object)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Structured, typeof (DataTable)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.DateTimeOffset, typeof (DateTimeOffset))
        };

        /// <summary>
        /// Extension method to sqlparameter to the List of Parameter object.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="parameters"></param>
        /// <param name="name"></param>
        /// <param name="value"></param>
        public static void Add<T>(this IList<SqlParameter> parameters, string name, T value)
        {
            Type parameterType = typeof(T);
            SqlDbType sqlDbType;
            sqlDbType = LookupSqlDbType.Where(w => w.Value == parameterType).Select(s => s.Key).FirstOrDefault();
            SqlParameter parameter = new SqlParameter()
            {
                SqlDbType = sqlDbType,
                ParameterName = "@" + name,
                Value = value == null ? (object)DBNull.Value : value
            };
            parameters.Add(parameter);
        }
    }
}
