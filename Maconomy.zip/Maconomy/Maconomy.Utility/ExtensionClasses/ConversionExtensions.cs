﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Maconomy.Utility.ExtensionClasses
{
    public static class ConversionExtensions
    {
        /// <summary>
        /// Generic method to convert to type passed as T.
        /// </summary>
        /// <usage>
        /// object o = "test";
        /// string str = o.To<string>();
        /// </usage>
        public static T To<T>(this IConvertible obj)
        {
            return (T)Convert.ChangeType(obj, typeof(T));
        }

        /// <summary>
        /// Generic method to convert to type passes as T else set as default of T.
        /// </summary>
        /// <usage>
        /// object o = "test";
        /// string str = o.To<string>();
        /// </usage>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static T ToOrDefault<T>(this IConvertible obj)
        {
            try
            {
                return To<T>(obj);
            }
            catch
            {
                return default(T);
            }
        }

        /// <summary>
        /// Generic method to convert type if failed to the passed value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <param name="other"></param>
        /// <returns></returns>
        public static T ToOrOther<T>(this IConvertible obj, T other)
        {
            try
            {
                return To<T>(obj);
            }
            catch
            {
                return other;
            }
        }
        
        /// <summary>
        /// Return bool if type is matched.
        /// </summary>
        /// <usage>
        /// string strList = Obj.Is<string>();
        /// </usage>
        /// <typeparam name="T"></typeparam>
        /// <param name="item"></param>
        /// <returns></returns>
        public static bool Is<T>(this object item) where T : class
        {
            return item is T;
        }

        /// <summary>
        /// Return bool if type is not matched
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="item"></param>
        /// <returns></returns>
        public static bool IsNot<T>(this object item) where T : class
        {
            return !(item.Is<T>());
        }
        
        /// <summary>
        /// Return as type else null if failed
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="item"></param>
        /// <returns></returns>
        public static T As<T>(this object item) where T : class
        {
            return item as T;
        }
    }
}
