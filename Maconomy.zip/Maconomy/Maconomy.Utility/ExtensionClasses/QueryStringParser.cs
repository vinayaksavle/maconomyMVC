﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;
using System.Web;
using System.Web.UI;
using System.Security.Cryptography;
using System.IO;


namespace Maconomy.Utility.ExtensionClasses
{
    public static class QueryStringParser
    {

        public static NameValueCollection ToQueryStringCollection(this string uri)
        {
            var queryString = HttpUtility.ParseQueryString(uri);
            return queryString;
        }

        /// <summary>
        /// Parse QueryString by its base type by passing key to Request.QueryString object.
        /// </summary>
        /// <typeparam name="T">generic to any type</typeparam>        
        /// <param name="key">name of the query string key</param>
        /// <returns>value of the queryString</returns>
        public static T TryParseQueryString<T>(this NameValueCollection queryString, string key)
        {
            T obj;
            try
            {
                obj = (T)Convert.ChangeType(queryString[key], typeof(T));
            }
            catch
            {
                obj = default(T);
            }
            return obj;
        }



        private const string ENCRYPTION_KEY = "ConnectPlusPr3cis3";

        /// <summary>
        /// The salt value used to strengthen the encryption.
        /// </summary>
        private readonly static byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY.Length.ToString());
 
        /// <summary>
        /// Encrypts any string using the Rijndael algorithm.
        /// </summary>
        /// <param name="inputText" />The string to encrypt.
        /// <returns>A Base64 encrypted string.</returns>
        public static string Encrypt(this string inputText)
        {
            using (RijndaelManaged rijndaelCipher = new RijndaelManaged())
            {
                byte[] plainText = Encoding.Unicode.GetBytes(inputText);
                PasswordDeriveBytes secretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT);
                using (ICryptoTransform encryptor = rijndaelCipher.CreateEncryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
                {
                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                        {
                            cryptoStream.Write(plainText, 0, plainText.Length);
                            cryptoStream.FlushFinalBlock();
                            string base64 = Convert.ToBase64String(memoryStream.ToArray());
                            base64 = base64.Replace('+', '-');
                            base64 = base64.Replace('/', '_');
                            base64 = base64.Replace('=', '!');
                            return base64;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Decrypts a previously encrypted string.
        /// </summary>
        /// <param name="inputText" />The encrypted string to decrypt.
        /// <returns>A decrypted string.</returns>
        public static string Decrypt(this string inputText)
        {
            string decrypt = string.Empty;
            using (RijndaelManaged rijndaelCipher = new RijndaelManaged())
            {
                try
                {
                    inputText = inputText.TrimStart('?');
                    inputText = inputText.Replace('-', '+');
                    inputText = inputText.Replace('_', '/');
                    inputText = inputText.Replace('!', '=');

                    byte[] encryptedData = Convert.FromBase64String(inputText);
                    PasswordDeriveBytes secretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT);

                    using (ICryptoTransform decryptor = rijndaelCipher.CreateDecryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
                    {
                        using (MemoryStream memoryStream = new MemoryStream(encryptedData))
                        {
                            using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                            {
                                byte[] plainText = new byte[encryptedData.Length];
                                //int decryptedCount = cryptoStream.Read(plainText, 0, plainText.Length);
                                //return Encoding.Unicode.GetString(plainText, 0, decryptedCount);
                                int decryptCount = cryptoStream.Read(plainText, 0, plainText.Length);
                                decrypt = Encoding.Unicode.GetString(plainText, 0, decryptCount);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    
                }
            }
            return decrypt;
        }
    }
}
