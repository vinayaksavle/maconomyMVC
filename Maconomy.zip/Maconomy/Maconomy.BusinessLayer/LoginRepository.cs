﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class LoginRepository
    {
        private static LoginRepository _loginRepository;
        public static LoginRepository Instance
        {
            get
            {
                if (_loginRepository == null)
                {
                    _loginRepository = new LoginRepository();
                }
                return _loginRepository;
            }
        }

        public User CheckLogin(string userName,string password)
        {
            return LoginRepositoryDb.Instance.CheckLogin(userName,password);
        }

    }
}
