﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class BusinessUnitConfigPackRepository
    {
        private static BusinessUnitConfigPackRepository _bUnitRepository;
        public static BusinessUnitConfigPackRepository Instance
        {
            get
            {
                if (_bUnitRepository == null)
                {
                    _bUnitRepository = new BusinessUnitConfigPackRepository();
                }
                return _bUnitRepository;
            }
        }

        public IEnumerable<BusinessUnit> GetBussinessUnit(int ConfigPackId, int UserId, int CompanyId)
        {
            return BusinessUnitConfigPackRepositoryDb.Instance.GetBussinessUnit(ConfigPackId, UserId, CompanyId);
        }

        public BusinessUnit EditBussinessUnit(int ConfigPackId, int UserId, int CompanyId, int Id)
        {
            return BusinessUnitConfigPackRepositoryDb.Instance.EditBussinessUnit(ConfigPackId,UserId,CompanyId, Id);
        }

        public string SaveBussinessUnit(BusinessUnit bUnit, int UserId)
        {
            return BusinessUnitConfigPackRepositoryDb.Instance.SaveBussinessUnit(bUnit, UserId);
        }

    }
}
