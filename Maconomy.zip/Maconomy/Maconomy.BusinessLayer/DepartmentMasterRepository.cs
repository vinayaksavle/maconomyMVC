﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class DepartmentMasterRepository
    {
        private static DepartmentMasterRepository _deptRepository;
        public static DepartmentMasterRepository Instance
        {
            get
            {
                if (_deptRepository == null)
                {
                    _deptRepository = new DepartmentMasterRepository();
                }
                return _deptRepository;
            }
        }

        public List<DepatmentMaster> GetDepartmentMaster()
        {
            return DepartmentMasterRepositoryDB.Instance.GetDepartmentMaster();
        }

     

        public string SaveDeptMaster(DepatmentMaster dptMaster)
        {
            return DepartmentMasterRepositoryDB.Instance.SaveDepartmentMaster(dptMaster);
        }

    }
}
