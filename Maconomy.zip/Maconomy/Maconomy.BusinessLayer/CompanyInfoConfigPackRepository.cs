﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class CompanyInfoConfigPackRepository
    {
        private static CompanyInfoConfigPackRepository _compInfoRepository;
        public static CompanyInfoConfigPackRepository Instance
        {
            get
            {
                if (_compInfoRepository == null)
                {
                    _compInfoRepository = new CompanyInfoConfigPackRepository();
                }
                return _compInfoRepository;
            }
        }

        public CompanyInformation EditComapnyInfo(int ConfigPackId, int UserId, int CompanyId)
        {
            return CompanyInfoConfigPackRepositoryDB.Instance.EditComapnyInfo(ConfigPackId,UserId,CompanyId);
        }

        public string SaveCompanyInfo(CompanyInformation cGroup, int ConfigPackId, int UserId, int CompanyId)
        {
            return CompanyInfoConfigPackRepositoryDB.Instance.SaveCompanyInfo(cGroup, ConfigPackId, UserId, CompanyId);
        }

    }
}
