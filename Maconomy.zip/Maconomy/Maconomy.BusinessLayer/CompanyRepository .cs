﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class CompanyRepository
    {
        private static CompanyRepository _compRepository;
        public static CompanyRepository Instance
        {
            get
            {
                if (_compRepository == null)
                {
                    _compRepository = new CompanyRepository();
                }
                return _compRepository;
            }
        }

        public List<Company> GetCompany()
        {
            return CompanyRepositoryDb.Instance.GetCompany();
        }

     

        public string SaveCompany(Company company)
        {
            return CompanyRepositoryDb.Instance.SaveCompany(company);
        }

    }
}
