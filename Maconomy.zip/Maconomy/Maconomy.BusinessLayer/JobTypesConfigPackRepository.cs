﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class JobTypesConfigPackRepository
    {
        private static JobTypesConfigPackRepository _jTypeRepository;
        public static JobTypesConfigPackRepository Instance
        {
            get
            {
                if (_jTypeRepository == null)
                {
                    _jTypeRepository = new JobTypesConfigPackRepository();
                }
                return _jTypeRepository;
            }
        }
        public List<JobTypes> GetJobTypes(string search)
        {
            return JobTypesConfigPackRepositoryDb.Instance.GetJobTypes(search);
        }

        public List<JobViewConfigModel> GetJobTypeConfigPack(int ConfigPackId, int UserId)
        {
            return JobTypesConfigPackRepositoryDb.Instance.GetJobTypeConfigPack(ConfigPackId, UserId);
        }

       

        public string SaveJobTypeConfigPack(List<JobViewConfigModel> jUnit, int UserId)
        {
            return JobTypesConfigPackRepositoryDb.Instance.SaveJobTypeConfigPack(jUnit, UserId);
        }

    }
}
