﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class ConfigPackRepository
    {
        private static ConfigPackRepository _configPackRepository;
        public static ConfigPackRepository Instance
        {
            get
            {
                if (_configPackRepository == null)
                {
                    _configPackRepository = new ConfigPackRepository();
                }
                return _configPackRepository;
            }
        }

        public List<MaconomyConfigPack> GetConfigPacks(int UserId, int CompanyId)
        {
            return ConfigPackRepositoryDB.Instance.GetConfigPacks(UserId,CompanyId);
        }


    }
}
