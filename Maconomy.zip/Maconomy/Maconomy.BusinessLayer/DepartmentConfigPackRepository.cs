﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class DepartmentConfigPackRepository
    {
        private static DepartmentConfigPackRepository _deptRepository;
        public static DepartmentConfigPackRepository Instance
        {
            get
            {
                if (_deptRepository == null)
                {
                    _deptRepository = new DepartmentConfigPackRepository();
                }
                return _deptRepository;
            }
        }

        public IEnumerable<DepatmentMaster> GetDepartmentMaster()
        {
            return DepartmentConfigPackRepositoryDb.Instance.GetDepartmentMaster();
        }

        public IEnumerable<DepartmentViewmodel> GetDepartment(int ConfigPackId, int UserId, int CompanyId)
        {
            return DepartmentConfigPackRepositoryDb.Instance.GetDepartment(ConfigPackId,UserId,CompanyId);
        }

        public DepartmentViewmodel EditDepartment(int ConfigPackId, int UserId, int CompanyId, int Id)
        {
            return DepartmentConfigPackRepositoryDb.Instance.EditDepartment(ConfigPackId, UserId, CompanyId, Id);
        }

        public string SaveDepartment(DepartmentViewmodel dept,int UserId)
        {
            return DepartmentConfigPackRepositoryDb.Instance.SaveDepartment(dept,UserId);
        }

    }
}
