﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class CompanyGroupRepository
    {
        private static CompanyGroupRepository _compGrpRepository;
        public static CompanyGroupRepository Instance
        {
            get
            {
                if (_compGrpRepository == null)
                {
                    _compGrpRepository = new CompanyGroupRepository();
                }
                return _compGrpRepository;
            }
        }

        public List<CompanyGroup> GetCompanyGroups()
        {
            return CompanyGroupRepositoryDb.Instance.GetCompanyGroups();
        }

        public string SaveCompanyGroup(CompanyGroup cGroup)
        {
            return CompanyGroupRepositoryDb.Instance.SaveCompanyGroup(cGroup);
        }

    }
}
