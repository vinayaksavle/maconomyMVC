﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class UserRepository
    {
        private static UserRepository _userRepository;
        public static UserRepository Instance
        {
            get
            {
                if (_userRepository == null)
                {
                    _userRepository = new UserRepository();
                }
                return _userRepository;
            }
        }

        public List<User> GetUsers()
        {
            return UserRepositoryDb.Instance.GetUsers();
        }

        public List<UserRole> GetRoles()
        {
            List<UserRole> roles = new List<UserRole>();
            roles.Add(new UserRole() { RoleId = 0, RoleName = "Super Admin" });
            roles.Add(new UserRole() { RoleId = 1, RoleName = "Admin" });
            roles.Add(new UserRole() { RoleId = 2, RoleName = "User" });
            roles.Add(new UserRole() { RoleId = 3, RoleName = "Reviewer" });
            return roles;
        }

        public string SaveUser(User user)
        {
            return UserRepositoryDb.Instance.SaveUser(user);
        }

    }
}
