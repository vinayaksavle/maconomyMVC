﻿using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessLayer
{
    public class JobTypeMasterRepository
    {
        private static JobTypeMasterRepository _jTypeRepository;
        public static JobTypeMasterRepository Instance
        {
            get
            {
                if (_jTypeRepository == null)
                {
                    _jTypeRepository = new JobTypeMasterRepository();
                }
                return _jTypeRepository;
            }
        }

        public List<JobTypeMaster> GetJobTypeMaster()
        {
            return JobTypeMasterRepositoryDB.Instance.GetJobTypeMaster();
        }



        public string SaveJobTypeMaster(JobTypeMaster jTypeMaster)
        {
            return JobTypeMasterRepositoryDB.Instance.SaveJobTypeMaster(jTypeMaster);
        }

    }
}
