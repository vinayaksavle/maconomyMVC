﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessEntities.Constants
{
    public class Constants
    {
        public const string FirstLevelCategories = "FirstLevelCategories";
        public const string SecondLevelCategories = "SecondLevelCategories";
        public const string MainLevelCategories = "MainLevelCategories";

        public const string Country = "country";
        public const string State = "state";
        public const string County = "county";
        public const string City = "city";

        public const string SearchOutlet = "searchoutlet";

        public const string SearchContact = "searchcontact";
        public const string Pagination = "pagination";
        public const string Filter = "filter";
        public const string FoamTreeCluster = "foamtreecluster";
        public const string TweetsPage = "tweetspage";
        public const string SplitView = "splitview";

        public const string ViewContacts = "viewContacts";

        public const string GridResizeJavascriptFunction = "viewTweetsContacts._grid.Resize();";

        //Session Key for getting User info
        public const string SessionKey = "SessionKey";

        public const string DefaultEmailFromUser = "precise@precise.uk";
        

        #region used for view live tweets page
        public const string SearchContacts = "searchcontacts";
        public const string SearchOutlets = "searchoutlets";
        public const string ViewOutlet = "viewoutlet";
        public const string ViewList = "viewlist";
        #endregion

    }
}
