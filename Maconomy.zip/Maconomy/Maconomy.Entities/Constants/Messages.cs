﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessEntities.Constants
{
    public class Messages
    {
        public const string NoRecordFoundById = "No record found by {0} for id - {1}";
        public const string NoRecordFound = "No record found for {0}";
        public const string WebServiceError = "There was error in web service - {0}";
        public const string NoSearchType = "search type does not exist when passed as parameter to service";
        public const string DuplicateEntry = "Duplicate entry exist for the {0}";
        public const string SourceTypeDoesNotExist = "source type does not exist when passed as parameter to service";
        public const string MethodExecutingQuery = "-- Method executing query : {0}";
    }
}
