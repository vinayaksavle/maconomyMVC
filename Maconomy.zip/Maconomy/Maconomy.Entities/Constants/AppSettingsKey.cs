﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessEntities.Constants
{
    public class AppSettingsKey
    {
        public static string SqlCommandTimeout = "SqlCommandTimeout";
        public static string MaconomyConnectionString = "Maconomy";
    }
}
