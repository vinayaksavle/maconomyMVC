using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessEntities.Constants
{
    public class StoredProcedures
    {
        public const string SP_GetCompanyGroups = "dbo.sp_GetCompanyGroups";
        public const string SP_SaveCompanyGroup = "dbo.sp_SaveCompanyGroup";

        public const string SP_ValidateUser = "dbo.sp_ValidateUser";

        public const string SP_GetAllCompany = "dbo.sp_GetAllCompany";
        public const string SP_SaveCompany = "dbo.sp_SaveCompany";

        public const string SP_SaveDeptMaster = "dbo.sp_SaveDeptMaster";

        public const string SP_GetAllUsers = "dbo.sp_GetAllUsers";
        public const string SP_SaveUser = "dbo.sp_SaveUser";


        public const string SP_GetCompnayInfoConfigPack = "dbo.sp_GetCompnayInfoConfigPack";

        public const string SP_GetUserConfigPack = "dbo.sp_GetUserConfigPack";
        public const string SP_GetBusinessUnitInfoConfigPack = "dbo.sp_GetBusinessUnitInfoConfigPack";


        public const string SP_GetJobTypes = "dbo.SP_GetJobTypes";

        public const string SP_GetDepartmentConfigPack = "dbo.sp_GetDepartmentConfigPack";

        public const string SP_GetDepartmentMaster = "dbo.sp_GetDepartmentMaster";
        public const string SP_GetJobTypeMaster = "dbo.sp_GetJobTypeMaster";
        public const string SP_SaveJobTypeMaster = "dbo.sp_SaveJobTypeMaster ";



        public const string SP_SaveBusinessUnitConfigPack = "dbo.sp_SaveBusinessUnitConfigPack";
        public const string SP_SaveCompanyInfoConfigPack = "dbo.sp_SaveCompanyInfoConfigPack";
        public const string SP_SaveDepartmentConfigPack = "dbo.sp_SaveDepartmentConfigPack";
        public const string SP_SaveJobTypeConfigPack = "dbo.sp_SaveJobTypeConfigPack";
        public const string SP_GetJobTypeConfigPack = "dbo.sp_GetJobTypeConfigPack";




    }
}
