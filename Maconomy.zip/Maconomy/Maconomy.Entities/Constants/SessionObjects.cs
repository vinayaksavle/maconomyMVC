﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maconomy.BusinessEntities.Constants
{
    public class SessionObjects
    {
        public const string MaconomySession = "__MaconomySession__";

    }
}
