﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class CompanyInformation
    {
        public int intId { get; set; }
        public int CompanyId { get; set; }
        public int UserId { get; set; }

        
        public int ConfigPackId { get; set; }

        [DisplayName("Legacy Old Company Id")]
        public string strLegacyID { get; set; }

        [DisplayName("Company Name")]
        public string strCompanyName { get; set; }
        [DisplayName("Street Address1")]
        public string strStreetAddress1 { get; set; }
        [DisplayName("Street Address2")]
        public string strStreetAddress2 { get; set; }
        [DisplayName("Street Address3")]
        public string strStreetAddress3 { get; set; }
        [DisplayName("Area/County/State")]
        public string strArea_County_State { get; set; }
        [DisplayName("Postal Code")]
        public string strPostal_Code { get; set; }//change
        [DisplayName("Country Name")]
        public string strPostalDistrictOrCity { get; set; }
        [DisplayName("Company Name")]
        public Country strCountry { get; set; }
        [DisplayName("StructureType")]
        public string strMaconomyOrganisation_StructureType { get; set; }//change
        [DisplayName("Legal Entity Name")]
        public string strLegalEntityName { get; set; }
        [DisplayName("Base Currency")]
        public Currency strBaseCurrency { get; set; }
        [DisplayName("Phone")]
        public string strPhone { get; set; }
        [DisplayName("Fax")]
        public string strFax { get; set; }//change
        [DisplayName("Company Registration No")]
        public string strCompanyRegistrationNo { get; set; }
        [DisplayName("Tax No")]
        public string strTaxNo { get; set; }
        [DisplayName("PAN No")]
        public string strPANNo { get; set; }
        [DisplayName("TAN No")]
        public string strTANNo { get; set; }
        [DisplayName("BFC No")]
        public string strBFCNo { get; set; }
        [DisplayName("WPP Office Code Entity")]
        public WPPOfficeCodeEntity strWPPofficecodeEntity { get; set; }
        [DisplayName("ManagingDirector Empl 1")]
        public string strManagingDirector_Empl_1 { get; set; }
        [DisplayName("FinanceDirector Empl 2")]
        public string strFinance_Director_Empl_2 { get; set; }
        [DisplayName("CEO Empl 3")]
        public string strCFO_Empl_3 { get; set; }
        [DisplayName("CEO Empl 4")]
        public string strCEO_Empl_4 { get; set; }
        [DisplayName("Standard Weekly hours")]
        public string strStandardWeeklyhours { get; set; }//change
        [DisplayName("TimeSheet Hours")]
        public TimesheetHours strMandatoryMin_TimeSheetHours { get; set; }
        [DisplayName("Absence Management Tool")]
        public MaconomyAbsence strUsing_Maconomy_Absence_Management_tool { get; set; }
        [DisplayName("OtherKey Info")]
        public string strOtherKey_Info { get; set; }
        [DisplayName("Additional Comments")]
        public string strAdditional_Comments { get; set; }

        public Country Countries { get; set; }

        public MaconomyAbsence Mabsence { get; set; }

        public TimesheetHours TimeSheetHrs { get; set; }
        public Currency currency { get; set; }
        public WPPOfficeCodeEntity WPPOffc { get; set; }

    }
    public enum Country
    {
        India,
        Ireland,
        Libya,
        Afghanistan,
        Algeria,
        Argentina,
    }
    public enum MaconomyAbsence
    {
        Yes = 1,
        No = 0
    }
    public enum TimesheetHours
    {
        NoMinimum = 0,
        PerSplitWeek = 1,
        PerDay =2 
    }
    public enum Currency
    {
        IndianRupee,
        IraquiDinar,
        SouthAfricanRand,
        Japaneseyen,
        Euro,
        UsDollar
    }
    public enum WPPOfficeCodeEntity
    {
        Grey,
        JWT,
        Kantar,
        Ogilvy,
        Geometry,
        BrandUnion,
        Fitch,
        VBAT,
        LambieNairn,
        Hogarth,
        ParentPlus,
        Possible,
        FinancePlus
    }



}