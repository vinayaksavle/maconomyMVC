﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class JobTypeViewModel
    {
        public List<JobTypes> jobList { get; set; }
        public List<JobViewConfigModel> jobModel { get; set; }

        public JobTypeMaster jobMaster { get; set; }
    }
}