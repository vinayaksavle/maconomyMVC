﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class BusinessUnit
    {
        [DisplayName("Id")]
        public int intId { get; set; }
        public int intConfigPackId { get; set; }

        [DisplayName("BFC Entity")]
        public string strBFCEntity { get; set; }

        [DisplayName("Busines Unit No")]
        public string strBusinesUnitNo { get; set; }

        [DisplayName("Business Unit Name")]
        public string strBusinessUnitName { get; set; }

        [DisplayName("BU Legacy Name")]
        public string strBU_LegacyName { get; set; }

        [DisplayName("BU Legacy FieldName")]
        public string strBU_LegacyFieldName { get; set; }

        [DisplayName("BU Legacy CodeOrValue")]
        public string strBU_LegacyCodeOrValue { get; set; }


        public int intUserId { get; set; }
        public int intCompanyid { get; set; }
    }
}