﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class JobTypeMaster
    {
        [DisplayName("Job TypeId")]
        public int intId { get; set; }       

        [DisplayName("Job Type Code")]
        public string strJobType { get; set; }
        [DisplayName("Description")]
        public string strDescription { get; set; }

        [DisplayName("Justification")]
        public string strComments { get; set; }

        [DisplayName("Active")]
        public string bitIsActive { get; set; }


        [DisplayName("Approved")]
        public bool bitIsApproved { get; set; }

        public int intUserId { get; set; }
        public int intCompanyid { get; set; }
        public int intConfigPackId { get; set; }

    }
}