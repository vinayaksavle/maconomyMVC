﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class MaconomyConfigPack
    {
        [DisplayName("Id")]
        public int Id { get; set; }
        [DisplayName("Name")]
        public string Name { get; set; }
        [DisplayName("Company")]
        public string CompanyId { get; set; }
        [DisplayName("Created By")]
        public string CreatedBy { get; set; }
        [DisplayName("Created Date")]
        public string CreatedOn { get; set; }
        [DisplayName("Modified By")]
        public string ModifiedBy { get; set; }
        [DisplayName("Modified Date")]
        public string ModifiedOn { get; set; }
        [DisplayName("Version No.")]
        public string VersionNum { get; set; }
        [DisplayName("User Name")]
        public string UserName { get; set; }
        [DisplayName("Parent ConfigPack")]
        public string ParentConfigPackId { get; set; }
        [DisplayName("Status")]
        public string Status { get; set; }

        [DisplayName("Download")]
        public string Download { get; set; }

        public int UserId { get; set; }
    }
    //public enum ConfigPackStatus
    //{
    //    Draft = 1,
    //    Submitted = 2,
    //    Approved = 3,
    //}
}