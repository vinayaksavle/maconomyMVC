﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class Department
    {
        [DisplayName("Id")]
        public int Id { get; set; }
        
        public int ConfigPackId { get; set; }
        [DisplayName("Deparment Master Id")]
        public int DeparmentMasterId { get; set; }
        [DisplayName("Legacy Name")]
        public string LegacyName { get; set; }
        [DisplayName("Legacy Field Name")]
        public string LegacyFieldName { get; set; }
        [DisplayName("Legacy CodeOrValue")]
        public string LegacyCodeOrValue { get; set; }

        [DisplayName("Department Code")]
        public string DepartmentCode { get; set; }
        [DisplayName("Description")]
        public string Description { get; set; }
        [DisplayName("Active")]
        public string IsActive { get; set; }
    }
}