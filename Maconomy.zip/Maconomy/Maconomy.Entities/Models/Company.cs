﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Maconomy.BusinessEntities.Models
{
    public class Company
    {
        [DisplayName("Company")]
        public int Id { get; set; }
        
        [DisplayName("Company Group ID")]
        public string CompanyGroupID { get; set; }
        [DisplayName("Company Group")]
        public string CompanyGroup { get; set; }
        [DisplayName("Company Name")]
        [Required(ErrorMessage ="Please enter Company Name")]
        public string CompanyName { get; set; }
        [DisplayName("Active")]
        public string isActive { get; set; }

        public bool Active { get; set; }

        //  public IEnumerable<CompanyGroup> companyGroups { get; set; }


        public List<CompanyGroup> companyGroups { get; set; }
    }
}