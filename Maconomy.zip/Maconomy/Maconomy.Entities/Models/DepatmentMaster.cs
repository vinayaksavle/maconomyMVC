﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class DepatmentMaster
    {
        [DisplayName("Deparment MasterId")]
        public int DeparmentMasterId { get; set; }
        [DisplayName("Department Code")]
        public string DepartmentCode { get; set; }
        [DisplayName("Description")]
        public string Description { get; set; }
        [DisplayName("Active")]
        public string IsActive { get; set; }

        [DisplayName("Department Code")]
        public string strDepartmentCode { get; set; }
        [DisplayName("Description")]
        public string strDescription { get; set; }

        [DisplayName("Active")]
        public string bitIsActive { get; set; }


        [DisplayName("Approved")]
        public bool bitIsApproved { get; set; }
    }
}