﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class JobTypes
    {
        [DisplayName("Id")]
        public int intId { get; set; }

        public bool chk { get; set; }

        [DisplayName("Job Type")]
        public string strJobType { get; set; }

        [DisplayName("Description")]
        public string strDescription { get; set; }
        
        [DisplayName("Active")]
        public string bitIsActive { get; set; }

        public bool Checked { get; set; }


        public int intUserId { get; set; }
        public int intCompanyid { get; set; }
    }
}