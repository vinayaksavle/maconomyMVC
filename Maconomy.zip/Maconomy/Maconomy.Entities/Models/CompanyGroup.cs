﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
   public  class CompanyGroup
    {
        [DisplayName("Id")]
        public int Id { get; set; }
        [DisplayName("Company Group")]
        public string Companygroup { get; set; }
        [DisplayName("Active")]
        public string isActive { get; set; }
    }
}