﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class DepartmentViewmodel
    {
        [DisplayName("Id")]
        public int intId { get; set; }
        [DisplayName("Deparment MasterId")]
        public int intDeparmentMasterId { get; set; }
        [DisplayName("Legacy Name")]
        public string strLegacyName { get; set; }
        [DisplayName("Legacy Field Name")]
        public string strLegacyFieldName { get; set; }
        [DisplayName("Legacy CodeOrValue")]
        public string strLegacyCodeOrValue { get; set; }
        [DisplayName("Department Name")]

        public string strDepartmentName { get; set; }
        [DisplayName("Department Code")]


        public string DepartmentCode { get; set; }
        [DisplayName("Description")]
        public string Description { get; set; }
        [DisplayName("Active")]
        public string IsActive { get; set; }

        public bool IsApproved { get; set; }


        public int intConfigPackId { get; set; }
        public int intUserId { get; set; }
        public int intCompanyid { get; set; }

        public IEnumerable<DepatmentMaster> DeptMaster { get; set; }
        }
    }
