﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class JobViewConfigModel
    {
        [DisplayName("Id")]
        public int intId { get; set; }
        public int intConfigPackId { get; set; }

        public string jobType { get; set; }

        public string Description { get; set; }

        

        [DisplayName("Legacy Name")]
        public string str_LegacyName { get; set; }

        [DisplayName("Legacy FieldName")]
        public string str_LegacyFieldName { get; set; }

        [DisplayName("Legacy CodeOrValue")]
        public string str_LegacyCodeOrValue { get; set; }

        public int intJobTyeMasterId { get; set; }

        public int intUserId { get; set; }
        public int intCompanyid { get; set; }

        public bool bitIsApproved { get; set; }
    }
}