﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Maconomy.BusinessEntities.Models
{
    public class User
    {
        [DisplayName("Id")]
        public int Id { get; set; }
        [DisplayName("User Name")]
        public string userName { get; set; }
        [DisplayName("Password")]
        public string password { get; set; }
        [DisplayName("company ID")]
        public int companyID { get; set; }
        [DisplayName("Company Name")]
        public string CompanyName { get; set; }
        [DisplayName("Role")]
        public int RoleId { get; set; }

        public string RoleName { get; set; }

        public List<UserRole> Role { get; set; }

        [DisplayName("Active")]
        public string isActive { get; set; }

        
        public int intConfigPackId { get; set; }

        public List<Company> CompanyNames { get; set; }

        public User()
        {
            Role = new List<UserRole>();
            CompanyNames = new List<Company>();
        }
    }

    public class UserRole
    {
        public string RoleName { get; set;}
        public int RoleId { get; set; }
    }


    //public enum UserRole
    //{
    //    Admin=1,
    //    User=2,
    //    Reviewer=3
    //}
}