﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Maconomy.BusinessEntities.Models;
using Maconomy.BusinessLayer;
using System;

namespace Maconomy.Controllers
{
    public class UserController : Controller
    {
        #region Fields      
        List<BusinessUnit> BusinessUnitList;
        List<DepartmentViewmodel> listDepartmentViewmodel = new List<DepartmentViewmodel>();
        #endregion

        #region Constructor
        public UserController()
        {
            //BindBusinessData();
        }
        #endregion

        #region CompanyInformation

        // GET: User
        public ActionResult CompanyInformation(int Userid, int CompanyId,int ConfigPackId)
        {
            CompanyInformation cInfo = new CompanyInformation();
            cInfo.UserId = Userid;
            cInfo.CompanyId = CompanyId;
            cInfo.ConfigPackId = ConfigPackId;

            TempData["Userid"] = Userid;
            TempData["CompanyId"] = CompanyId;
            TempData["ConfigPackId"] = ConfigPackId;


            TempData.Keep();



            if (ConfigPackId != 0)
            {
                cInfo = CompanyInfoConfigPackRepository.Instance.EditComapnyInfo(ConfigPackId, Userid, CompanyId);
            }


            return View(cInfo);
        }
        [HttpPost]
        public ActionResult CompanyInformation(CompanyInformation CompanyInfo)
        {
            User user = TempData["userdata"] as User;
            
            string id= CompanyInfoConfigPackRepository.Instance.SaveCompanyInfo(CompanyInfo, CompanyInfo.ConfigPackId, user.Id, user.companyID);
            return RedirectToAction("CompanyInformation", new
            {
                Userid = System.Convert.ToInt32(TempData["Userid"]),
                CompanyId = System.Convert.ToInt32(TempData["CompanyId"]),
                ConfigPackId = CompanyInfo.ConfigPackId
            });
        }
        #endregion

        #region BusinessUnit
        public ActionResult BusinessUnit(int Userid, int CompanyId, int ConfigPackId)
        {
            TempData["Userid"] = Userid;
            TempData["CompanyId"] = CompanyId;
            TempData["ConfigPackId"] = ConfigPackId;

            TempData.Keep();


            IEnumerable<BusinessUnit> bUnit = BusinessUnitConfigPackRepository.Instance.GetBussinessUnit(ConfigPackId, Userid, CompanyId);
            return View(bUnit);
        }

        [HttpPost]
        public ActionResult SaveBusinessUnit(BusinessUnit Businessobj)
        {
            return Json(Businessobj, JsonRequestBehavior.AllowGet);

            //return success status and data
        }

        public ActionResult EditBusinessUnit(int Id)
        {
            int Userid = Convert.ToInt32(TempData["Userid"]);
            int CompanyId = Convert.ToInt32(TempData["CompanyId"]);
            int ConfigPackId = Convert.ToInt32(TempData["ConfigPackId"]);

            BusinessUnit bUnit = BusinessUnitConfigPackRepository.Instance.EditBussinessUnit(ConfigPackId
                , Userid, CompanyId, Id);

            bUnit.intUserId = Userid;
            bUnit.intCompanyid = CompanyId;
            bUnit.intConfigPackId = ConfigPackId;

            return View(bUnit);
        }
        [HttpPost]
        public ActionResult EditBusinessUnit(BusinessUnit savebusinessobj)
        {
            
            savebusinessobj.intConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"]);
             BusinessUnitConfigPackRepository.Instance.SaveBussinessUnit(savebusinessobj, System.Convert.ToInt32(TempData["Userid"]));
            return RedirectToAction("BusinessUnit",new { Userid = System.Convert.ToInt32( TempData["Userid"]),
                CompanyId = System.Convert.ToInt32(TempData["CompanyId"]),
                ConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"])
            });
        }

        public ActionResult AddBusinessUnit()
        {
            int Userid = Convert.ToInt32(TempData["Userid"]);
            int CompanyId = Convert.ToInt32(TempData["CompanyId"]);
            int ConfigPackId = Convert.ToInt32(TempData["ConfigPackId"]);

            BusinessUnit bUnit = new BusinessEntities.Models.BusinessUnit();
            bUnit.intUserId = Userid;
            bUnit.intCompanyid = CompanyId;
            bUnit.intConfigPackId = ConfigPackId;
            return View(bUnit);
        }
        [HttpPost]
        public ActionResult AddBusinessUnit(BusinessUnit bUnit)
        {
            bUnit.intConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"]);
            
            BusinessUnitConfigPackRepository.Instance.SaveBussinessUnit(bUnit, System.Convert.ToInt32(TempData["Userid"]));
            return RedirectToAction("BusinessUnit", new
            {
                Userid = System.Convert.ToInt32(TempData["Userid"]),
                CompanyId = System.Convert.ToInt32(TempData["CompanyId"]),
                ConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"])
            });
        }
        #endregion

        #region Department
        public ActionResult Department(int Userid, int CompanyId, int ConfigPackId)
        {
            TempData["Userid"] = Userid;
            TempData["CompanyId"] = CompanyId;
            TempData["ConfigPackId"] = ConfigPackId;

            TempData.Keep();

            IEnumerable<DepartmentViewmodel> bUnit = DepartmentConfigPackRepository.Instance.GetDepartment(ConfigPackId, Userid, CompanyId);
            return View(bUnit);
        }

        public ActionResult EditDepartment(int DeparmentMasterId)
        {
            int Userid = Convert.ToInt32( TempData["Userid"] ) ;
            int CompanyId = Convert.ToInt32(TempData["CompanyId"]);
            int ConfigPackId = Convert.ToInt32(TempData["ConfigPackId"])  ;

            DepartmentViewmodel departmentVM = DepartmentConfigPackRepository.Instance.EditDepartment(ConfigPackId, Userid, CompanyId, DeparmentMasterId);

            departmentVM.DeptMaster = DepartmentConfigPackRepository.Instance.GetDepartmentMaster();

            departmentVM.intUserId = Userid;
            departmentVM.intCompanyid = CompanyId;
            departmentVM.intConfigPackId = ConfigPackId;

            return View(departmentVM);
              return RedirectToAction("BusinessUnit",new { Userid = System.Convert.ToInt32( TempData["Userid"]),
                CompanyId = System.Convert.ToInt32(TempData["CompanyId"]),
                ConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"])
            });
        }

        [HttpPost]
        public ActionResult EditDepartment(DepartmentViewmodel SaveDepartment)
        {
            SaveDepartment.intConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"]);



            DepartmentConfigPackRepository.Instance.SaveDepartment(SaveDepartment, System.Convert.ToInt32(TempData["Userid"]));
            return RedirectToAction("Department", new
            {
                Userid = System.Convert.ToInt32(TempData["Userid"]),
                CompanyId = System.Convert.ToInt32(TempData["CompanyId"]),
                ConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"])
            });
        }

        public ActionResult AddDepartment()
        {
            DepartmentViewmodel DModel = new DepartmentViewmodel();

            int Userid = Convert.ToInt32(TempData["Userid"]);
            int CompanyId = Convert.ToInt32(TempData["CompanyId"]);
            int ConfigPackId = Convert.ToInt32(TempData["ConfigPackId"]);

            DModel.intUserId = Userid;
            DModel.intCompanyid = CompanyId;
            DModel.intConfigPackId = ConfigPackId;

            DModel.DeptMaster = DepartmentConfigPackRepository.Instance.GetDepartmentMaster();
           // ViewBag.VBDepartment = new SelectList(listDepartmentViewmodel, "DepartmentCode", "Description");
            return View(DModel);
        }
        [HttpPost]
        public ActionResult AddDepartment(DepartmentViewmodel Dept)
        {
            Dept.intConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"]);

          

            DepartmentConfigPackRepository.Instance.SaveDepartment(Dept, System.Convert.ToInt32(TempData["Userid"]));
            return RedirectToAction("Department",new { Userid = System.Convert.ToInt32( TempData["Userid"]),
                CompanyId = System.Convert.ToInt32(TempData["CompanyId"])  , ConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"] )});
        }

        #endregion

        #region JobType


        public ActionResult SearchJobTye(string searchString)
        {
            int Userid = System.Convert.ToInt32(TempData["Userid"]);
            int ConfigPackId = Convert.ToInt32(TempData["ConfigPackId"]);
            TempData.Keep();

            List<JobViewConfigModel> jType = JobTypesConfigPackRepository.Instance.GetJobTypeConfigPack(ConfigPackId, Userid);
            List<JobTypes> jobTypes = JobTypesConfigPackRepository.Instance.GetJobTypes(searchString);

            foreach (JobTypes j in jobTypes)
            {
                foreach (JobViewConfigModel c in jType)
                {
                    if (j.strJobType == c.jobType && j.strDescription == c.Description)
                    {
                        j.Checked = true;
                        break;
                    }
                }
            }

            return PartialView("JobTypeMaster", jobTypes);
        }

        public ActionResult SaveJobType(List<JobViewConfigModel> jModel)
        {
            int Userid = System.Convert.ToInt32(TempData["Userid"]);
            int ConfigPackId = Convert.ToInt32(TempData["ConfigPackId"]);
            jModel.ForEach(z => z.intConfigPackId = ConfigPackId);
            string result = JobTypesConfigPackRepository.Instance.SaveJobTypeConfigPack(jModel, Userid);
            return RedirectToAction("JobType", new
            {
                Userid = System.Convert.ToInt32(TempData["Userid"]),
                CompanyId = System.Convert.ToInt32(TempData["CompanyId"]),
                ConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"])
            });
        }

        [HttpPost]
        public ActionResult AddJobType(string jobType,string des,string comments)
        {
            JobTypeMaster jMaster = new JobTypeMaster();
            jMaster.strJobType = jobType;
            jMaster.strDescription = des;
            jMaster.strComments = comments;
            string result = JobTypeMasterRepository.Instance.SaveJobTypeMaster(jMaster);
            return RedirectToAction("JobType", new
            {
                Userid = System.Convert.ToInt32(TempData["Userid"]),
                CompanyId = System.Convert.ToInt32(TempData["CompanyId"]),
                ConfigPackId = System.Convert.ToInt32(TempData["ConfigPackId"])
            });
        }

        public ActionResult JobType(int Userid, int CompanyId, int ConfigPackId)
        {
            TempData["Userid"] = Userid;
            TempData["CompanyId"] = CompanyId;
            TempData["ConfigPackId"] = ConfigPackId;

            TempData.Keep();

            List<JobViewConfigModel> jType = JobTypesConfigPackRepository.Instance.GetJobTypeConfigPack(ConfigPackId, Userid);

            List<JobTypes> jobTypes = JobTypesConfigPackRepository.Instance.GetJobTypes("");

            foreach (JobTypes j in jobTypes)
            {
                foreach (JobViewConfigModel c in jType)
                {
                    if (j.strJobType == c.jobType && j.strDescription == c.Description)
                    {
                        j.Checked = true;
                        break;
                    }
                }
            }

            JobTypeMaster jobMaster = new JobTypeMaster();
            jobMaster.strJobType = "RBXXX";
            jobMaster.intUserId = Userid;
            jobMaster.intCompanyid = CompanyId;
            jobMaster.intConfigPackId = ConfigPackId;


            JobTypeViewModel job = new JobTypeViewModel();
            job.jobList = jobTypes;
            job.jobModel = jType;
            job.jobMaster = jobMaster;
            return View(job);
        }

        #endregion

        #region Private Methods
        private void BindBusinessData()
        {
            //BusinessUnitList = new List<BusinessUnit>();
            //BusinessUnitList.Add(new BusinessUnit() { Id = 1, BFCEntity = "AAATL", BusinesUnitNo = "B100", BusinessUnitName = "Madrid", LegacyName = "Business Unit", LegacyFieldName = "LocalSpec1Name", LegacyCodeOrValue = "GR210IBM / IBM IT" });
            //BusinessUnitList.Add(new BusinessUnit() { Id = 2, BFCEntity = "BBBPL", BusinesUnitNo = "B101", BusinessUnitName = "Barcelona", LegacyName = "Business Unit", LegacyFieldName = "LocalSpec1Name", LegacyCodeOrValue = "GR210MAD / MADRID" });
            //BusinessUnitList.Add(new BusinessUnit() { Id = 3, BFCEntity = "BBBPL", BusinesUnitNo = "B102", BusinessUnitName = "Seville", LegacyName = "Business Unit", LegacyFieldName = "LocalSpec1Name", LegacyCodeOrValue = "GR210MED / MEDIOS" });
            //BusinessUnitList.Add(new BusinessUnit() { Id = 4, BFCEntity = "AAATL", BusinesUnitNo = "B103", BusinessUnitName = "Valencia", LegacyName = "Business Unit", LegacyFieldName = "LocalSpec1Name", LegacyCodeOrValue = "GR210NMD / NEW MEDIA DIGITAL" });



            //listDepartmentViewmodel.Add(new DepartmentViewmodel { DeparmentMasterId = 1, DepartmentCode = "mycode1", Description = "description1", IsActive = "True", LegacyCodeOrValue = "legacycodevalue1", LegacyFieldName = "LegacyFieldname1", LegacyName = "LegacyName1" });
            //listDepartmentViewmodel.Add(new DepartmentViewmodel { DeparmentMasterId = 2, DepartmentCode = "mycode2", Description = "description2", IsActive = "True", LegacyCodeOrValue = "legacycodevalue2", LegacyFieldName = "LegacyFieldname2", LegacyName = "LegacyName2" });
        }
        #endregion
    }
}