﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Maconomy.Models;
using Maconomy.Models.Models;
using Maconomy.BusinessEntities.Models;
using Maconomy.BusinessLayer;

namespace Maconomy.Controllers
{
    public class HomeController : Controller
    {
        #region Fields
        List<CompanyGroup> CompanyGroupList;
        List<SelectListItem> CompanyGroupList1;

        List<Company> companylist = new List<Company>();

        List<User> UserList = new List<User>();
        #endregion
        public HomeController()
        {
            //BindData();
        }
        #region CompanyGroup
        public ActionResult CompanyGroup()
        {
            CompanyGroupList =  CompanyGroupRepository.Instance.GetCompanyGroups();
            return View(CompanyGroupList);
        }

        public ActionResult EditCompanyGroup(int Id)
        {
            CompanyGroupList = CompanyGroupRepository.Instance.GetCompanyGroups();
            CompanyGroup companyGroupEdit = CompanyGroupList.Where(p => p.Id == Id).FirstOrDefault();
            return View(companyGroupEdit);
        }
        [HttpPost]
        public ActionResult EditCompanyGroup(CompanyGroup CompanyGroupsave)
        {
           CompanyGroupRepository.Instance.SaveCompanyGroup(CompanyGroupsave);
            return RedirectToAction("CompanyGroup");
        }
        public ActionResult AddCompanyGroup()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddCompanyGroup(CompanyGroup CompanyGroupsave)
        {
            CompanyGroupRepository.Instance.SaveCompanyGroup(CompanyGroupsave);
            return RedirectToAction("CompanyGroup");
        }
        #endregion

        #region Company
        /// <summary>
        /// Displays the List of Companies
        /// </summary>
        /// <returns></returns>
        public ActionResult Company()
        {
            companylist = CompanyRepository.Instance.GetCompany();
           // ViewBag.VBCompanyGroupList = new SelectList(companylist, "companyGroupID", "CompanyGroupName");
            return View(companylist);
        }
        /// <summary>
        /// Used to edit a row in Company List
        /// </summary>
        /// <param name="CompanyGroupId"></param>
        /// <returns></returns>
        public ActionResult EditCompany(string Company)
        {
            companylist = CompanyRepository.Instance.GetCompany();
            Company Companyedit = companylist.Where(p => p.Id == Convert.ToInt32(Company)).FirstOrDefault();
            return View(Companyedit);
        }
        /// <summary>
        /// used for saving the edited Details of company
        /// </summary>
        /// <param name="Companysave"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult EditCompany(Company Companysave)
        {
            CompanyRepository.Instance.SaveCompany(Companysave);
            return RedirectToAction("Company");
        }
        /// <summary>
        /// Used to Add a Company
        /// </summary>
        /// <returns></returns>
        public ActionResult AddCompany()
        {
            CompanyGroupList = CompanyGroupRepository.Instance.GetCompanyGroups();
            Company comp = new BusinessEntities.Models.Company();
            comp.companyGroups = CompanyGroupList;
           // ViewBag.VBCompanyGroupList = new SelectList(CompanyGroupList, "Id", "CompanyGroup");
            return View(comp);
        }
        /// <summary>
        /// Saves the newly added company 
        /// </summary>
        /// <param name="SaveCompany"></param>
        /// <returns></returns>
        [HttpPost]
        public RedirectToRouteResult AddCompany(Company SaveCompany)
        {
            CompanyRepository.Instance.SaveCompany(SaveCompany);
            return RedirectToAction("Company");
        }
        #endregion

        #region User
        public ActionResult UserDetail()
        {
            UserList= UserRepository.Instance.GetUsers();
            //ViewBag.VBCompanyList = new SelectList(UserList, "CompanyID", "CompanyName");
            return View(UserList);
        }
        public ActionResult EditUserDetail(int Id)
        {
            UserList = UserRepository.Instance.GetUsers();
            companylist = CompanyRepository.Instance.GetCompany();
            User editUserList = UserList.Where(p => p.Id == Id).FirstOrDefault();
            editUserList.Role = UserRepository.Instance.GetRoles();
            editUserList.CompanyNames = companylist;
            return View(editUserList);
        }

        [HttpPost]
        public ActionResult EditUserDetail(User user)
        {
            UserRepository.Instance.SaveUser(user);
            return RedirectToAction("UserDetail");
        }

        public ActionResult AddUserDetail()
        {
            companylist = CompanyRepository.Instance.GetCompany();
            User user_li = new User();
            user_li.CompanyNames = companylist;
            user_li.Role = UserRepository.Instance.GetRoles();

            return View(user_li);
        }
        [HttpPost]
        public ActionResult AddUserDetail(User Usersave)
        {
            UserRepository.Instance.SaveUser(Usersave);
            return RedirectToAction("UserDetail");
        }
        #endregion


        #region Departments
        /// <summary>
        /// Displays the List of Companies
        /// </summary>
        /// <returns></returns>
        public ActionResult DepartmentMaster()
        {
            List<DepatmentMaster> DeptMaster = DepartmentMasterRepository.Instance.GetDepartmentMaster();
            return View(DeptMaster);
        }
        /// <summary>
        /// Used to edit a row in Company List
        /// </summary>
        /// <param name="CompanyGroupId"></param>
        /// <returns></returns>
        public ActionResult EditDepartmentMaster(int deptMasterId)
        {
            List<DepatmentMaster> DeptMaster = DepartmentMasterRepository.Instance.GetDepartmentMaster();
            DepatmentMaster dept = DeptMaster.Where(p => p.DeparmentMasterId == deptMasterId).FirstOrDefault();
            return View(dept);
        }
        /// <summary>
        /// used for saving the edited Details of company
        /// </summary>
        /// <param name="Companysave"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult EditDepartmentMaster(DepatmentMaster deptMaster)
        {
            DepartmentMasterRepository.Instance.SaveDeptMaster(deptMaster);
            return RedirectToAction("DepartmentMaster");
        }
        /// <summary>
        /// Used to Add a Company
        /// </summary>
        /// <returns></returns>
        public ActionResult AddDepartmentMaster()
        {
            return View();
        }
        /// <summary>
        /// Saves the newly added company 
        /// </summary>
        /// <param name="SaveCompany"></param>
        /// <returns></returns>
        [HttpPost]
        public RedirectToRouteResult AddDepartmentMaster(DepatmentMaster deptMaster)
        {
            DepartmentMasterRepository.Instance.SaveDeptMaster(deptMaster);
            return RedirectToAction("DepartmentMaster");
        }
        #endregion


        #region JobTypes
        /// <summary>
        /// Displays the List of Companies
        /// </summary>
        /// <returns></returns>
        public ActionResult JobTypeMaster()
        {
            List<JobTypeMaster> jTypeMaster = JobTypeMasterRepository.Instance.GetJobTypeMaster();
            return View(jTypeMaster);
        }
        /// <summary>
        /// Used to edit a row in Company List
        /// </summary>
        /// <param name="CompanyGroupId"></param>
        /// <returns></returns>
        public ActionResult EditJobTypeMaster(int jobId)
        {
            List<JobTypeMaster> jTypeMaster = JobTypeMasterRepository.Instance.GetJobTypeMaster();
            JobTypeMaster job = jTypeMaster.Where(p => p.intId == jobId).FirstOrDefault();
            return View(job);
        }
        /// <summary>
        /// used for saving the edited Details of company
        /// </summary>
        /// <param name="Companysave"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult EditJobTypeMaster(JobTypeMaster jobMaster)
        {
            JobTypeMasterRepository.Instance.SaveJobTypeMaster(jobMaster);
            return RedirectToAction("JobTypeMaster");
        }
        /// <summary>
        /// Used to Add a Company
        /// </summary>
        /// <returns></returns>
        public ActionResult AddJobTypeMaster()
        {
            return View();
        }
        /// <summary>
        /// Saves the newly added company 
        /// </summary>
        /// <param name="SaveCompany"></param>
        /// <returns></returns>
        [HttpPost]
        public RedirectToRouteResult AddJobTypeMaster(JobTypeMaster jobMaster)
        {
            JobTypeMasterRepository.Instance.SaveJobTypeMaster(jobMaster);
            return RedirectToAction("JobTypeMaster");
        }
        #endregion

        private void BindData()
        {

            CompanyGroupList = new List<CompanyGroup>();
            CompanyGroupList.Add(new CompanyGroup() { Id = 1, Companygroup = "Kantar", isActive = "true" });
            CompanyGroupList.Add(new CompanyGroup() { Id = 3, Companygroup = "KantarMedia", isActive = "true" });
            companylist = new List<Company>();
            companylist.Add(new Company() { Id = 09, CompanyGroupID = "1", CompanyGroup = "Kantar", CompanyName = "Encompass", isActive = "true" });
            companylist.Add(new Company() { Id = 07, CompanyGroupID = "2", CompanyGroup = "kantarmedia", CompanyName = "KantarHealth", isActive = "true" });
            UserList = new List<User>();
            UserList.Add(new User() { Id = 78, userName = "Jhon", password = "jh@12", CompanyName = "Encompass", companyID = 09,  isActive = "true" });
            UserList.Add(new User() { Id = 79, userName = "Albert", password = "al@23", CompanyName = "KantarHealth", companyID = 07,  isActive = "true" });
        }
    }
}