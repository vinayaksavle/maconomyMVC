﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Maconomy.Models;
using Maconomy.Models.Models;
using Maconomy.BusinessEntities.Models;
using Maconomy.BusinessLayer;
using System.IO;

namespace Maconomy.Controllers
{
    public class ConfigPackController : Controller
    {
        // GET: ConfigPack
        public ActionResult ConfigPack(int Userid,int CompanyId)
        {
           
            List<MaconomyConfigPack> ConfigpackList = new List<MaconomyConfigPack>();
            ConfigpackList = ConfigPackRepository.Instance.GetConfigPacks(Userid, CompanyId);
            //ConfigpackList.Add(new MaconomyConfigPack() { Id = 1, Name = "xxxxx", CompanyId = "07", CreatedOn = "06/06/2018", ModifiedOn = "06/07/2018",VersionNum="1" ,Status = "Approved" });
            return View(ConfigpackList);
        }
        public ActionResult EditConfig(int ConfigPackId,int UserId,int CompanyId)
        {
            TempData["ConfigPackId"] = ConfigPackId;

            //int Userid = Convert.ToInt32(UserId);
            //int CompanyId = Convert.ToInt32(TempData["CompanyId"]);

            TempData.Keep();
            return RedirectToAction("CompanyInformation", "User", new { Userid = UserId, CompanyID = CompanyId, ConfigPackId = ConfigPackId });
        }
        public ActionResult AddConfigPack()
        {
            User user = TempData["userdata"] as User;
            TempData["ConfigPackId"] = 0;

            TempData.Keep();

            return RedirectToAction("CompanyInformation","User", new { Userid= user.Id,CompanyID= user.companyID , ConfigPackId  = 0});
        }

        [HttpGet]
        public virtual ActionResult Download()
        {
            string file = "Maconomy.xlsx";
            string fullPath = Path.Combine(Server.MapPath("~/MyFiles"), file);
            return File(fullPath, "application/vnd.ms-excel", file);
        }
    }

    
}