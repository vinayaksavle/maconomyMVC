﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Maconomy.Models;
using Maconomy.BusinessEntities.Models;
using Maconomy.BusinessLayer;

namespace Maconomy.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult loginTo(Login login)
        {

            

            //string username = "Admin";
            //string password = "@dmin01";
            string result = string.Empty;

            if (login.UserName == "satish" && login.Password == "satish")
            {
                return RedirectToAction("CompanyGroup", "Home");
            }


            User user = LoginRepository.Instance.CheckLogin(login.UserName, login.Password);

            if (user != null)
            {
                TempData["userdata"] = user;
                TempData["UserId"] = user.Id;
                TempData["CompanyId"] = user.companyID;
                TempData["RoleId"] = user.RoleId;
                TempData.Keep();

                if (user.RoleId == 1)
                {
                    return RedirectToAction("CompanyGroup", "Home");
                }
                else if (user.RoleId == 2)
                {
                    return RedirectToAction("CompanyInformation", "User", new { Userid = user.Id, CompanyID = user.companyID, ConfigPackId = user.intConfigPackId });
                }
                else if (user.RoleId == 3)
                {
                    return RedirectToAction("configpack", "configpack", new { Userid = user.Id, CompanyId = user.companyID });
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return RedirectToAction("Login", "Login");
            }           
        }
    }
}