﻿var GridObject = function () {
    headlineFilter = "";
    summaryFilter = "";
    publicationNameFilter = "";
    publicationDateFilter = "";
    deliveredDateFilter = "";

}
var advanceFilters = {
    sampledArticle: [],
    countryFilter: [],
    languageFilter: [],
    mediaTypeFilter: [],
    scoredStatusFilter: [],
    structureValues: []

}

//This function is called to make the structure mapped icon visible or hide if the structure is mapped.
GridObject.prototype.loadStructureMappedIcon = function () {
    var elementRows = $(".jsgrid-grid-body").find("tr");
    $.each(elementRows, function (i, row) {
        var mappedStructures = $(row).children(".mappedStructures").text();
        var iconsCell = $(row).children(".gridIconCell");
        var appendTemplate = "";
        if (mappedStructures != "") {
            var array = mappedStructures.split(",");
            var template = new Template();
            var structureMapPopoverTemplate = template.gridStructureMapIconPopoverTemplate();
            $.each(array, function (i, value) {
                if (value.trim() != "") {
                    appendTemplate += structureMapPopoverTemplate.replace("{{value}}", value);
                }
            });
            var element = $(row).find(".structureMappedIcon");
            $(element).popover({
                title: globalResourceLoader.Title_StructureMappedDetails,
                html: true,
                content: appendTemplate,
                trigger: "hover",
                placement: 'left',
                ele: 'body'
            })
            //element.popover("show");
        }
        else {
            $(iconsCell).find(".structureMappedIcon").closest(".grid-icon-cell").addClass("hide");
            //$(iconsCell).find(".structureMappedIcon").addClass("hide");
        }
    });
}

//This function is called to make the structure mapped icon visible or hide if the structure is mapped.
GridObject.prototype.loadIsDeletedStructureMapping = function () {
    var elementRows = $(".jsgrid-grid-body").find("tr");
    $.each(elementRows, function (i, row) {
        var isVisible = $(row).children(".isVisible").text();
        var iconsCell = $(row).children(".gridIconCell");
        var appendTemplate = "";
        if (isVisible == "") {
            //$(iconsCell).replace("{{value}}", "This item is deleted");
            $(iconsCell).find(".delete").addClass("hide")
            $(iconsCell).find(".edit").addClass("hide")
        }
        else {
            $(iconsCell).find(".renew").addClass("hide");
            $(iconsCell).find(".deleted").addClass("hide");
        }
    });
}

GridObject.prototype.applyFilteredText = function (data) {
    $.each(data, function (i, item) {
        var name = item.key;
        var value = item.value;
        var filterColumn = $(".jsgrid-filter-row").find("[class*='" + name + "']");
        if (filterColumn.length > 0) {
            $(filterColumn).find("input").val(value);
        }
    })
    if (!$(".PublishedDate").find("input").attr("name"))
        $(".PublishedDate").find("input").attr("name", "PublishDateFilter").addClass('widget-main max-height-100 slimscroll');


    if (!$(".DeliveredDate").find("input").attr("name"))
        $(".DeliveredDate").find("input").attr("name", "DeliveredDateFilter").addClass('widget-main max-height-100 slimscroll');

    for (var visiblecolmns = 0; visiblecolmns < scoringGridModel.visibleColumns.length; visiblecolmns++) {
        var colmn = scoringGridModel.visibleColumns[visiblecolmns];
        if (scoringGridModel.visibleColumns[visiblecolmns] != "PublishedDate" && scoringGridModel.visibleColumns[visiblecolmns] != "DeliveredDate") {
            if (scoringGridModel.visibleColumns[visiblecolmns].indexOf("Name") > 0) {

                if (!$('.' + colmn.replace(/\s/g, "")).find("input").attr("name"))
                    $('.' + colmn.replace(/\s/g, "")).find("input").attr("name", colmn.replace(/\s/g, "") + "Filter").addClass('customizeFilterView');
            }
            else if (!$('.' + colmn.replace(/\s/g, "") + "Name").find("input").attr("name"))
                $('.' + colmn.replace(/\s/g, "") + "Name").find("input").attr("name", colmn.replace(/\s/g, "") + "Filter").addClass('customizeFilterView');

        }


    }


}


//This function is used to build the grid for the home page.
GridObject.prototype.loadStructureGrid = function (options) {
    options = options || {};
    var serviceId = options.serviceId;
    var clientId = options.clientId;
    var element = options.element;

    var booleanList = [
         { Name: "", Id: -1 },
         { Name: "False", Id: 0 },
         { Name: "True", Id: 1 }
    ]


    $(element).jsGrid({
        width: "100%",
        filtering: true,
        sorting: true,
        paging: true,
        autoload: true,
        pageLoading: true,
        controller: {
            loadData: function (filter) {
                $.showLoading();
                var deferred = $.Deferred();
                $.ajax({
                    url: '../Common/GetViewStructureGridData?serviceId=' + serviceId + '&clientId=' + clientId,
                    dataType: 'json',
                    type: "POST",
                    data: filter,
                    success: function (data) {
                        deferred.resolve(data);
                        var gridObject = new GridObject();
                        gridObject.loadStructureMappedIcon();
                        gridObject.applyFilteredText(data.filterAppliedText);
                        $.hideLoading();
                    },
                    error: function (err) {
                        $.errorResponseText(err).notifyError();
                        $.hideLoading();
                    }
                });
                return deferred.promise();
            }
        },
        pageSize: options.pageSize,
        pageButtonCount: 5,
        pageIndex: 1,
        noDataContent: globalResourceLoader.Alert_NoRecordFoundStructure,
        loadIndication: false,
        loadIndicationDelay: 500,
        loadMessage: globalResourceLoader.PleaseWait + "...",
        loadShading: false,
        fields: [
            { name: "StructureId", type: "number", css: "hide uniqueId" },
            { name: "SortNo", type: "number", css: "hide sortNo" },
            { name: "MappedStructures", type: "text", css: "hide mappedStructures" },
            { name: "StructureName", type: "text", title: globalResourceLoader.StructureName, css: "structureName" },
            { name: "LevelOneName", type: "text", title: globalResourceLoader.Level1, css: "levelOneName" },
            { name: "LevelTwoName", type: "text", title: globalResourceLoader.Level2, css: "levelTwoName" },
            { name: "LevelThreeName", type: "text", title: globalResourceLoader.Level3, css: "levelThreeName" },
            { name: "StructureType", type: "text", title: globalResourceLoader.StructureType },
            { name: "FieldType", type: "text", title: globalResourceLoader.FieldType },
            { name: "DataType", type: "text", title: globalResourceLoader.DataType, width: "76px" },
            { name: "HierarchyLevel", type: "number", title: globalResourceLoader.HierarchyLevel, css: "hierarchyLevel", width: "68px" },
            {
                name: "", type: "text", sorting: false, filtering: false, width: "120px", css: "gridIconCell",
                itemTemplate: function (value, item) {
                    var template = new Template();
                    var iconTemplate = template.gridIconTemplate();
                    iconTemplate = iconTemplate.replace(/{{structure_type}}/g, (item.HierarchyLevel == 0 ? "non-hierarchy" : "hierarchy"));
                    iconTemplate = iconTemplate.replace(/{{scored-value}}/g, item.IsScored);
                    return iconTemplate;
                }
            }
        ]
    });
};

//method to fetch advance filters selection
var getAdvanceFilterData = function (selectedValues) {
    var filterData = "";
    $.grep(selectedValues, function (item, i) {
        if (filterData == "") {
            filterData = item;
        }
        else {
            filterData = filterData + "," + item;
        }
    });
    return filterData;
}

var getselectedFields = function (defaultfields) {
    var defaultFieldnames = [];
    for (var field = 0; field < defaultfields.length; field++) {
        defaultFieldnames.push(defaultfields[field].name);
    }
    for (var visiblecolmns = 0; visiblecolmns < scoringGridModel.visibleColumns.length; visiblecolmns++) {
        var fname = scoringGridModel.visibleColumns[visiblecolmns];
        var fielnameExists = (defaultFieldnames.indexOf(scoringGridModel.visibleColumns[visiblecolmns]) > -1);
        if (fielnameExists == false) {
            defaultfields.splice(defaultfields.length - 1, 0, {
                name: fname, type: "text", css: fname.replace(/\s/g, "") + "Name"
                //    function () {
                //    if (visibleColumns == undefined || $.inArray(fname, visibleColumns) !== -1) {
                //        alert(fname + "-name " + fname + "Name");
                //        return fname + "-name " + fname + "Name";
                //    }
                //    else {
                //        alert(fname + "-name " + fname + "Name" + " hide");
                //        return fname + "-name " + fname + "Name" + " hide";
                //    }
                //}
            });
        }
    }

    return defaultfields;

}


var mapAllArticles = function (allArticles) {
    allAvailableArticles = allArticles;
}

var mapScoredFieldValues = function (data) {

    for (var d = 0; d < data.data.length; d++) {
        var reflst = data.data[d].ScoreUnitIdWithName;
        var splrefLst = reflst.split("-");
        var refArray = [];
        for (var ls = 0; ls < splrefLst.length; ls++) {
            if (ls == 0) continue;
            var arr = splrefLst[ls].split("|");
            refArray.push({ key: arr[0], value: arr[1] });
        }


        if ((data.data[d].StructureValues != null && data.data[d].StructureValues.length > 0)) {
            for (var svalue = 0; svalue < data.data[d].StructureValues.length; svalue++) {
                for (var s = 0; s < refArray.length; s++) {
                    if (refArray[s].value == data.data[d].StructureValues[svalue].ScoringUnitValueId) {
                        if (refArray[s].key != data.data[d].StructureValues[svalue].ScoringStructureName) {
                            if (data.data[d][refArray[s].key] != null) {
                                if (data.data[d].StructureValues[svalue].RowScoredValue != null && data.data[d].StructureValues[svalue].RowScoredValue != "")
                                    data.data[d][refArray[s].key] = data.data[d][refArray[s].key] + "," + data.data[d].StructureValues[svalue].RowScoredValue;
                            }
                            else {
                                if (data.data[d].StructureValues[svalue].RowScoredValue != null && data.data[d].StructureValues[svalue].RowScoredValue != "")
                                    data.data[d][refArray[s].key] = data.data[d].StructureValues[svalue].RowScoredValue;
                            }

                            if (data.data[d].StructureValues[svalue].ColumnScoredValue != null && data.data[d].StructureValues[svalue].ColumnScoredValue != "") {
                                if (data.data[d][refArray[s].key] != null)
                                    data.data[d][refArray[s].key] = data.data[d][refArray[s].key] + " : " + data.data[d].StructureValues[svalue].ColumnScoredValue;
                                else
                                    data.data[d][refArray[s].key] = data.data[d].StructureValues[svalue].ColumnScoredValue;
                            }

                            if (data.data[d].StructureValues[svalue].ScoringUnitValue != null && data.data[d].StructureValues[svalue].ScoringUnitValue != "") {
                                if (data.data[d][refArray[s].key] != null)
                                    data.data[d][refArray[s].key] = data.data[d][refArray[s].key] + " : " + data.data[d].StructureValues[svalue].ScoringUnitValue;
                                else
                                    data.data[d][refArray[s].key] = data.data[d].StructureValues[svalue].ScoringUnitValue;
                            }
                        }
                        else
                            data.data[d][refArray[s].key] = data.data[d].StructureValues[svalue].ScoringUnitValue;
                    }
                }

            }
        }
    }
    return data;
}


//loading article grid from elastic search
GridObject.prototype.loadScoringArticleGrid = function (options) {
    options = options || {};
    var serviceId = options.serviceId;
    var startDate = options.startDate;
    var endDate = options.endDate;
    var element = options.element;
    var visibleColumns = options.columns;
    var sampleArticleVal = getSampleArticle.sampleValue;
    var headlineFilter = this.HeadlineFilter;
    var summaryFilter = this.SummaryFilter;
    var publicationNameFiter = this.PublicationNameFilter;
    var publicationDateFilter = this.PublishDateFilter;
    var deliveredDateFilter = this.DeliveredDateFilter;
    var defaultFields = [
            {
                name: "ArticleId",
                width: "30px",
                align: "center",
                title: "",
                sorting: false,
                itemTemplate: function (value, item) {
                    //disable article checkbox if its scored
                    var formatDate = "";
                    function getMonthFromString(mon) {
                        return new Date(Date.parse(mon + " 1, 2012")).getMonth() + 1
                    }
                    if (item.DeliveredDate.trim().length != 0) {
                        var delDate = item.DeliveredDate.trim().split(" ");
                        formatDate = getMonthFromString(delDate[1]) + "/" + delDate[0] + "/" + delDate[2];
                    }
                    var template = '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-item" published-article-id=' + item.PublishedArticleId + ' article-id=' + value + ' delivered-date=' + formatDate + ' isScored="' + item.IsScored + '" ></i>';
                    //Raghav - removed disable functionality as part of bulk edit REQ 174
                    //if (item.IsScored) {
                    //    template = '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-item disable-checkbox" published-article-id=' + item.PublishedArticleId + ' article-id=' + value + ' isScored="' + item.IsScored + '" ></i>';
                    //}
                    $.each(selectedBulkScoreArticles, function (i, svDetail) {
                        if (svDetail.AssignedArticleId == item.ArticleId) {
                            template = template.replace("fa-square-o", "fa-check-square-o");
                        }
                    });
                    var div = "";
                    var element = $(template);
                    //if (item.IsScored) {
                    //    div = "<div class='scored-border' data-placement='right' data-toggle='tooltip' title='Article is scored.'></div>"
                    //}

                    switch (item.ScoredStatus) {
                        case "Not Scored":
                            ""
                            break;
                        case "Partially Scored":
                            div = "<div class='scored-border-partial' data-placement='right' data-toggle='tooltip' title='Article is partially scored.'></div>"
                            break;
                        case "Finished":
                            div = "<div class='scored-border-complete' data-placement='right' data-toggle='tooltip' title='Article is finished.'></div>"
                            break;
                    }
                    if (item.SampledStatus == "true") {
                        div += "<div class='sample-article-border' data-placement='right' data-toggle='tooltip' title='This article is flagged as random sample' data-original-title='Sample Articles'></div>";
                    }

                    return div + template;
                },
                filterTemplate: function (value, item) {
                    return '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-all-on-page" data-placement="right" data-toggle="tooltip" title="Select articles in current page (Alt + J)"></i>';
                }
                //headerTemplate: function (value, item) {
                //    //return '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-all" data-placement="right" data-toggle="tooltip" title="Select all in grid"></i>';
                //},
            },
            {
                name: "PublishedArticleId", type: "number",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("PublishedArticleId", visibleColumns) !== -1) {
                        return "published-article-id PublishedArticleId";
                    }
                    else {
                        return "published-article-id PublishedArticleId hide";
                    }
                }
            },
            {
                name: "ArticleId", type: "number", title: "Article Id", sorter: "number", align: "left", width: "50px",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("ArticleId", visibleColumns) !== -1) {
                        return "article-id ArticleId";
                    }
                    else {
                        return "article-id ArticleId hide";
                    }
                }
            },
            {
                name: "ServiceId", type: "number",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("ServiceId", visibleColumns) !== -1) {
                        return "service-id ServiceId";
                    }
                    else {
                        return "service-id ServiceId hide";
                    }
                }
            },
            {
                name: "Headline", type: "text", title: "Headline",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("Headline", visibleColumns) !== -1) {
                        return "headline HeadlineName";
                    }
                    else {
                        return "headline HeadlineName hide";
                    }
                },
                itemTemplate: function (value, item) {
                    var truncatedheadline = item.ShortHeadline;
                    var headline = value;
                    var template = new Template();
                    var headlineTemplate = template.contentTextTemplate();
                    var popoverIcon = '<i id="headline_' + item.ArticleId + '" header="Headline" class="fa fa-file content-popup headline" aria-hidden="true" data-placement="right" data-toggle="tooltip" title="View full headline"></i>';

                    headlineTemplate = headlineTemplate.replace(/{{full_text}}/, headline).replace(/{{truncated_text}}/, truncatedheadline).replace(/{{icon_popover}}/, popoverIcon);
                    return headlineTemplate;
                }
            },
            {
                name: "Summary", type: "text", title: "Summary",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("Summary", visibleColumns) !== -1) {
                        return "summary SummaryName";
                    }
                    else {
                        return "summary SummaryName hide";
                    }
                },
                itemTemplate: function (value, item) {
                    var summary = value;
                    var truncatedSummary = item.ShortSummary;
                    var template = new Template();
                    var summaryTemplate = template.contentTextTemplate();
                    //var popoverIcon = '<i id="summary_' + item.ArticleId + '" value=\"' + summary + '\" header=\"Summary\" class=\"fa fa-file content-popup summary\" aria-hidden=\"true\" data-placement=\"right\" data-toggle=\"tooltip\" title=\"View full summary\"></i>';
                    var popoverIcon = '<i id="summary_' + item.ArticleId + '" header=\"Summary\" class=\"fa fa-file content-popup summary\" aria-hidden=\"true\" data-placement=\"right\" data-toggle=\"tooltip\" title=\"View full summary\"></i>';
                    summaryTemplate = summaryTemplate.replace(/{{full_text}}/, summary).replace(/{{truncated_text}}/, truncatedSummary).replace(/{{icon_popover}}/, popoverIcon);
                    return summaryTemplate;
                }
            },
             {
                 name: "AssignedArticleText", type: "text", title: "Assigned Article Text",
                 css: function () {
                     if (visibleColumns == undefined || $.inArray("AssignedArticleText", visibleColumns) !== -1) {
                         return "assignedarticletext AssignedArticleTextName";
                     }
                     else {
                         return "assignedarticletext AssignedArticleTextName hide";
                     }
                 },
                 itemTemplate: function (value, item) {
                     var truncatedarticletext = item.ShortArticletext;
                     var articletext = value;
                     var template = new Template();
                     var articletextTemplate = template.contentTextTemplate();
                     var popoverIcon = '<i id="assignedarticletext_' + item.ArticleId + '" header="AssignedArticleText" class="fa fa-file content-popup assignedarticletext" aria-hidden="true" data-placement="right" data-toggle="tooltip" title="View full assignedarticletext"></i>';

                     articletextTemplate = articletextTemplate.replace(/{{full_text}}/, articletext).replace(/{{truncated_text}}/, truncatedarticletext).replace(/{{icon_popover}}/, popoverIcon);
                     return articletextTemplate;
                 }
             },
              {
                  name: "PublishedArticleText", type: "text", title: "Published Article Text",
                  css: function () {
                      if (visibleColumns == undefined || $.inArray("PublishedArticleText", visibleColumns) !== -1) {
                          return "publishedarticletext PublishedArticleTextName";
                      }
                      else {
                          return "publishedarticletext PublishedArticleTextName hide";
                      }
                  },
                  itemTemplate: function (value, item) {
                      var truncatedpubarticletext = item.ShortPubArticleText;
                      var publishedarticletext = value;
                      var template = new Template();
                      var pubarticletextTemplate = template.contentTextTemplate();
                      var popoverIcon = '<i id="publishedarticletext_' + item.ArticleId + '" header="PublishedArticleText" class="fa fa-file content-popup publishedarticletext" aria-hidden="true" data-placement="right" data-toggle="tooltip" title="View full publishedarticletext"></i>';

                      pubarticletextTemplate = pubarticletextTemplate.replace(/{{full_text}}/, publishedarticletext).replace(/{{truncated_text}}/, truncatedpubarticletext).replace(/{{icon_popover}}/, popoverIcon);
                      return pubarticletextTemplate;
                  }
              },
            {
                name: "PublicationName", type: "text", title: "Publication Name",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("PublicationName", visibleColumns) !== -1) {
                        return "publication-name PublicationName";
                    }
                    else {
                        return "publication-name PublicationName hide";
                    }
                }
            },
            {
                name: "PublishedDate", type: "text", title: "Published Date",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("PublishedDate", visibleColumns) !== -1) {
                        return "published-date PublishedDate";
                    }
                    else {
                        return "published-date PublishedDate hide";
                    }
                }
            },
            {
                name: "DeliveredDate", type: "text", title: "Delivered Date",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("DeliveredDate", visibleColumns) !== -1) {
                        return "delivered-date DeliveredDate";
                    }
                    else {
                        return "delivered-date DeliveredDate hide";
                    }
                }
            },
            {
                title: "Action", align: "center", width: "50px", sorting: false,
                itemTemplate: function (value, item) {
                    var template = new Template();
                    var iconTemplate = template.gridIconTemplateScoring();
                    iconTemplate = iconTemplate.replace(/{{article_id}}/g, item.ArticleId).replace(/{{service_id}}/g, item.ServiceId).replace(/{{published_article_id}}/g, item.PublishedArticleId);
                    var iconElement = $(iconTemplate);
                    if (item.IsScored) {
                        $(iconElement).find(".edit-scoring").removeClass("hide");
                        $(iconElement).find(".copy-scoring").removeClass("hide");
                    }
                    else {
                        $(iconElement).find(".edit-scoring").addClass("hide");
                        $(iconElement).find(".copy-scoring").addClass("hide");
                    }
                    return $(iconElement).html();
                }
            },
    ];

    var selectedFields = getselectedFields(defaultFields);

    $(element).jsGrid({
        width: "100%",
        filtering: true,
        sorting: true,
        paging: true,
        autoload: true,
        pageLoading: true,
        controller: {
            loadData: function (filter) {
                $.showLoading();
                filter.ServiceId = serviceId;
                filter.StartDate = startDate;
                filter.EndDate = endDate;

                //if (pageNum != filter.pageIndex && filter.pageIndex != 1) {
                //    pageNum = filter.pageIndex;
                //}
                //if (typeof (newWindow) != "undefined") {
                //    filter.pageIndex = pageNum;
                //}

                //advance filters
                var SearchQuery = getKeywordSearch.queryStringValue;
                var sampledArticle = getAdvanceFilterData(advanceFilters.sampledArticle);
                var country = getAdvanceFilterData(advanceFilters.countryFilter);
                var language = getAdvanceFilterData(advanceFilters.languageFilter);
                var mediaType = getAdvanceFilterData(advanceFilters.mediaTypeFilter);
                var scoredStatus = getAdvanceFilterData(advanceFilters.scoredStatusFilter);
                var selectedStructures = getAdvanceFilterData(advanceFilters.structureValues);
                filter.sampledArticle = sampledArticle;
                filter.country = country;
                filter.language = language;
                filter.mediaType = mediaType;
                filter.scoredStatus = scoredStatus;
                filter.selectedStructure = selectedStructures;
                filter.sampleArticleVal = sampleArticleVal;
                filter.SearchQuery = SearchQuery;
                if (filter.Headline == "" && headlineFilter != null)
                    filter.Headline = headlineFilter;
                if (filter.Summary == "" && summaryFilter != null)
                    filter.Summary = summaryFilter;
                if (filter.PublicationName == "" && publicationNameFiter != null)
                    filter.PublicationName = publicationNameFiter;

                if (filter.PublishedDate == "" && publicationDateFilter != null)
                    filter.PublishedDate = publicationDateFilter;
                if (filter.DeliveredDate == "" && deliveredDateFilter != null)
                    filter.DeliveredDate = deliveredDateFilter;

                if (isFirstTimeFilter == true) {
                    options.pageSize = 1;
                    isFirstTimeFilter = false;
                }
                //if (getScoredArticlesList.length > 0) {
                //    filter.pageIndex = pageNum;
                //}
                //else {
                //    pageNum = 1;
                //}
                var deferred = $.Deferred();
                //to load the customized column
                newPdfWindow = undefined;
                if (typeof (newWindow) != "undefined") {
                    newPdfWindow = newWindow;
                }
                $.ajax({
                    url: '../Scoring/LoadArticleGrid',
                    dataType: 'json',
                    type: "POST",
                    data: filter,
                    success: function (data) {
                        data = mapScoredFieldValues(data);
                        mapAllArticles(data.allArticles);
                        deferred.resolve(data);
                        var gridObject = new GridObject();
                        gridObject.applyFilteredText(data.filterAppliedText);
                        $.bindAdvanceFilters(data.advanceFilterData);
                        if ($(".jsgrid-table").length > 0) {
                            $(".jsgrid-table").css("width", "");
                        }
                        var partialScoredCount = data.partialScoredCount;
                        var totalCount = data.totalCount;
                        totalArticlesCount = data.totalCount;
                        var completeScoredCount = data.completeScoredCount;
                        var pageIndex = data.pageIndex;
                        var pageSize = data.pageSize;
                        var notScoredCount = totalCount - (completeScoredCount + partialScoredCount);
                        var countText = "";
                        var articelStatus = $("#scoreStatusContainer").find(".selected-row").text();
                        //if (articelStatus != "Completely Scored" || articelStatus != "Partially Scored" || articelStatus != "Unscored" || articelStatus != "Rejected Articles" || articelStatus != "Auto Scored") {
                        //    articelStatus = "All";
                        //}
                        if (articelStatus != "Finished" && articelStatus != "Partially Scored" && articelStatus != "Unscored" && articelStatus != "Rejected Articles" && articelStatus != "Auto Scored") {
                            articelStatus = "All";
                        }
                        countText = parseInt(pageIndex) == 1 ? pageIndex + "-" + pageSize : ((parseInt(pageIndex) * parseInt(pageSize)) + 1 - parseInt(pageSize)) + "-" + ((parseInt(pageIndex) * parseInt(pageSize)));
                        if (totalCount <= pageSize) {
                            countText = "";
                        }
                        if (articelStatus == "" || articelStatus == "All") {

                            countText = countText + " of " + "<mark class='bold-text'>" + totalCount + "</mark>";
                            countText = countText + "| <mark class='bold-text'>" + completeScoredCount + "</mark>" + "-Finished | " + "<mark class='bold-text'>" + partialScoredCount + "</mark class='bold-text'>" + "-Partially Scored | " + "<mark class='bold-text'>" + notScoredCount + "</mark>" + "-Not Scored";
                        }
                        else {
                            //countText = countText + " of " + "<mark class='bold-text'>" + data.data.length + "</mark>";
                            countText = countText + " of " + "<mark class='bold-text'>" + data.itemsCount + "</mark>";
                            countText = countText + " - " + articelStatus.replace(" Articles", "") + " Articles"

                        }
                        if (totalCount <= pageSize) {
                            countText = countText.replace(" of ", "Total Count: ");
                        }
                        $("#scoreCount").html(countText);
                        // SCOR-211
                        if ($(".jsgrid-header-row").find("th:first").children().length == 0) {
                            var template = '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-all-articles"  type="selectTypeValue" data-placement="right" data-toggle="tooltip" title="" data-original-title="Select all the Articles (Alt + Y)" ></i>';
                            $(".jsgrid-header-row").find("th:first").append(template);
                        }
                        if ($(".select-all-articles").closest(".fa-check-square").length > 0) {
                            $(".select-all-on-page").removeClass("fa-square-o").addClass("fa-check-square-o");
                            $(".grid-checkbox.select-item").each(function (i, item) {
                                if (!(gridViewSelection.selectionType == "copy-scoring" && $(item).closest("tr").hasClass("nav-selected-article-row"))) {
                                    $(item).removeClass("fa-square-o");
                                    $(item).addClass("fa-check-square-o");
                                }
                            });
                        }
                        if ($(".jsgrid-filter-row").find("td:first").find(".fa-check-square-o").length > 0 && ($(".select-all-articles").closest(".fa-check-square").length == 0)) {
                            $(".jsgrid-filter-row").find("td:first").find(".fa-check-square-o").removeClass("fa-check-square-o").addClass("fa-square-o");
                        }
                        //else if ($(".jsgrid-filter-row").find("td:first").find(".fa-check-square-o").length == 0 && ($(".select-all-articles").closest(".fa-check-square").length == 0) && selectedBulkScoreArticles.length > 0) {
                        //    $(".jsgrid-filter-row").find("td:first").find(".fa-square-o").removeClass("fa-square-o").addClass("fa-check-square-o");
                        //}
                        var iCnt = 0;
                        var iGridLength = $(".grid-checkbox.select-item").length;
                        $(".grid-checkbox.select-item").each(function (i, item) {
                            if ($(item).hasClass('fa-check-square-o')) {
                                iCnt++;
                            }
                        });
                        if (iGridLength == iCnt && totalCount > 0 && data.itemsCount > 0) {
                            $(".select-all-on-page").removeClass("fa-square-o").addClass("fa-check-square-o");
                        }




                        var clearFilter = $("#btnClearFilter").clone();
                        if ($(".jsgrid-filter-row").find("td:last").children().length == 0) {
                            $(".jsgrid-filter-row").find("td:last").append($(clearFilter).removeClass("hide"));
                            var customReport = $("#btnCustomReport").clone();
                            $(".jsgrid-filter-row").find("td:last").append($(customReport).removeClass("hide"));
                        }

                        //sampled Articles samplearticlesContainer
                        if ($("#samplearticlesContainer").find("#samplearticle").hasClass("selected-row")) {
                            //advanceFilters.sampledArticle = "";
                            $(".bulk-article-action[action-type='sampling']").find("i").removeClass("fa fa-random");
                            $(".bulk-article-action[action-type='sampling']").find("i").addClass("fa fa-undo");
                            $(".bulk-article-action[action-type='sampling']").attr("action-value", "undosampling");
                            $(".bulk-article-action[action-type='sampling']").attr("data-original-title", "Undo Sampling");
                            $(".bulk-article-action[action-type='pdfScoring']").closest("div").addClass("disable");
                        }
                        else {
                            if ($(".bulk-article-action").find("i").hasClass("fa-undo")) {
                                $(".bulk-article-action[action-type='sampling']").find("i").removeClass("fa fa-undo");
                                $(".bulk-article-action[action-type='sampling']").find("i").addClass("fa fa-random");
                                $(".bulk-article-action[action-type='sampling']").attr("action-value", "sampling");
                                $(".bulk-article-action[action-type='sampling']").attr("data-original-title", "Mark selected articles as sample articles");
                                $(".bulk-article-action[action-type='pdfScoring']").closest("div").removeClass("disable");
                            }
                        }

                        //rejeted articles.
                        if ($("#scoreStatusContainer").find("#ss4").hasClass("selected-row")) {
                            $(".bulk-article-action[action-type='irrelevant']").find("i").removeClass("fa-exclamatio-triangle");
                            $(".bulk-article-action[action-type='irrelevant']").find("i").addClass("fa-undo");
                            $(".bulk-article-action[action-type='irrelevant']").attr("action-value", "undoreject");
                            $(".bulk-article-action[action-type='irrelevant']").attr("data-original-title", "Undo Reject/Irrelevant");
                            $(".bulk-article-action[action-type='pdfScoring']").closest("div").addClass("disable");
                            $(".bulk-article-action[action-type='sampling']").closest("div").addClass("disable");
                        }
                        else {
                            if ($(".bulk-article-action").find("i").hasClass("fa-undo")) {
                                $(".bulk-article-action[action-type='irrelevant']").find("i").removeClass("fa-undo");
                                $(".bulk-article-action[action-type='irrelevant']").find("i").addClass("fa-exclamatio-triangle");
                                $(".bulk-article-action[action-type='irrelevant']").attr("action-value", "irrelevant");
                                $(".bulk-article-action[action-type='irrelevant']").attr("data-original-title", "Mark selected articles as Reject/Irrelevant");
                                $(".bulk-article-action[action-type='pdfScoring']").closest("div").removeClass("disable");
                                $(".bulk-article-action[action-type='sampling']").closest("div").removeClass("disable");
                            }
                        }

                        //select article for navigation scoring
                        if (typeof (newPdfWindow) != "undefined") {
                            newWindow = newPdfWindow;
                        }
                        if (typeof (newWindow) != "undefined") {
                            //pdf scoring
                            if (newWindow.title == "pdfScoring" || newWindow.name == "pdfScoring") {
                                //$.selectCurrentPdfArticles();
                                $.disablePopupClicks();
                                $.loadCurrentArticleScoreDetails();
                                $.loadCurrentArticleMetaData();
                                //$.selectCurrentGridViewRow();
                                //$.showOnly3Articles();
                                //$.setPageNumberSelected();
                            }
                                //pop up sdcoring US
                            else {
                                if (!$(".row.score-structure-container").hasClass("hide")) {
                                    $(".row.score-structure-container").addClass("hide", 500);
                                    $(".row-container.scoring-button-container").addClass("hide", 500);
                                }
                                else {
                                    $(".row.score-structure-container").removeClass("hide", 500);
                                    $(".row-container.scoring-button-container").removeClass("hide", 500);
                                }
                            }
                        }
                        //UAT Issue-4
                        //if (getScoredArticlesList.length > 0 && isScoredClick == true) {
                            //if (isBulkScoredCheck == true) {
                            //    $(".select-all-on-page").removeClass("fa-square-o").addClass("fa-check-square-o");
                            //}
                            //$.each($($("#insightGrid .jsgrid-grid-body .jsgrid-table").find(".grid-checkbox")), function (i, value) {
                            //    var articleId = $(value).attr("article-id");
                            //    $.map(getScoredArticlesList, function (elementOfArray, indexInArray) {
                            //        if (elementOfArray.AssignedArticleId == articleId) {
                            //            $(value).removeClass("fa-square-o");
                            //            $(value).addClass("fa-check-square-o");
                            //        }
                            //    });

                            //});
                       // }
                        //if (getScoredArticlesList.length == 0) {
                            //isScoredClick = false;
                        //}
                        //End of the code UAT Isssue-4
                        $(".jsgrid-table").find("tr").not(".nav-selected-article-row").find(".grid-checkbox").addClass("enable");
                        if (gridViewSelection.selectionType == "copy-scoring") {
                            $(".jsgrid-grid-body").addClass("enable");
                            $(".jsgrid-grid-body table").addClass("disable");
                            $.each($("#insightGrid").find(".jsgrid-grid-body").find("tr").find("td.article-id"), function (i, value) {
                                var copiedId = $(value).text();
                                var copiedRow = $(value).closest("tr");
                                if (copiedId == $("#btnPasteScore").attr("copied-article-id")) {
                                    $(copiedRow).find("td:first").find("i").removeClass("enable");
                                    $(copiedRow).find("td:first").find("i").addClass("disable");
                                    $(".alert-info button").click();
                                    $.notifyInfo("select articles to copy scoring to", 50000);
                                    return;
                                }
                            });
                            $("#btnPasteScore").removeClass("hide");
                            $("#btnScoreSave").addClass("hide");
                            $(".score-popup").addClass("disable");
                            $("#bulk-action-widget").addClass("disable");
                            $(".grid-icon-cell").addClass("disable");
                            //$("#ddlPageSize").addClass("disable").parent().addClass("disable");
                            $("#insightGrid").find(".jsgrid-filter-row").find("input").addClass("enable");
                            $(".jsgrid-filter-row").find("td:last").find("#btnClearFilter").addClass("enable");
                            $("#insightGrid").find(".jsgrid-pager-container").addClass("enable");
                        }
                        //$.hideLoading();
                    },
                    error: function (err) {
                        $.errorResponseText(err).notifyError();
                        $.hideLoading();
                    },
                    complete: function () {
                        $.hideLoading();
                    }
                    //complete: function () {
                    //    var a = $("#insightGrid").find(".jsgrid-grid-body").find("tr").find("td").filter(
                    //                 function (index) {
                    //                     return $(this).text() == "" && $(this).hasClass("scoredValue");
                    //                 });
                    //    a.each(function (item, i) { $(i).text("scoredValue Test") })
                    //    $.hideLoading();
                    //}
                });
                return deferred.promise();
            }
        },
        pageSize: options.pageSize,
        pageButtonCount: 5,
        pageIndex: pageNum,
        noDataContent: globalResourceLoader.NoRecordFound,
        loadIndication: false,
        loadIndicationDelay: 500,
        loadMessage: globalResourceLoader.PleaseWait + "...",
        loadShading: false,
        fields: selectedFields
    });



}



//loading article grid from elastic search
GridObject.prototype.loadScoringArticleGridCustom = function (options) {
    options = options || {};
    var serviceId = options.serviceId;
    var startDate = options.startDate;
    var endDate = options.endDate;
    var element = options.element;
    var visibleColumns = options.columns;

    var defaultFields = [
            {
                name: "ArticleId",
                width: "30px",
                align: "center",
                title: "",
                sorting: false,
                itemTemplate: function (value, item) {
                    //disable article checkbox if its scored
                    var template = '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-item" published-article-id=' + item.PublishedArticleId + ' article-id=' + value + ' isScored="' + item.IsScored + '" ></i>';
                    //Rghav - removed disable functionality as part of bulk edit REQ 174
                    //if (item.IsScored) {
                    //    template = '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-item disable-checkbox" published-article-id=' + item.PublishedArticleId + ' article-id=' + value + ' isScored="' + item.IsScored + '" ></i>';
                    //}

                    var div = "";
                    var element = $(template);

                    //if (item.IsScored) {
                    //    div = "<div class='scored-border' data-placement='right' data-toggle='tooltip' title='Article is scored.'></div>"
                    //}

                    switch (item.ScoredStatus) {
                        case "Not Scored":
                            ""
                            break;
                        case "Partially Scored":
                            div = "<div class='scored-border-partial' data-placement='right' data-toggle='tooltip' title='Article is partially scored.'></div>"
                            break;
                        case "Finished":
                            div = "<div class='scored-border-complete' data-placement='right' data-toggle='tooltip' title='Article is finished.'></div>"
                            break;
                    }
                    if (item.SampledStatus == "true") {
                        div += "<div class='sample-article-border' data-placement='right' data-toggle='tooltip' title='This article is flagged as random sample' data-original-title='Sample Articles'></div>";
                    }
                    return div + template;
                },
                filterTemplate: function (value, item) {
                    return '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-all-on-page" data-placement="right" data-toggle="tooltip" title="Select articles in current page"></i>';
                }
                //headerTemplate: function (value, item) {
                //    //return '<i class="fa fa-square-o fa-lg grid-checkbox checkbox-unchecked select-all" data-placement="right" data-toggle="tooltip" title="Select all in grid"></i>';
                //},
            },
            {
                name: "PublishedArticleId", type: "number",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("PublishedArticleId", visibleColumns) !== -1) {
                        return "published-article-id PublishedArticleId";
                    }
                    else {
                        return "published-article-id PublishedArticleId hide";
                    }
                }
            },
            {
                name: "ArticleId", type: "number", title: "Article Id", sorter: "number", align: "left", width: "50px",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("ArticleId", visibleColumns) !== -1) {
                        return "article-id ArticleId";
                    }
                    else {
                        return "article-id ArticleId hide";
                    }
                }
            },
            {
                name: "ServiceId", type: "number",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("ServiceId", visibleColumns) !== -1) {
                        return "service-id ServiceId";
                    }
                    else {
                        return "service-id ServiceId hide";
                    }
                }
            },
            {
                name: "Headline", type: "text", title: "Headline",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("Headline", visibleColumns) !== -1) {
                        return "headline HeadlineName";
                    }
                    else {
                        return "headline HeadlineName hide";
                    }
                },
                itemTemplate: function (value, item) {
                    var truncatedheadline = item.ShortHeadline;
                    var headline = value;
                    var template = new Template();
                    var headlineTemplate = template.contentTextTemplate();
                    var popoverIcon = '<i id="headline_' + item.ArticleId + '" header="Headline" class="fa fa-file content-popup headline" aria-hidden="true" data-placement="right" data-toggle="tooltip" title="View full headline"></i>';

                    headlineTemplate = headlineTemplate.replace(/{{full_text}}/, headline).replace(/{{truncated_text}}/, truncatedheadline).replace(/{{icon_popover}}/, popoverIcon);
                    return headlineTemplate;
                }
            },
            {
                name: "Summary", type: "text", title: "Summary",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("Summary", visibleColumns) !== -1) {
                        return "summary SummaryName";
                    }
                    else {
                        return "summary SummaryName hide";
                    }
                },
                itemTemplate: function (value, item) {
                    var summary = value;
                    var truncatedSummary = item.ShortSummary;
                    var template = new Template();
                    var summaryTemplate = template.contentTextTemplate();
                    //var popoverIcon = '<i id="summary_' + item.ArticleId + '" value=\"' + summary + '\" header=\"Summary\" class=\"fa fa-file content-popup summary\" aria-hidden=\"true\" data-placement=\"right\" data-toggle=\"tooltip\" title=\"View full summary\"></i>';
                    var popoverIcon = '<i id="summary_' + item.ArticleId + '" header=\"Summary\" class=\"fa fa-file content-popup summary\" aria-hidden=\"true\" data-placement=\"right\" data-toggle=\"tooltip\" title=\"View full summary\"></i>';
                    summaryTemplate = summaryTemplate.replace(/{{full_text}}/, summary).replace(/{{truncated_text}}/, truncatedSummary).replace(/{{icon_popover}}/, popoverIcon);
                    return summaryTemplate;
                }
            },
             {
                 name: "AssignedArticleText", type: "text", title: "Assigned Article Text",
                 css: function () {
                     if (visibleColumns == undefined || $.inArray("AssignedArticleText", visibleColumns) !== -1) {
                         return "assignedarticletext AssignedArticleTextName";
                     }
                     else {
                         return "assignedarticletext AssignedArticleTextName hide";
                     }
                 },
                 itemTemplate: function (value, item) {
                     var truncatedarticletext = item.ShortArticletext;
                     var articletext = value;
                     var template = new Template();
                     var articletextTemplate = template.contentTextTemplate();
                     var popoverIcon = '<i id="assignedarticletext_' + item.ArticleId + '" header="AssignedArticleText" class="fa fa-file content-popup assignedarticletext" aria-hidden="true" data-placement="right" data-toggle="tooltip" title="View full assignedarticletext"></i>';

                     articletextTemplate = articletextTemplate.replace(/{{full_text}}/, articletext).replace(/{{truncated_text}}/, truncatedarticletext).replace(/{{icon_popover}}/, popoverIcon);
                     return articletextTemplate;
                 }
             },
              {
                  name: "PublishedArticleText", type: "text", title: "Published Article Text",
                  css: function () {
                      if (visibleColumns == undefined || $.inArray("PublishedArticleText", visibleColumns) !== -1) {
                          return "publishedarticletext PublishedArticleTextName";
                      }
                      else {
                          return "publishedarticletext PublishedArticleTextName hide";
                      }
                  },
                  itemTemplate: function (value, item) {
                      var truncatedpubarticletext = item.ShortPubArticleText;
                      var publishedarticletext = value;
                      var template = new Template();
                      var pubarticletextTemplate = template.contentTextTemplate();
                      var popoverIcon = '<i id="publishedarticletext_' + item.ArticleId + '" header="PublishedArticleText" class="fa fa-file content-popup publishedarticletext" aria-hidden="true" data-placement="right" data-toggle="tooltip" title="View full publishedarticletext"></i>';

                      pubarticletextTemplate = pubarticletextTemplate.replace(/{{full_text}}/, publishedarticletext).replace(/{{truncated_text}}/, truncatedpubarticletext).replace(/{{icon_popover}}/, popoverIcon);
                      return pubarticletextTemplate;
                  }
              },
            {
                name: "PublicationName", type: "text", title: "Publication Name",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("PublicationName", visibleColumns) !== -1) {
                        return "publication-name PublicationName";
                    }
                    else {
                        return "publication-name PublicationName hide";
                    }
                }
            },
            {
                name: "PublishedDate", type: "text", title: "Published Date",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("PublishedDate", visibleColumns) !== -1) {
                        return "published-date PublishedDate";
                    }
                    else {
                        return "published-date PublishedDate hide";
                    }
                }
            },
            {
                name: "DeliveredDate", type: "text", title: "Delivered Date",
                css: function () {
                    if (visibleColumns == undefined || $.inArray("DeliveredDate", visibleColumns) !== -1) {
                        return "delivered-date DeliveredDate";
                    }
                    else {
                        return "delivered-date DeliveredDate hide";
                    }
                }
            }

    ];

    var selectedFields = getselectedFields(defaultFields);

    $(element).jsGrid({
        width: "100%",
        filtering: true,
        sorting: true,
        paging: true,
        autoload: true,
        pageLoading: true,
        controller: {
            loadData: function (filter) {
                $.showLoading();
                filter.ServiceId = serviceId;
                filter.StartDate = startDate;
                filter.EndDate = endDate;
                //advance filters
                var sampledArticle = getAdvanceFilterData(advanceFilters.sampledArticle);
                var country = getAdvanceFilterData(advanceFilters.countryFilter);
                var language = getAdvanceFilterData(advanceFilters.languageFilter);
                var mediaType = getAdvanceFilterData(advanceFilters.mediaTypeFilter);
                var scoredStatus = getAdvanceFilterData(advanceFilters.scoredStatusFilter);
                filter.sampledArticle = sampledArticle;
                filter.country = country;
                filter.language = language;
                filter.mediaType = mediaType;
                filter.scoredStatus = scoredStatus;
                var deferred = $.Deferred();
                $.ajax({
                    url: '../Scoring/LoadArticleGridCustom',
                    dataType: 'json',
                    type: "POST",
                    data: filter,
                    success: function (data) {
                        data = mapScoredFieldValues(data);
                        deferred.resolve(data);
                        var gridObject = new GridObject();
                        gridObject.applyFilteredText(data.filterAppliedText);
                        $.bindAdvanceFilters(data.advanceFilterData);
                        if ($(".jsgrid-table").length > 0) {
                            $(".jsgrid-table").css("width", "");
                        }
                        var partialScoredCount = data.partialScoredCount;
                        var totalCount = data.totalCount;
                        totalArticlesCount = data.totalCount;
                        var completeScoredCount = data.completeScoredCount;
                        var pageIndex = data.pageIndex;
                        var pageSize = data.pageSize;
                        var notScoredCount = totalCount - (completeScoredCount + partialScoredCount);
                        var countText = parseInt(pageIndex) == 1 ? pageIndex + "-" + pageSize : ((parseInt(pageIndex) * parseInt(pageSize)) + 1 - parseInt(pageSize)) + "-" + ((parseInt(pageIndex) * parseInt(pageSize)));
                        countText = countText + " of " + "<mark class='bold-text'>" + totalCount + "</mark>" + " (";
                        countText = countText + "<mark class='bold-text'>" + completeScoredCount + "</mark>" + "-Finished, " + "<mark class='bold-text'>" + partialScoredCount + "</mark class='bold-text'>" + "-Partially Scored, " + "<mark class='bold-text'>" + notScoredCount + "</mark>" + "-Not Scored";
                        $("#scoreCount").html(countText);
                        var clearFilter = $("#btnClearFilter").clone();
                        if ($(".jsgrid-filter-row").find("td:last").children().length == 0) {
                            $(".jsgrid-filter-row").find("td:last").append($(clearFilter).removeClass("hide"));
                            var customReport = $("#btnCustomReport").clone();
                            $(".jsgrid-filter-row").find("td:last").append($(customReport).removeClass("hide"));
                        }

                        $.hideLoading();
                    },
                    error: function (err) {
                        $.errorResponseText(err).notifyError();
                        $.hideLoading();
                    }
                    //complete: function () {
                    //    var a = $("#insightGrid").find(".jsgrid-grid-body").find("tr").find("td").filter(
                    //                 function (index) {
                    //                     return $(this).text() == "" && $(this).hasClass("scoredValue");
                    //                 });
                    //    a.each(function (item, i) { $(i).text("scoredValue Test") })
                    //    $.hideLoading();
                    //}
                });
                return deferred.promise();
            }
        },
        pageSize: options.pageSize,
        pageButtonCount: 5,
        pageIndex: 1,
        noDataContent: globalResourceLoader.NoRecordFound,
        loadIndication: false,
        loadIndicationDelay: 500,
        loadMessage: globalResourceLoader.PleaseWait + "...",
        loadShading: false,
        fields: selectedFields
    });



}

//This function is used to build the grid for the View Structure Mapping
GridObject.prototype.loadStructureMappingGrid = function (options) {
    options = options || {
    };
    var serviceId = options.serviceId;
    var clientId = options.clientId;
    var element = options.element;

    var booleanList = [
             {
                 Name: "", Id: -1
             },
             {
                 Name: "False", Id: 0
             },
                 { Name: "True", Id: 1 }
    ]
    $(element).jsGrid({
        width: "100%",
        filtering: true,
        sorting: true,
        paging: true,
        autoload: true,
        pageLoading: true,
        controller: {
            loadData: function (filter) {
                $.showLoading();
                filter.ServiceId = serviceId;
                filter.ClientId = clientId;
                var deferred = $.Deferred();
                $.ajax({
                    url: '../StructureMapping/GetMappedStructuresByServiceId',
                    dataType: 'json',
                    type: "POST",
                    data: filter,
                    success: function (data) {
                        deferred.resolve(data);
                        var gridObject = new GridObject();
                        gridObject.loadIsDeletedStructureMapping();
                        gridObject.applyFilteredText(data.filterAppliedText);
                        if ($(".jsgrid-table").length > 0) {
                            $(".jsgrid-table").css("width", "");
                        }
                        $.hideLoading();
                    },
                    error: function (err) {
                        $.errorResponseText(err).notifyError();
                        $.hideLoading();
                    }
                });
                return deferred.promise();
            }
        },
        pageSize: options.pageSize,
        pageButtonCount: 5,
        pageIndex: 1,
        noDataContent: globalResourceLoader.Alert_NoRecordFoundStructureMapping,
        loadIndication: false,
        loadIndicationDelay: 500,
        loadMessage: globalResourceLoader.PleaseWait + "...",
        loadShading: false,
        fields: [
            {
                name: "StructureMappingId", type: "number", css: "hide uniqueId StructureMappingId"
            },
            {
                name: "ScoringUnitStructureId", type: "number", css: "hide ScoringUnitStructureId"
            },
            {
                name: "RowStructureId", type: "number", css: "hide RowStructureId"
            },
            {
                name: "ColumnStructureId", type: "number", css: "hide ColumnStructureId"
            },
            {
                name: "IsVisible", type: "text", css: "hide isVisible"
            },
            {
                name: "StructureMappingName", type: "text", title: globalResourceLoader.StructureMappingName, css: "structuremappingname"
            },
            {
                name: "ScoringUnitStructureName", type: "text", title: globalResourceLoader.StructureMappingScoringunit, css: "scoringunit"
            },
            {
                name: "RowStructureName", type: "text", title: globalResourceLoader.StructureMappingRowDimension, css: "levelOneName"
            },
            {
                name: "ColumnStructureName", type: "text", title: globalResourceLoader.StructureMappingColumnDimension, css: "levelTwoName"
            },
            {
                name: "LatestActionBy", type: "text", title: globalResourceLoader.LastActionBy, css: "LatestActionBy", width: "120px"
            },
            {
                name: "LatestActionDateTime", type: "text", title: globalResourceLoader.LastActionDate, css: "LatestActionTimestamp"
            },
            {
                name: "DimensionCount", type: "number", css: "hide dimensioncount", title: globalResourceLoader.Title_DimensionCount
            },
            {
                name: "ServiceId", type: "number", css: "hide"
            },
            {
                name: "ClientId", type: "number", css: "hide"
            },
            {
                name: "", type: "text", sorting: false, filtering: false, css: "gridIconCell",
                itemTemplate: function (value, item) {
                    var template = new Template();
                    var element = $(template.gridIconTemplateStructureMapping());
                    if (!item.IsVisible) {
                        $(element).find(".mapping-disable").closest("div").removeClass("hide");
                        $(element).find(".mapping-enable").closest("div").addClass("hide");
                        $(element).find(".edit-mapping").closest("div").addClass("hide");
                    }
                    else {
                        $(element).find(".mapping-disable").closest("div").addClass("hide");
                        $(element).find(".mapping-enable").closest("div").removeClass("hide");
                        $(element).find(".edit-mapping").closest("div").removeClass("hide");
                    }
                    if (item.IsScored) {
                        $(element).find(".mapping-scored").closest("div").removeClass("hide");
                    }
                    else {
                        $(element).find(".mapping-scored").closest("div").addClass("hide");
                    }

                    return element.html();
                }
            }
        ]
    });
    //Use this to convert JSON date format to date time format within the grid
    function parsedate(jsonstring) {
        var str, year, month, day, hour, minute, d, finalDate;
        str = jsonstring.replace(/\D/g, "");
        d = new Date(parseInt(str));
        year = d.getFullYear();
        month = pad(d.getMonth() + 1);
        day = pad(d.getDate());
        hour = pad(d.getHours());
        minutes = pad(d.getMinutes());
        finalDate = year + "-" + month + "-" + day + " " + hour + ":" + minutes;
        return finalDate;
    }
    function pad(num) {
        num = "0" + num;
        return num.slice(-2);
    }
};

