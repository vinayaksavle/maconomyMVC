﻿$(function () {
    var highlightSelectedMenu = function () {
        $("ul#menu li").siblings().removeClass("active");
        var element = $("ul#menu li").find("[name='manageusers']").closest("li");
        element.addClass("active");

        //$.ajax({
        //    url: "../Home/GetMenuContent",

        //    type: "POST",
        //    dataType: "JSON",
        //    data: {
        //        'identity': 1,

        //    },
        //    success: function (result) {

        //        if (result.isManageRoster == false) {

        //            $('.rosterDiv').addClass('disable');
        //            $('.rosterDiv').attr('href', '#');


        //        }
        //        if (result.isAllinFunction == false) {
        //            $('.setAllTmDiv').addClass('disable');
        //            $('.setAllTmDiv').attr('href', '#');
        //        }
        //    },
        //    error: function (err) {
        //        $.errorResponseText(err).notifyError();

        //    }
        //});
    };

    highlightSelectedMenu();
    var GridObject = function () { }

    GridObject.prototype.loadUserGrid = function (options) {
        options = options || {};
        var element = options.element;
        var booleanList = [
             { Name: "", Id: -1 },
             { Name: "False", Id: 0 },
             { Name: "True", Id: 1 }
        ]
        $(element).jsGrid({
            width: "100%",
            filtering: true,
            sorting: true,
            editing: false,
            paging: false,
            autoload: true,
            pageLoading: true,            
            controller: {
                loadData: function (filter) {
                    var deferred = $.Deferred();
                    $.ajax({
                        url: '../User/JobType',
                        dataType: 'json',
                        type: "POST",
                        data: filter,
                        success: function (data) {
                            deferred.resolve(data);
                        },
                        error: function (ex) {
                            ex.responseJSON.Message.notifyError();
                        }
                    });
                    return deferred.promise();
                },
                deleteItem: function (item) {
                    return $.ajax({
                        type: "DELETE",
                        url: "../home/DeleteUser?Id=" + item.Id,
                        dataType: 'json',
                        type: "POST",
                        data: item
                    });
                    return deferred.promise();
                },
                updateItem: function (item) {
                    var d = $.Deferred();
                    return $.ajax({
                        type: "POST",
                        url: "../home/UpdateUser",
                        data: item
                    }).done(function (updatedItemReturnedFromServer) {
                        d.resolve(updatedItemReturnedFromServer);
                    });
                    return deferred.promise();
                }
            },
            pageSize: 10,
            pageButtonCount: 5,
            pageIndex: 1,
            noDataContent: 'No data found',
            loadIndication: false,
            loadIndicationDelay: 500,
            loadMessage: "Please Wait...",
            loadShading: false,
            fields: [
                { name: "intId", type: "text", title: "intId", css: "hidden intId" },
                { name: "chk", type: "checkbox", title: "Select" },
                { name: "strJobType", type: "text", title: "Job Type" },
                { name: "strDescription", type: "text", title: "Description" },
                { name: "bitIsActive", type: "text", title: "Active" },                                
                {
                    type: "control", width: 100,
                    modeSwitchButton: false,
                    editButton: false,
                    itemTemplate: function (value, item) {
                        var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                        var template = new Template();
                        var $customButton = template.gridIconTemplate();
                        $customButton = $customButton.replace(/{{id}}/g, item.Id);
                        return $result.add($customButton);
                    }
                },
            ]
        });
    }


    var loadGridView = function () {
        $("#jsGrid").empty();
        var gridObject = new GridObject();
        gridObject.loadUserGrid(
        {
            element: $("#jsGrid"),
            pageSize: 10
        });
    }

    loadGridView();



    $(document).on("click", ".edituser", function () {
        var userid = $(this).closest('span').attr("UserID");
        var EditUserURL = "../Home/EditUser?userid=" + userid;
        window.location.href = EditUserURL;
        //$.ajax({
        //    url: "../Home/AddUser",
        //    type: "GET",
        //    dataType: "HTML",
        //    data: {
        //        'userid': userid
        //    },
        //    success: function (data) {
        //             window.location.href = "../Home/AddUser";
        //    },
        //    error: function (errMsg)
        //    {
        //       // window.location.href = "../Home/AddUser";
        //    }
        //});

    })

    $(document).on("click", ".servicemapping", function () {
        var userid = $(this).closest('span').attr("UserID");
        var EditUserURL = "../Mapping/EditUserService?userid=" + userid;
        window.location.href = EditUserURL;
    })

    //common parsedate functionality
    function parsedate(jsonstring) {
        var str, year, month, day, hour, minute, d, finalDate;
        str = jsonstring.replace(/\D/g, "");
        d = new Date(parseInt(str));
        year = d.getFullYear();
        month = pad(d.getMonth() + 1);
        day = pad(d.getDate());
        hour = pad(d.getHours());
        minutes = pad(d.getMinutes());
        finalDate = year + "-" + month + "-" + day + " " + hour + ":" + minutes;
        return finalDate;
    }

    function pad(num) {
        num = "0" + num;
        return num.slice(-2);
    }


    $("#btnSave").on("click", function () {
        if (!validateusernamepassword()) {
            return false;
        }
    });

});

