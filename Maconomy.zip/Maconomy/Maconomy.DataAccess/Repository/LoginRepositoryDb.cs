﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class LoginRepositoryDb
    {
        private static LoginRepositoryDb _instance;

        public static LoginRepositoryDb Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new LoginRepositoryDb();
                }
                return _instance;
            }
        }


        public User CheckLogin(string userName,string password)
        {


            IEnumerable<User> user = new List<User>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {

                SqlParameter[] parameters = new SqlParameter[]
                {
                     new SqlParameter("@strUserName", SqlDbType.NVarChar){ Value = userName },
                     new SqlParameter("@strPassword", SqlDbType.NVarChar){ Value = password }
                };

                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_ValidateUser, CommandType.StoredProcedure, parameters);
                var results = reader.Select(dataRecord => new User()
                {
                    Id = Convert.ToInt32(dataRecord["Id"]),
                    RoleId = Convert.ToInt32(dataRecord["roleId"]),
                    companyID = Convert.ToInt32(dataRecord["companyID"]),
                    CompanyName = Convert.ToString(dataRecord["username"]),
                    intConfigPackId = Convert.ToInt32(dataRecord["intConfigPackId"])
                }).ToList();

                if (results.Count > 0)
                    return results.First();
                else
                    return null;
               
            }

            
        }
        
    }
}
