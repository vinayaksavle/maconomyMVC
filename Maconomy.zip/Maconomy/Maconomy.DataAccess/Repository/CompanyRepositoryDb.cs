﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class CompanyRepositoryDb
    {
        private static CompanyRepositoryDb _instance;

        public static CompanyRepositoryDb Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new CompanyRepositoryDb();
                }
                return _instance;
            }
        }


        public List<Company> GetCompany()
        {
            IEnumerable<Company> companyGroup = new List<Company>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                companyGroup = sqlDataHelper.ExecuteReader<Company>(StoredProcedures.SP_GetAllCompany, CommandType.StoredProcedure);
            }
            return companyGroup.ToList();
        }


        public string SaveCompany(Company company)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {                    
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add<int>("Id", company.Id);
                    parameters.Add<string>("CompanyGroupId", company.CompanyGroupID);
                    parameters.Add<string>("CompanyGroupName", Convert.ToString(company.CompanyGroup));
                    parameters.Add<string>("CompanyName", company.CompanyName);
                    parameters.Add<string>("IsActive", company.Active.ToString());


                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveCompany, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }



    }
}
