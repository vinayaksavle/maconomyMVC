﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class UserRepositoryDb
    {
        private static UserRepositoryDb _instance;

        public static UserRepositoryDb Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserRepositoryDb();
                }
                return _instance;
            }
        }


        public List<User> GetUsers()
        {
            IEnumerable<User> userList = new List<User>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                List<SqlParameter> parameters = new List<SqlParameter>();

                userList = sqlDataHelper.ExecuteReader<User>(StoredProcedures.SP_GetAllUsers, CommandType.StoredProcedure);
            }
            return userList.ToList();
        }


        public string SaveUser(User user)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {                    
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add<int>("Id", user.Id);
                    parameters.Add<string>("UserName", user.userName);
                    parameters.Add<string>("Password", user.password);
                    parameters.Add<int>("CompanyId", user.companyID);
                    parameters.Add<string>("CompanyName", user.CompanyName);
                    parameters.Add<int>("RoleId", user.RoleId);
                    parameters.Add<string>("IsActive", user.isActive);

                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveUser, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }



    }
}
