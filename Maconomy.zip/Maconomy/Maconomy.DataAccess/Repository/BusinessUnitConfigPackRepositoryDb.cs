﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class BusinessUnitConfigPackRepositoryDb
    {
        private static BusinessUnitConfigPackRepositoryDb _instance;

        public static BusinessUnitConfigPackRepositoryDb Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new BusinessUnitConfigPackRepositoryDb();
                }
                return _instance;
            }
        }



        public IEnumerable<BusinessUnit> GetBussinessUnit(int ConfigPackId, int UserId, int CompanyId)
        {
            IEnumerable<BusinessUnit> bUnitList = new List<BusinessUnit>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                SqlParameter[] parameters = new SqlParameter[]
                 {
                     new SqlParameter("@ConfigPackId", SqlDbType.Int){ Value = ConfigPackId },
                     new SqlParameter("@UserId", SqlDbType.Int){ Value = UserId },
                     new SqlParameter("@BId", SqlDbType.Int){ Value = 0 }
                 };

                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_GetBusinessUnitInfoConfigPack, CommandType.StoredProcedure, parameters);
                var results = reader.Select(dataRecord => new BusinessUnit()
                {
                    intId = Convert.ToInt32(dataRecord["intId"]),
                    strBFCEntity = Convert.ToString(dataRecord["strBFCEntity"]),
                    strBusinessUnitName = Convert.ToString(dataRecord["strBusinessUnitName"]),
                    strBusinesUnitNo = Convert.ToString(dataRecord["strBusinesUnitNo"]),
                    intConfigPackId = Convert.ToInt32(dataRecord["intConfigPackId"]),
                    strBU_LegacyCodeOrValue = Convert.ToString(dataRecord["strBU_LegacyCodeOrValue"]),
                    strBU_LegacyFieldName = Convert.ToString(dataRecord["strBU_LegacyFieldName"]),
                    strBU_LegacyName = Convert.ToString(dataRecord["strBU_LegacyName"])

                }).ToList();


                return results;
            }
        }

        public BusinessUnit EditBussinessUnit(int ConfigPackId, int UserId, int CompanyId, int Id)
        {
            IEnumerable<BusinessUnit> bUnitList = new List<BusinessUnit>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                SqlParameter[] parameters = new SqlParameter[]
                 {
                     new SqlParameter("@ConfigPackId", SqlDbType.Int){ Value = ConfigPackId },
                     new SqlParameter("@UserId", SqlDbType.Int){ Value = UserId },
                     new SqlParameter("@BId", SqlDbType.Int){ Value = Id }
                     
                 };

                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_GetBusinessUnitInfoConfigPack, CommandType.StoredProcedure, parameters);
                var results = reader.Select(dataRecord => new BusinessUnit()
                {
                    intId = Convert.ToInt32(dataRecord["intId"]),
                    strBFCEntity = Convert.ToString(dataRecord["strBFCEntity"]),
                    strBusinessUnitName = Convert.ToString(dataRecord["strBusinessUnitName"]),
                    strBusinesUnitNo = Convert.ToString(dataRecord["strBusinesUnitNo"]),
                    intConfigPackId = Convert.ToInt32(dataRecord["intConfigPackId"]),
                    strBU_LegacyCodeOrValue = Convert.ToString(dataRecord["strBU_LegacyCodeOrValue"]),
                    strBU_LegacyFieldName = Convert.ToString(dataRecord["strBU_LegacyFieldName"]),
                    strBU_LegacyName = Convert.ToString(dataRecord["strBU_LegacyName"])

                }).ToList().First();


                return results;
            }
        }

        public static DataTable ObjectToData(object o)
        {
            DataTable dt = new DataTable("OutputData");

            DataRow dr = dt.NewRow();
            dt.Rows.Add(dr);

            o.GetType().GetProperties().ToList().ForEach(f =>
            {
                try
                {
                    f.GetValue(o, null);
                    dt.Columns.Add(f.Name, typeof(string));
                    object value = f.GetValue(o, null);
                    dt.Rows[0][f.Name] = Convert.ToString(value);
                }
                catch (Exception ex) { }
            });
            return dt;

        }
        public string SaveBussinessUnit(BusinessUnit busUnit,int UserId)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    DataTable dt = ObjectToData(busUnit);

                    List<SqlParameter> parameters = new List<SqlParameter>();
                    DataTable dtBunit = dt.DefaultView.ToTable(false, new string[] { "intId" ,    "intConfigPackId",  "strBFCEntity",
                    "strBusinesUnitNo",    "strBusinessUnitName" ,   "strBU_LegacyName" ,   "strBU_LegacyFieldName", "strBU_LegacyCodeOrValue"});
                  
                    parameters.Add<DataTable>("BusinessUnit", dtBunit);
                    parameters.Add<int>("intUserId", UserId);

                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveBusinessUnitConfigPack, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }



    }
}
