﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class DepartmentConfigPackRepositoryDb
    {
        private static DepartmentConfigPackRepositoryDb _instance;

        public static DepartmentConfigPackRepositoryDb Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DepartmentConfigPackRepositoryDb();
                }
                return _instance;
            }
        }

        public IEnumerable<DepatmentMaster> GetDepartmentMaster()
        {
            IEnumerable<DepatmentMaster> department = new List<DepatmentMaster>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_GetDepartmentMaster, CommandType.StoredProcedure, null);
                var results = reader.Select(dataRecord => new DepatmentMaster()
                {
                    DeparmentMasterId = Convert.ToInt32(dataRecord["DeparmentMasterId"]),
                    DepartmentCode = Convert.ToString(dataRecord["strDepartmentCode"]),
                    Description = Convert.ToString(dataRecord["strDescription"]),
                    IsActive = Convert.ToString(dataRecord["bitIsActive"]),
                    bitIsApproved = Convert.ToBoolean(dataRecord["bitIsApproved"])

                }).ToList();


                return results;
            }
        }

        public IEnumerable<DepartmentViewmodel> GetDepartment(int ConfigPackId, int UserId,int CompanyId)
        {
            IEnumerable<Department> department = new List<Department>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                SqlParameter[] parameters = new SqlParameter[]
                 {
                     new SqlParameter("@ConfigPackId", SqlDbType.Int){ Value = ConfigPackId },
                     new SqlParameter("@UserId", SqlDbType.Int){ Value = UserId },
                     new SqlParameter("@Id", SqlDbType.Int){ Value = 0 }
                 };

                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_GetDepartmentConfigPack, CommandType.StoredProcedure, parameters);
                var results = reader.Select(dataRecord => new DepartmentViewmodel()
                {
                    intId = Convert.ToInt32(dataRecord["intId"]),
                    intDeparmentMasterId = Convert.ToInt32(dataRecord["intDeparmentMasterId"]),
                    intConfigPackId = Convert.ToInt32(dataRecord["intConfigPackId"]),
                    strLegacyCodeOrValue = Convert.ToString(dataRecord["strLegacyCodeOrValue"]),
                    strLegacyFieldName = Convert.ToString(dataRecord["strLegacyFieldName"]),
                    strLegacyName = Convert.ToString(dataRecord["strLegacyName"]),
                    DepartmentCode = Convert.ToString(dataRecord["DepartmentCode"]),
                    Description = Convert.ToString(dataRecord["Description"]),
                    IsApproved = Convert.ToBoolean(dataRecord["bitIsApproved"])

                }).ToList();


                return results;
            }
        }

        public DepartmentViewmodel EditDepartment(int ConfigPackId, int UserId, int CompanyId,int Id)
        {
            IEnumerable<Department> department = new List<Department>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                SqlParameter[] parameters = new SqlParameter[]
                 {
                     new SqlParameter("@ConfigPackId", SqlDbType.Int){ Value = ConfigPackId },
                     new SqlParameter("@UserId", SqlDbType.Int){ Value = UserId },
                     new SqlParameter("@Id", SqlDbType.Int){ Value = Id }
                 };

                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_GetDepartmentConfigPack, CommandType.StoredProcedure, parameters);
                var results = reader.Select(dataRecord => new DepartmentViewmodel()
                {
                    intId = Convert.ToInt32(dataRecord["intId"]),
                    intDeparmentMasterId = Convert.ToInt32(dataRecord["intDeparmentMasterId"]),
                    intConfigPackId = Convert.ToInt32(dataRecord["intConfigPackId"]),
                    strLegacyCodeOrValue = Convert.ToString(dataRecord["strLegacyCodeOrValue"]),
                    strLegacyFieldName = Convert.ToString(dataRecord["strLegacyFieldName"]),
                    strLegacyName = Convert.ToString(dataRecord["strLegacyName"]),
                    DepartmentCode = Convert.ToString(dataRecord["DepartmentCode"]),
                    Description = Convert.ToString(dataRecord["Description"])

                }).ToList().First();


                return results;
            }
        }
        public static DataTable ObjectToData(object o)
        {
            DataTable dt = new DataTable("OutputData");

            DataRow dr = dt.NewRow();
            dt.Rows.Add(dr);

            o.GetType().GetProperties().ToList().ForEach(f =>
            {
                try
                {
                    f.GetValue(o, null);
                    dt.Columns.Add(f.Name, typeof(string));
                    object value = f.GetValue(o, null);
                    dt.Rows[0][f.Name] = Convert.ToString(value);
                }
                catch (Exception ex) { }
            });
            return dt;

        }

        public string SaveDepartment(DepartmentViewmodel department,int UserId)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    DataTable dt = ObjectToData(department);
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    DataTable dtDept = dt.DefaultView.ToTable(false, new string[] { "intId" ,    "intConfigPackId",  "intDeparmentMasterId",
                    "strDepartmentName",    "strLegacyName" ,   "strLegacyFieldName" , "strLegacyCodeOrValue"});

                    parameters.Add<DataTable>("Department", dtDept);
                    parameters.Add<int>("intUserId", UserId);

                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveDepartmentConfigPack, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }



    }
}
