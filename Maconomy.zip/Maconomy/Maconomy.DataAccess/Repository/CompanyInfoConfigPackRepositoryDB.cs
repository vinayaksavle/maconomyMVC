﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;
using System.Collections;

namespace Maconomy.DataAccess.Repository
{
    public class CompanyInfoConfigPackRepositoryDB
    {
        private static CompanyInfoConfigPackRepositoryDB _instance;

        public static CompanyInfoConfigPackRepositoryDB Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new CompanyInfoConfigPackRepositoryDB();
                }
                return _instance;
            }
        }


        public CompanyInformation EditComapnyInfo(int ConfigPackId, int UserId,int CompanyId)
        {
            IEnumerable<CompanyInformation> companyGroup = new List<CompanyInformation>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                SqlParameter[] parameters = new SqlParameter[]
               {
                     new SqlParameter("@ConfigPackId", SqlDbType.Int){ Value = ConfigPackId },
                     new SqlParameter("@UserId", SqlDbType.Int){ Value = UserId }
               };

                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_GetCompnayInfoConfigPack, CommandType.StoredProcedure, parameters);
                var results = reader.Select(dataRecord => new CompanyInformation()
                {
                    intId = Convert.ToInt32(dataRecord["intId"]),
                    UserId = Convert.ToInt32(dataRecord["intUserId"]),
                    ConfigPackId = Convert.ToInt32(dataRecord["intConfigPackId"]),
                    strLegacyID = Convert.ToString(dataRecord["strLegacyID"]),
                    strCompanyName = Convert.ToString(dataRecord["strCompanyName"]),
                    strStreetAddress1 = Convert.ToString(dataRecord["strStreetAddress1"]),
                    strStreetAddress2 = Convert.ToString(dataRecord["strStreetAddress2"]),
                    strStreetAddress3 = Convert.ToString(dataRecord["strStreetAddress3"]),
                    strArea_County_State = Convert.ToString(dataRecord["strArea_County_State"]),
                    strPostal_Code = Convert.ToString(dataRecord["strPostal_Code"]),
                    strPostalDistrictOrCity = Convert.ToString(dataRecord["strPostalDistrictOrCity"]),
                    //strCountry =(Country)(dataRecord["strCountry"]),
                    strMaconomyOrganisation_StructureType = Convert.ToString(dataRecord["strMaconomyOrganisation_StructureType"]),
                    strLegalEntityName = Convert.ToString(dataRecord["strLegalEntityName"]),
                    //strBaseCurrency = (Currency)(dataRecord["strBaseCurrency"]),
                    strPhone = Convert.ToString(dataRecord["strPhone"]),
                    strFax = Convert.ToString(dataRecord["strFax"]),
                    strCompanyRegistrationNo = Convert.ToString(dataRecord["strCompanyRegistrationNo"]),
                    strTaxNo = Convert.ToString(dataRecord["strTaxNo"]),
                    strPANNo = Convert.ToString(dataRecord["strPANNo"]),
                    strTANNo = Convert.ToString(dataRecord["strTANNo"]),
                    strBFCNo = Convert.ToString(dataRecord["strBFCNo"]),
                    //strWPPofficecodeEntity = (WPPOfficeCodeEntity)(dataRecord["strWPPofficecodeEntity"]),
                    strManagingDirector_Empl_1 = Convert.ToString(dataRecord["strManagingDirector_Empl_1"]),
                    strFinance_Director_Empl_2 = Convert.ToString(dataRecord["strFinance_Director_Empl_2"]),
                    strCFO_Empl_3 = Convert.ToString(dataRecord["strCFO_Empl_3"]),
                    strCEO_Empl_4 = Convert.ToString(dataRecord["strCEO_Empl_4"]),
                    strStandardWeeklyhours = Convert.ToString(dataRecord["strStandardWeeklyhours"]),
                   // strMandatoryMin_TimeSheetHours = (TimesheetHours)(dataRecord["strMandatoryMin_TimeSheetHours"]),
                    //strUsing_Maconomy_Absence_Management_tool =(MaconomyAbsence)(dataRecord["strUsing_Maconomy_Absence_Management_tool"]),
                    strOtherKey_Info = Convert.ToString(dataRecord["strOtherKey_Info"]),
                    strAdditional_Comments = Convert.ToString(dataRecord["strAdditional_Comments"]),
                }).ToList().First();
                return results;
            }
            
        }

        public static DataTable ObjectToData(object o)
        {
            DataTable dt = new DataTable("OutputData");

            DataRow dr = dt.NewRow();
            dt.Rows.Add(dr);

            o.GetType().GetProperties().ToList().ForEach(f =>
            {
                try
                {
                    f.GetValue(o, null);
                    dt.Columns.Add(f.Name , typeof(string));
                    object value = f.GetValue(o, null);        
                    dt.Rows[0][f.Name] = Convert.ToString(value);
                }
                catch (Exception ex) {  }
            });
            return dt;
           
        }

        public string SaveCompanyInfo(CompanyInformation companyInfo, int ConfigPackId, int UserId, int CompanyId)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    DataTable dt = ObjectToData(companyInfo);

                    List<SqlParameter> parameters = new List<SqlParameter>();
                    DataTable dtCompanyInfo = dt.DefaultView.ToTable(false, new string[] { "intId" ,	"strLegacyID", 	"strCompanyName",
                    "strStreetAddress1",	"strStreetAddress2" ,	"strStreetAddress3" ,	"strArea_County_State",	"strPostal_Code",
                    "strPostalDistrictOrCity",	"strCountry",	"strMaconomyOrganisation_StructureType",    "strLegalEntityName",
                    "strBaseCurrency",    "strPhone",   "strFax", "strCompanyRegistrationNo",   "strTaxNo",   "strPANNo",   "strTANNo",
                    "strBFCNo" ,  "strWPPofficecodeEntity", "strManagingDirector_Empl_1",    "strFinance_Director_Empl_2", "strCFO_Empl_3",
                    "strCEO_Empl_4",  "strStandardWeeklyhours", "strMandatoryMin_TimeSheetHours", "strUsing_Maconomy_Absence_Management_tool",
                        "strOtherKey_Info" ,  "strAdditional_Comments" });
                    parameters.Add<int>("intConfigPackId", ConfigPackId);
                    parameters.Add<int>("intUserId", UserId);
                    parameters.Add<int>("CompanyId", CompanyId);
                    parameters.Add<DataTable>("CompanyInfo", dtCompanyInfo);

                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveCompanyInfoConfigPack, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }



    }
}
