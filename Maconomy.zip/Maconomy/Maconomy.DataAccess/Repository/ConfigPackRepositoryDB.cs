﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class ConfigPackRepositoryDB
    {
        private static ConfigPackRepositoryDB _instance;

        public static ConfigPackRepositoryDB Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new ConfigPackRepositoryDB();
                }
                return _instance;
            }
        }


        public List<MaconomyConfigPack> GetConfigPacks(int UserId, int CompanyId)
        {
            IEnumerable<MaconomyConfigPack> userList = new List<MaconomyConfigPack>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add<int>("CompanyId", CompanyId);
                parameters.Add<int>("UserId", UserId);


                userList = sqlDataHelper.ExecuteReader<MaconomyConfigPack>(StoredProcedures.SP_GetUserConfigPack, CommandType.StoredProcedure, parameters);
            }
            return userList.ToList();
        }



    }
}
