﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class JobTypesConfigPackRepositoryDb
    {
        private static JobTypesConfigPackRepositoryDb _instance;

        public static JobTypesConfigPackRepositoryDb Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new JobTypesConfigPackRepositoryDb();
                }
                return _instance;
            }
        }

        public List<JobTypes> GetJobTypes(string search)
        {
            IEnumerable<JobTypes> bUnitList = new List<JobTypes>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {

                SqlParameter[] parameters = new SqlParameter[]
                {
                     new SqlParameter("@search", SqlDbType.NVarChar){ Value = search },
                     
                };
                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_GetJobTypes, CommandType.StoredProcedure, parameters);
                var results = reader.Select(dataRecord => new JobTypes()
                {
                    intId = Convert.ToInt32(dataRecord["intId"]),
                    strJobType = Convert.ToString(dataRecord["strJobType"]),
                    strDescription = Convert.ToString(dataRecord["strDescription"]),
                    bitIsActive = Convert.ToString(dataRecord["bitIsActive"])

                }).ToList();


                return results;
            }
        }

        public List<JobViewConfigModel> GetJobTypeConfigPack(int ConfigPackId, int UserId)
        {
            IEnumerable<JobViewConfigModel> bUnitList = new List<JobViewConfigModel>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                SqlParameter[] parameters = new SqlParameter[]
                 {
                     new SqlParameter("@ConfigPackId", SqlDbType.Int){ Value = ConfigPackId },
                     new SqlParameter("@UserId", SqlDbType.Int){ Value = UserId }                     
                 };

                var reader = sqlDataHelper.ExecuteReader(StoredProcedures.SP_GetJobTypeConfigPack, CommandType.StoredProcedure, parameters);
                var results = reader.Select(dataRecord => new JobViewConfigModel()
                {
                    intId = Convert.ToInt32(dataRecord["intId"]),
                    intConfigPackId = Convert.ToInt32(dataRecord["intConfigPackId"]),
                    intJobTyeMasterId = Convert.ToInt32(dataRecord["intJobTypeMasterId"]),
                    str_LegacyCodeOrValue = Convert.ToString(dataRecord["str_LegacyCodeOrValue"]),
                    str_LegacyFieldName = Convert.ToString(dataRecord["str_LegacyFieldName"]),
                    str_LegacyName = Convert.ToString(dataRecord["str_LegacyName"]),
                    jobType = Convert.ToString(dataRecord["jobType"]).Replace("\r\n","").Replace("\n",""),
                    Description = Convert.ToString(dataRecord["Description"]).Replace("\r\n", "").Replace("\n", ""),
                    bitIsApproved = Convert.ToBoolean(dataRecord["bitIsApproved"])

                }).ToList();


                return results;
            }
        }


        public static DataTable ObjectToData(List<JobViewConfigModel> o)
        {
            DataTable dt = new DataTable("OutputData");

            

            dt.Columns.Add("intId", typeof(int));
            dt.Columns.Add("intConfigPackId", typeof(string));
            dt.Columns.Add("jobType", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("str_LegacyName", typeof(string));
            dt.Columns.Add("str_LegacyFieldName", typeof(string));
            dt.Columns.Add("str_LegacyCodeOrValue", typeof(string));

            foreach (JobViewConfigModel model in o)
            {
                DataRow dr = dt.NewRow();
                dt.Rows.Add(dr);
                dt.Rows[dt.Rows.Count - 1]["intId"] = model.intId;
                dt.Rows[dt.Rows.Count - 1]["intConfigPackId"] = model.intConfigPackId;
                dt.Rows[dt.Rows.Count - 1]["jobType"] = model.jobType.Replace("\r\n", "").Replace("\n", "").Trim();
                dt.Rows[dt.Rows.Count - 1]["Description"] = model.Description.Replace("\r\n", "").Replace("\n", "").Trim();
                dt.Rows[dt.Rows.Count - 1]["str_LegacyName"] = model.str_LegacyName;
                dt.Rows[dt.Rows.Count - 1]["str_LegacyFieldName"] = model.str_LegacyFieldName;
                dt.Rows[dt.Rows.Count - 1]["str_LegacyCodeOrValue"] = model.str_LegacyCodeOrValue;
            }
            return dt;

        }
        public string SaveJobTypeConfigPack(List<JobViewConfigModel> jModel,int UserId)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    DataTable dt = ObjectToData(jModel);

                    List<SqlParameter> parameters = new List<SqlParameter>();
                    DataTable dtBunit = dt.DefaultView.ToTable(false, new string[] { "intId" , "intConfigPackId",   "jobType",
                    "Description",   "str_LegacyName" ,   "str_LegacyFieldName", "str_LegacyCodeOrValue"});
                  
                    parameters.Add<DataTable>("JobTypes", dtBunit);
                    parameters.Add<int>("intUserId", UserId);

                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveJobTypeConfigPack, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }



    }
}
