﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class DepartmentMasterRepositoryDB
    {
        private static DepartmentMasterRepositoryDB _instance;

        public static DepartmentMasterRepositoryDB Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DepartmentMasterRepositoryDB();
                }
                return _instance;
            }
        }

        public List<DepatmentMaster> GetDepartmentMaster()
        {
            IEnumerable<DepatmentMaster> deptList = new List<DepatmentMaster>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                deptList = sqlDataHelper.ExecuteReader<DepatmentMaster>(StoredProcedures.SP_GetDepartmentMaster, CommandType.StoredProcedure, null);
            }
            return deptList.ToList();
        }

        public string SaveDepartmentMaster(DepatmentMaster dptMaster)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add<int>("Id", dptMaster.DeparmentMasterId);
                    parameters.Add<string>("Code", dptMaster.strDepartmentCode);
                    parameters.Add<string>("Name", dptMaster.strDescription);                    
                    parameters.Add<string>("IsActive", dptMaster.bitIsActive);
                    parameters.Add<string>("IsApproved", dptMaster.bitIsApproved.ToString());


                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveDeptMaster, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }


    }
}
