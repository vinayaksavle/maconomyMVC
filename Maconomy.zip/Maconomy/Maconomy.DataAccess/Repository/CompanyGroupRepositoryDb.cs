﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class CompanyGroupRepositoryDb
    {
        private static CompanyGroupRepositoryDb _instance;

        public static CompanyGroupRepositoryDb Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new CompanyGroupRepositoryDb();
                }
                return _instance;
            }
        }


        public List<CompanyGroup> GetCompanyGroups()
        {
            IEnumerable<CompanyGroup> companyGroup = new List<CompanyGroup>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                companyGroup = sqlDataHelper.ExecuteReader<CompanyGroup>(StoredProcedures.SP_GetCompanyGroups, CommandType.StoredProcedure);
            }
            return companyGroup.ToList();
        }


        public string SaveCompanyGroup(CompanyGroup cGroup)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {                    
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add<int>("Id", cGroup.Id);
                    parameters.Add<string>("CompanyGroup", cGroup.Companygroup);
                    parameters.Add<string>("IsActive", cGroup.isActive);
                    
                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveCompanyGroup, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }



    }
}
