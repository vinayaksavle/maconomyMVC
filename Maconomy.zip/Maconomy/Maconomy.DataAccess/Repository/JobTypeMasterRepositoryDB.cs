﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Maconomy.BusinessEntities.Models;
using Maconomy.DataAccess.SqlDataAccess;
using System.Data;
using System.Transactions;
using Maconomy.BusinessEntities.Constants;
using System.Data.SqlClient;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.Repository
{
    public class JobTypeMasterRepositoryDB
    {
        private static JobTypeMasterRepositoryDB _instance;

        public static JobTypeMasterRepositoryDB Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new JobTypeMasterRepositoryDB();
                }
                return _instance;
            }
        }

        public List<JobTypeMaster> GetJobTypeMaster()
        {
            IEnumerable<JobTypeMaster> deptList = new List<JobTypeMaster>();
            using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
            {
                deptList = sqlDataHelper.ExecuteReader<JobTypeMaster>(StoredProcedures.SP_GetJobTypeMaster, CommandType.StoredProcedure, null);
            }
            return deptList.ToList();
        }

        public string SaveJobTypeMaster(JobTypeMaster dptMaster)
        {
            string result = string.Empty;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add<int>("Id", dptMaster.intId);
                    parameters.Add<string>("Code", dptMaster.strJobType);
                    parameters.Add<string>("Name", dptMaster.strDescription);                    
                    parameters.Add<string>("IsActive", dptMaster.bitIsActive);
                    parameters.Add<string>("IsApproved", dptMaster.bitIsApproved.ToString());


                    using (SqlDataHelper sqlDataHelper = new SqlDataHelper())
                    {
                        sqlDataHelper.ExecuteNonQuery(StoredProcedures.SP_SaveJobTypeMaster, CommandType.StoredProcedure, parameters);
                    }
                    transactionScope.Complete();
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    result = ex.Message;
                }
            }
            return result;
        }


    }
}
