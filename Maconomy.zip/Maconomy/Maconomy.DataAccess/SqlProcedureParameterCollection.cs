﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Maconomy.DataAccess
{
    public class SqlProcedureParameterCollection:Dictionary<string, SqlParameter>
    {
        private bool Retrieved = false;
        public string ProcedureName { get; private set; }

        public SqlProcedureParameterCollection() : base(StringComparer.OrdinalIgnoreCase)
        {
        }

        public SqlProcedureParameterCollection(string connectionString, string procedureName)
            : base(StringComparer.OrdinalIgnoreCase)
        {
            if (string.IsNullOrWhiteSpace(connectionString)) throw new ArgumentNullException("connectionString");
            if (string.IsNullOrWhiteSpace(procedureName)) throw new ArgumentNullException("procedureName");
            ProcedureName = procedureName;
            foreach (var parameter in SqlHelperParameterCache.GetSpParameterSet(connectionString, procedureName))
                base[parameter.ParameterName] = parameter;

            Retrieved = true;
        }

        public SqlProcedureParameterCollection(SqlConnection connection, string procedureName)
            : base(StringComparer.OrdinalIgnoreCase)
        {
            if (connection==null) throw new ArgumentNullException("connection");
            if (string.IsNullOrWhiteSpace(procedureName)) throw new ArgumentNullException("procedureName");
            ProcedureName = procedureName;
            foreach (var parameter in SqlHelperParameterCache.GetSpParameterSet(connection, procedureName))
                base[parameter.ParameterName] = parameter;

            Retrieved = true;
        }

        public SqlProcedureParameterCollection(SqlTransaction transaction, string procedureName)
            : base(StringComparer.OrdinalIgnoreCase)
        {
            if (transaction == null) throw new ArgumentNullException("transaction");
            if (string.IsNullOrWhiteSpace(procedureName)) throw new ArgumentNullException("procedureName");
            ProcedureName = procedureName;
            foreach (var parameter in SqlHelperParameterCache.GetSpParameterSet(transaction, ProcedureName))
                base[parameter.ParameterName] = parameter;

            Retrieved = true;
        }

        public new object this[string name]
        {
            get
            {
                if (!name.StartsWith("@")) name = "@" + name;
                if (string.IsNullOrWhiteSpace(name))throw new ArgumentNullException("name");

                if (!ContainsKey(name))throw new ArgumentException("Cannot find SQlParameter '"+name+"'","name");
                
                return base[name].Value;
            }
            set
            {
                if (!name.StartsWith("@")) name = "@" + name;
                if (string.IsNullOrWhiteSpace(name)) throw new ArgumentNullException("name");

                if (!ContainsKey(name))
                {
                    if (Retrieved) throw new ArgumentException("Cannot find SQlParameter '" + name + "'", "name");
                    base[name]=new SqlParameter(name, value);
                }
                else
                    base[name].Value = value;
            }
        }

        public void Repopulate(SqlTransaction transaction, string procedureName)
        {
            if (transaction == null) throw new ArgumentNullException("transaction");
            if (string.IsNullOrWhiteSpace(procedureName)) throw new ArgumentNullException("procedureName");
            ProcedureName = procedureName;

            foreach (var parameter in SqlHelperParameterCache.GetSpParameterSet(transaction, procedureName))
            {
                if (ContainsKey(parameter.ParameterName)) parameter.Value = base[parameter.ParameterName].Value;
                base[parameter.ParameterName] = parameter;
            }

            Retrieved = true;
        }

        public void Repopulate(SqlConnection connection, string procedureName)
        {
            if (connection == null) throw new ArgumentNullException("connection");
            if (string.IsNullOrWhiteSpace(procedureName)) throw new ArgumentNullException("procedureName");
            ProcedureName = procedureName;

            foreach (var parameter in SqlHelperParameterCache.GetSpParameterSet(connection, procedureName))
            {
                if (ContainsKey(parameter.ParameterName)) parameter.Value = base[parameter.ParameterName].Value;
                base[parameter.ParameterName] = parameter;
            }

            Retrieved = true;
        }


        public SqlParameter[] ToArray()
        {
            return Values.ToArray();
        }

        /// <summary>
        /// Sets any nullable parameters to null such as when DateTime=MinValue
        /// </summary>
        public void Nullify()
        {
            foreach (var parameter in Values)
            {
                if (parameter.Value == null) continue;
                switch (parameter.SqlDbType)
                {
                    case SqlDbType.Date:
                    case SqlDbType.DateTime:
                    case SqlDbType.DateTime2:
                    case SqlDbType.SmallDateTime:
                        if (parameter.Value.Equals(DateTime.MinValue)) parameter.Value = null;
                        break;
                }
                
            }
        }
    }
}
