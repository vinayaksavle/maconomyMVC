﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data;
using Maconomy.Utility.ExtensionClasses;

namespace Maconomy.DataAccess.SqlDataAccess
{
    public class SqlBulkCopyWrapper
    {
        public string ConnectionString { get; set; }
        public string DestinationTableName { get; set; }
        public int? BatchSize { get; set; }
        public Func<PropertyDescriptor, bool> ExpressionFilter { get; set; }

        /// <summary>
        /// Copies all items in a collection to a destination table
        /// </summary>
        public virtual void WriteToServer<T>(IEnumerable<T> items) where T : class
        {
            WriteToServer(items, SqlBulkCopyOptions.Default);
        }


        /// <summary>
        /// Copies all items in a collection to a destination table using SqlBulkCopyOption
        /// </summary>
        public virtual void WriteToServer<T>(IEnumerable<T> items, SqlBulkCopyOptions options) where T : class
        {
            DataTable dataTable = (this.ExpressionFilter == null) ? items.ToDataTable() : items.ToDataTable(this.ExpressionFilter);

            WriteToServer(dataTable, options);
        }


        /// <summary>
        /// Copies all items in a collection to a destination table using column mapping
        /// </summary>
        public virtual void WriteToServer<T>(IEnumerable<T> items, SqlBulkCopyOptions options, IEnumerable<SqlBulkCopyColumnMapping> columnMappings) where T : class
        {
            DataTable dataTable = (this.ExpressionFilter == null) ? items.ToDataTable() : items.ToDataTable(this.ExpressionFilter);

            WriteToServer(dataTable, options, columnMappings);
        }


        /// <summary>
        /// Copies all rows in the supplied System.Data.DataTable to a destination table
        /// </summary>
        /// <param name="dataTable">A System.Data.DataTable whose rows will be copied to the destination table</param>
        private void WriteToServer(DataTable dataTable)
        {
            WriteToServer(dataTable, SqlBulkCopyOptions.Default);
        }


        /// <summary>
        /// Copies all rows in the supplied System.Data.DataTable to a destination table
        /// </summary>
        private void WriteToServer(DataTable dataTable, SqlBulkCopyOptions options)
        {
            var columnMappings = from x in dataTable.Columns.Cast<DataColumn>()
                                 select new SqlBulkCopyColumnMapping(x.ColumnName, x.ColumnName);

            WriteToServer(dataTable, options, columnMappings);
        }


        /// <summary>
        /// Copies all rows in the supplied System.Data.DataTable to a destination table
        /// </summary>
        private void WriteToServer(DataTable dataTable, SqlBulkCopyOptions options, IEnumerable<SqlBulkCopyColumnMapping> columnMappings)
        {
            string destinationTableName = (string.IsNullOrWhiteSpace(DestinationTableName) ? null : DestinationTableName)  ?? (string.IsNullOrWhiteSpace(dataTable.TableName) ? null : dataTable.TableName);

            if (string.IsNullOrEmpty(destinationTableName))
            {
                throw new ArgumentException("Destination table name cannot be null or empty");
            }

            using (var bulkCopy = new SqlBulkCopy(this.ConnectionString, options))
            {
                bulkCopy.DestinationTableName = destinationTableName;

                if (this.BatchSize.HasValue)
                {
                    bulkCopy.BatchSize = this.BatchSize.Value;
                }

                foreach (var mapping in columnMappings)
                {
                    bulkCopy.ColumnMappings.Add(mapping);
                }

                bulkCopy.WriteToServer(dataTable);
            }
        }
    }
}
