﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Globalization;

namespace Maconomy.DataAccess.SqlDataAccess
{
    public class SqlQuery
    {
        public string UserName { get; set; }

        /// <summary>
        /// The underlying <see cref="StringBuilder"/>.
        /// </summary>
        public StringBuilder Buffer { get; private set; }

        /// <summary>
        /// Gets or sets the current SQL clause, used to identify consecutive 
        /// appends to the same clause.
        /// </summary>
        public string CurrentClause { get; set; }

        /// <summary>
        /// Gets or sets the separator of the current SQL clause body.
        /// </summary>
        /// <seealso cref="CurrentClause"/>
        public string CurrentSeparator { get; set; }

        /// <summary>
        /// Gets or sets the next SQL clause. Used by clause continuation methods,
        /// such as <see cref="AppendToCurrentClause(string)"/> and the methods that start with "_".
        /// </summary>
        public string NextClause { get; set; }

        /// <summary>
        /// Gets or sets the separator of the next SQL clause body.
        /// </summary>
        /// <seealso cref="NextClause"/>
        public string NextSeparator { get; set; }

        /// <summary>
        /// Returns true if the buffer is empty.
        /// </summary>
        public bool IsEmpty
        {
            get { return this.Buffer.Length == 0; }
        }

        public int TabSpace { get; set; }

        /// <summary>
        /// ctor used when building sub query.
        /// </summary>
        public SqlQuery(int tabSpace)
        {
            this.Buffer = new StringBuilder();
            this.TabSpace = tabSpace;
        }

        /// <summary>
        /// Ctor used when building sql query
        /// </summary>
        public SqlQuery(string userName)
        {
            this.UserName = userName;
            this.Buffer = new StringBuilder();
            this.Buffer.AppendLine(string.Format("-- Query executed by {0}", this.UserName));
        }


        /// <summary>
        /// Appends the IF EXISTS clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the IF EXISTS clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery IfExists(string format, int tabSpace = 0, params object[] args)
        {
            this.TabSpace = tabSpace;
            return AppendClause("IF EXISTS", null, format, args);
        }

        /// <summary>
        /// Appends the IF EXISTS clause using the provided <paramref name="subQuery"/> as body named after
        /// <paramref name="alias"/>.
        /// </summary>
        /// <param name="subQuery">The sub-query to use as the body of the IF EXISTS clause.</param>
        /// <param name="alias">The alias of the sub-query.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery IfExists(SqlQuery subQuery, int tabSpace = 0)
        {
            this.TabSpace = tabSpace;
            return IfExists("IF EXISTS ({0})", tabSpace, subQuery);
        }


        /// <summary>
        /// Sets SELECT as the next clause, to be used by subsequent calls to clause continuation methods,
        /// such as <see cref="_(string)"/> and <see cref="_If(bool, string, bool, args)"/>.
        /// </summary>
        /// <returns>A reference to this instance after the operation has completed.</returns>
        public SqlQuery Select()
        {
            return SetNextClause("SELECT", ", ");
        }


        /// <summary>
        /// Sets Buffer string builder pointing to the next SQL clause.
        /// </summary>
        /// <param name="clauseName">The SQL clause.</param>
        /// <param name="separator">The clause body separator, used for consecutive appends to the same clause.</param>
        /// <returns>A reference to this instance after the operation has completed.</returns>
        /// <seealso cref="NextClause"/>
        public SqlQuery SetNextClause(string clauseName, string separator)
        {

            this.NextClause = clauseName;
            this.NextSeparator = separator;
            return this;
        }
        /// <summary>
        /// Appends the SELECT clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="isDistinctClause"> if select required distinct keyword. </param>
        /// <param name="body">The body of the SELECT clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery Select(bool isDistinctClause, string body)
        {
            string selectClause = "SELECT";
            if (isDistinctClause)
            {
                selectClause = "SELECT DISTINCT";
            }
            return Select(isDistinctClause, body, null);
        }

        /// <summary>
        /// Appends the SELECT clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="isDistinctClause"> if select required distinct keyword. </param>
        /// <param name="format">The format string that represents the body of the SELECT clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery Select(bool isDistinctClause, string format, params object[] args)
        {
            string selectClause = "SELECT";
            if (isDistinctClause)
            {
                selectClause = "SELECT DISTINCT";
            }
            return AppendClause(selectClause, ", ", format, args);
        }


        /// <summary>
        /// Appends the FROM clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the FROM clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery From(string body)
        {
            return From(body, null);
        }

        /// <summary>
        /// Appends the FROM clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the FROM clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery From(string format, params object[] args)
        {
            return AppendClause("FROM", ", ", format, args);
        }

        /// <summary>
        /// Appends the FROM clause using the provided <paramref name="subQuery"/> as body named after
        /// <paramref name="alias"/>.
        /// </summary>
        /// <param name="subQuery">The sub-query to use as the body of the FROM clause.</param>
        /// <param name="alias">The alias of the sub-query.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery From(SqlQuery subQuery, string alias)
        {
            return From("({0}) " + alias, subQuery);
        }

        /// <summary>
        /// Appends the LEFT JOIN clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the LEFT JOIN clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery LeftJoin()
        {
            return SetNextClause("LEFT JOIN", null);
        }

        /// <summary>
        /// Appends the LEFT JOIN clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the LEFT JOIN clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery LeftJoin(string body)
        {
            return LeftJoin(body, null);
        }

        /// <summary>
        /// Appends the LEFT JOIN clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the LEFT JOIN clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery LeftJoin(string format, params object[] args)
        {
            return AppendClause("LEFT JOIN", null, format, args);
        }

        /// <summary>
        /// Appends the RIGHT JOIN clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the RIGHT JOIN clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery RightJoin(string body)
        {
            return RightJoin(body, null);
        }

        /// <summary>
        /// Appends the RIGHT JOIN clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the RIGHT JOIN clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery RightJoin(string format, params object[] args)
        {
            return AppendClause("RIGHT JOIN", null, format, args);
        }

        /// <summary>
        /// Appends the INNER JOIN clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the INNER JOIN clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery InnerJoin()
        {
            return SetNextClause("INNER JOIN", null);
        }

        /// <summary>
        /// Appends the INNER JOIN clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the INNER JOIN clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery InnerJoin(string body)
        {
            return InnerJoin(body, null);
        }

        /// <summary>
        /// Appends the INNER JOIN clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the INNER JOIN clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery InnerJoin(string format, params object[] args)
        {
            return AppendClause("INNER JOIN", null, format, args);
        }


        /// <summary>
        /// Appends the INNER JOIN clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the INNER JOIN clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery InnerHashJoin(string body)
        {
            return InnerHashJoin(body, null);
        }

        /// <summary>
        /// Appends the INNER JOIN clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the INNER JOIN clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery InnerHashJoin(string format, params object[] args)
        {
            return AppendClause("INNER HASH JOIN", null, format, args);
        }

        /// <summary>
        /// Appends the CROSS APPLY  clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the CROSS APPLY  clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery CrossApply(string body)
        {
            return CrossApply(body, null);
        }

        /// <summary>
        /// Appends the CROSS APPLY clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the CROSS APPLY  clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery CrossApply(string format, params object[] args)
        {
            return AppendClause("CROSS APPLY", null, format, args);
        }

        /// <summary>
        /// Appends the CrossApply clause to the query builder
        /// </summary>
        /// <returns></returns>
        public SqlQuery AppendToCrossApply()
        {
            this.CurrentClause = "CROSS APPLY";
            this.CurrentSeparator = null;
            this.NextClause = null;
            this.NextSeparator = null;
            return this;
        }

        /// <summary>
        /// Appends the WHERE clause to the query builder
        /// </summary>
        /// <returns></returns>
        public SqlQuery AppendToWhere()
        {
            this.CurrentClause = "WHERE";
            this.CurrentSeparator = " AND ";
            this.NextClause = null;
            this.NextSeparator = null;
            return this;
        }

        /// <summary>
        /// Appends the LEFT JOIN clause to the query builder
        /// </summary>
        /// <returns></returns>
        public SqlQuery AppendToLeftJoin()
        {
            this.CurrentClause = "LEFT JOIN";
            this.CurrentSeparator = null;
            this.NextClause = null;
            this.NextSeparator = null;
            return this;
        }

        /// <summary>
        /// Appends the RIGHT JOIN clause to the query builder
        /// </summary>
        /// <returns></returns>
        public SqlQuery AppendToRightJoin()
        {
            this.CurrentClause = "RIGHT JOIN";
            this.CurrentSeparator = null;
            this.NextClause = null;
            this.NextSeparator = null;
            return this;
        }

        /// <summary>
        /// Appends the INNER JOIN clause to the query builder
        /// </summary>
        /// <returns></returns>
        public SqlQuery AppendToInnerJoin()
        {
            this.CurrentClause = "INNER JOIN";
            this.CurrentSeparator = null;
            this.NextClause = null;
            this.NextSeparator = null;
            return this;
        }


        /// <summary>
        /// Sets WHERE as the next clause, to be used by subsequent calls to clause continuation methods,
        /// such as <see cref="_(string)"/> and <see cref="_If(bool, string)"/>.
        /// </summary>
        /// <returns>A reference to this instance after the operation has completed.</returns>
        public SqlQuery Where()
        {
            return SetNextClause("WHERE", " AND ");
        }

        /// <summary>
        /// Appends the WHERE clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the WHERE clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery Where(string body)
        {
            return Where(body, null);
        }

        /// <summary>
        /// Appends the WHERE clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the WHERE clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery Where(string format, params object[] args)
        {
            return AppendClause("WHERE", " AND ", format, args);
        }

        /// <summary>
        /// Add Conditional query to the query string builder.
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="format"></param>
        /// <param name="isAddTab"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public SqlQuery _If(bool condition, string format, bool isAddTab = false, params object[] args)
        {
            return (condition) ? _(format, isAddTab, args) : this;
        }


        /// <summary>
        /// Sets GROUP BY as the next clause, to be used by subsequent calls to clause continuation methods,
        /// such as <see cref="_(string)"/> and <see cref="_If(bool, string)"/>.
        /// </summary>
        /// <returns>A reference to this instance after the operation has completed.</returns>
        public SqlQuery GroupBy()
        {
            return SetNextClause("GROUP BY", ", ");
        }

        /// <summary>
        /// Appends the GROUP BY clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the GROUP BY clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery GroupBy(string body)
        {
            return GroupBy(body, null);
        }

        /// <summary>
        /// Appends the GROUP BY clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the GROUP BY clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery GroupBy(string format, params object[] args)
        {
            return AppendClause("GROUP BY", ", ", format, args);
        }

        /// <summary>
        /// Sets HAVING as the next clause, to be used by subsequent calls to clause continuation methods,
        /// such as <see cref="_(string)"/> and <see cref="_If(bool, string)"/>.
        /// </summary>
        /// <returns>A reference to this instance after the operation has completed.</returns>
        public SqlQuery Having()
        {
            return SetNextClause("HAVING", " AND ");
        }

        /// <summary>
        /// Appends the HAVING clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the HAVING clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery Having(string body)
        {
            return Having(body, null);
        }

        /// <summary>
        /// Appends the HAVING clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the HAVING clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery Having(string format, params object[] args)
        {
            return AppendClause("HAVING", " AND ", format, args);
        }

        /// <summary>
        /// Sets ORDER BY as the next clause, to be used by subsequent calls to clause continuation methods,
        /// such as <see cref="_(string)"/> and <see cref="_If(bool, string)"/>.
        /// </summary>
        /// <returns>A reference to this instance after the operation has completed.</returns>
        public SqlQuery OrderBy()
        {
            return SetNextClause("ORDER BY", ", ");
        }

        /// <summary>
        /// Appends the ORDER BY clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the ORDER BY clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery OrderBy(string body)
        {
            return OrderBy(body, null);
        }

        /// <summary>
        /// Appends the ORDER BY clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the ORDER BY clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery OrderBy(string format, params object[] args)
        {
            return AppendClause("ORDER BY", ", ", format, args);
        }

        /// <summary>
        /// Appends the UNION All clause.
        /// </summary>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery UnionAll(SqlQuery query, params object[] args)
        {
            return AppendClause("UNION ALL", null, null, null);
        }

        /// <summary>
        /// Appends the WITH clause using the provided <paramref name="body"/>.
        /// </summary>
        /// <param name="body">The body of the WITH clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery With(string body, int tabSpace = 0)
        {
            this.TabSpace = tabSpace;
            return With(body, null);
        }

        /// <summary>
        /// Appends the WITH clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the WITH clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery With(string format, params object[] args)
        {
            return AppendClause("WITH", null, format, args);
        }

        /// <summary>
        /// Appends the WITH clause using the provided <paramref name="subQuery"/> as body named after
        /// <paramref name="alias"/>.
        /// </summary>
        /// <param name="subQuery">The sub-query to use as the body of the WITH clause.</param>
        /// <param name="alias">The alias of the sub-query.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery With(SqlQuery subQuery, string alias, int tabSpace = 0)
        {
            this.TabSpace = tabSpace;
            return With(alias + " AS ({0}\n)", subQuery);
        }

        /// <summary>
        /// Appends the WITH clause using the provided <paramref name="subQuery"/> as body named after
        /// <paramref name="alias"/>.
        /// </summary>
        /// <param name="subQuery">The sub-query to use as the body of the WITH clause.</param>
        /// <param name="alias">The alias of the sub-query.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery ContinueWith(SqlQuery subQuery, string alias, int tabSpace = 0)
        {
            this.TabSpace = tabSpace;
            this.CurrentClause = "WITH";
            this.CurrentSeparator = " , ";
            return AppendToCurrentClause(alias + " AS ({0}\n)", subQuery);
        }



        /// <summary>
        /// Appends <paramref name="body"/> to the current clause. This method is a shortcut for
        /// <see cref="AppendToCurrentClause(string)"/>.
        /// </summary>
        /// <param name="body">The body of the current clause.</param>
        /// <param name="isAddTab">condition to add tab space</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        /// <seealso cref="AppendToCurrentClause(string)"/>
        public SqlQuery _(string body, bool isAddTab = false)
        {
            if (isAddTab)
            {
                this.TabSpace = 1;
            }
            return AppendToCurrentClause(body);
        }

        /// <summary>
        /// Appends <paramref name="format"/> to the current clause. This method is a shortcut for
        /// <see cref="AppendToCurrentClause(string, object[])"/>.
        /// </summary>
        /// <param name="format">The format string that represents the body of the current clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        /// <seealso cref="AppendToCurrentClause(string, object[])"/>
        public SqlQuery _(string format, bool isAddTab = false, params object[] args)
        {
            if (isAddTab)
            {
                this.TabSpace = 1;
            }
            return AppendToCurrentClause(format, args);
        }

        /// <summary>
        /// Appends the INSERT INTO clause using the provided <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="format">The format string that represents the body of the INSERT INTO clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery InsertInto(string alias, string format, params object[] args)
        {
            return AppendClause("INSERT INTO " + alias, null, format, args);
        }

        /// <summary>
        /// Appends <paramref name="body"/> to the current clause.
        /// </summary>
        /// <param name="body">The body of the current clause.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        /// <seealso cref="CurrentClause"/>
        public SqlQuery AppendToCurrentClause(string body)
        {
            return AppendToCurrentClause(body, null);
        }

        /// <summary>
        /// Appends <paramref name="format"/> to the current clause.
        /// </summary>
        /// <param name="format">The format string that represents the body of the current clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        /// <seealso cref="CurrentClause"/>
        public SqlQuery AppendToCurrentClause(string format, params object[] args)
        {

            string clause = this.CurrentClause;
            string separator = this.CurrentSeparator;

            if (this.NextClause != null)
            {
                clause = this.NextClause;
                separator = this.NextSeparator;
            }

            AppendClause(clause, separator, format, args);

            return this;
        }

        /// <summary>
        /// Appends the SQL clause specified by <paramref name="clauseName"/> using the provided 
        /// <paramref name="format"/> string and parameters.
        /// </summary>
        /// <param name="clauseName">The SQL clause.</param>
        /// <param name="separator">The clause body separator, used for consecutive appends to the same clause.</param>
        /// <param name="format">The format string that represents the body of the clause.</param>
        /// <param name="args">The parameters of the clause body.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery AppendClause(string clauseName, string separator, string format, object[] args)
        {

            if (separator == null || !string.Equals(clauseName, this.CurrentClause, StringComparison.OrdinalIgnoreCase))
            {
                if (!this.IsEmpty)
                {
                    this.Buffer.AppendLine();
                }

                if (clauseName != null)
                {
                    this.Buffer.Append(clauseName);
                    this.Buffer.Append(" ");
                }

            }
            else if (separator != null)
            {
                this.Buffer.AppendLine();
                for (int tab = 0; tab < (this.TabSpace); tab++)
                {
                    this.Buffer.Append("\t");
                }
                this.Buffer.Append(separator);
            }

            Append(format, args);

            this.CurrentClause = clauseName;
            this.CurrentSeparator = separator;

            this.NextClause = null;
            this.NextSeparator = null;

            return this;
        }


        /// <summary>
        /// Appends <paramref name="format"/> to this instance.
        /// </summary>
        /// <param name="format">A SQL format string.</param>
        /// <param name="args">The array of parameters.</param>
        /// <returns>A reference to this instance after the append operation has completed.</returns>
        public SqlQuery Append(string format, params object[] args)
        {
            if (args == null || args.Length == 0)
            {
                this.Buffer.Append(format);
            }
            else
            {
                List<string> formatArgs = new List<string>();
                for (int i = 0; i < args.Length; i++)
                {
                    object obj = args[i];
                    if (obj != null)
                    {
                        Array arr = obj as Array;
                        if (arr != null && arr.Length > 0)
                        {
                            formatArgs.Add(String.Join(", ", Enumerable.Range(0, arr.Length)));
                        }
                        else if (obj is SqlQuery)
                        {
                            SqlQuery sqlQuery = obj as SqlQuery;
                            if (sqlQuery != null)
                            {
                                //Adding no of tabs for subquery.
                                string tabs = string.Empty;
                                for (int tab = 0; tab < (this.TabSpace * 2); tab++)
                                {
                                    tabs += "\t";
                                }
                                StringBuilder sqlSubQuery = new StringBuilder()
                                   .AppendLine()
                                   .Append(sqlQuery.ToString())
                                   .Replace(Environment.NewLine, Environment.NewLine + tabs);

                                formatArgs.Add(sqlSubQuery.ToString());
                                continue;
                            }
                        }
                        else
                        {
                            formatArgs.Add(obj.ToString());
                        }
                    }
                }
                this.Buffer.AppendFormat(CultureInfo.InvariantCulture, format, formatArgs.Cast<object>().ToArray());
            }
            return this;
        }

        /// <summary>
        /// This query return create table syntax
        /// </summary>
        /// <param name="tableName">enter temp table name to be created </param>
        /// <param name="columns">enter dictionary<string,string> as key = column name; value= datatype</param>
        /// <returns></returns>
        public SqlQuery CreateTempTable(string tableName, Dictionary<string, string> columns)
        {
            this.Buffer.AppendLine();
            this.Buffer.Append("IF OBJECT_ID('tempdb..#" + tableName +"') IS NOT NULL");
            this.Buffer.AppendLine();
            this.Buffer.Append("\tTRUNCATE TABLE #" + tableName);
            this.Buffer.AppendLine();
            this.Buffer.Append("ELSE");
            this.Buffer.AppendLine();
            this.Buffer.Append("\tCREATE TABLE #" + tableName + "\n");
            this.Buffer.Append("\t(\n");
            foreach(var item in columns)
            {
                this.Buffer.Append("\t\t" + item.Key + " " + item.Value + ",\n");
            }
            this.Buffer.Remove(this.Buffer.ToString().Length - 1, 1);
            this.Buffer.Append("\n\t)");
            this.Buffer.AppendLine();
            return this;
        }

        /// <summary>
        /// This query return declate table variable syntax
        /// </summary>
        /// <param name="tableName">enter table name without @ </param>
        /// <param name="columns">enter dictionary<string,string> as key = column name; value= datatype</param>
        /// <returns></returns>
        public SqlQuery DeclareTableVariable(string tableName, Dictionary<string, string> columns)
        {
            this.Buffer.AppendLine();
            this.Buffer.Append("\tDeclare @" + tableName.Replace("@", "") + " Table\n");
            this.Buffer.Append("\t(\n");
            foreach (var item in columns)
            {
                this.Buffer.Append("\t\t" + item.Key + " " + item.Value + ",\n");
            }
            this.Buffer.Remove(this.Buffer.ToString().Length - 2, 1);
            this.Buffer.Append("\n\t)");
            this.Buffer.AppendLine();
            return this;
        }

        /// <summary>
        /// Appends declare table clause        
        /// </summary>
        public SqlQuery DeclareTable(string alias)
        {
            return AppendClause("DECLARE " + alias + " TABLE ", null, null, null);
        }


        public SqlQuery DropTable(string tableName)
        {
            this.Buffer.AppendLine();
            this.Buffer.Append("DROP TABLE tempdb.." + tableName);
            return this;
        }

        public SqlQuery AppendLine()
        {
            this.Buffer.AppendLine();
            return this;
        }

        public override string ToString()
        {
            return this.Buffer.ToString();
        }
    }
}
