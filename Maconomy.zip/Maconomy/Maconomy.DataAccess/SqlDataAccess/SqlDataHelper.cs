﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Reflection.Emit;
using Maconomy.Utility;

namespace Maconomy.DataAccess.SqlDataAccess
{
    public class SqlDataHelper : IDisposable
    {
        private SqlConnection _sqlConnection = null;
        private SqlCommand _sqlCommand = null;
        private SqlDataReader _sqlReader;
        private static readonly MethodInfo GetValueMethod = typeof(SqlDataReader).GetMethod("get_Item", new Type[] { typeof(int) });
        private static readonly MethodInfo IsDBNullMethod = typeof(SqlDataReader).GetMethod("IsDBNull", new Type[] { typeof(int) });


        private List<long> _pageIds = null;
        public List<long> PageIds
        {
            get
            {
                if (_pageIds == null)
                {
                    _pageIds = new List<long>();
                }
                return _pageIds;
            }
            set
            {
                _pageIds = value;
            }
        }

        private List<KeyValuePair<string, string>> _combinedIds = null;
        public List<KeyValuePair<string, string>> CombinedIds
        {
            get
            {
                if (_combinedIds == null)
                {
                    _combinedIds = new List<KeyValuePair<string, string>>();
                }
                return _combinedIds;
            }
            set
            {
                _combinedIds = value;
            }
        }

        public int RecordCount { get; set; }

        /// <summary>
        /// Open synchronous sql connection object
        /// </summary>
        /// <returns></returns>
        public SqlConnection OpenConnection()
        {
            _sqlConnection = new SqlConnection(ConfigSettings.ConnectionString);
            if (_sqlConnection.State != ConnectionState.Open)
            {
                _sqlConnection.Open();
            }
            return _sqlConnection;
        }

        /// <summary>
        /// Create sql command to accept any IEnumerable sqlParameters
        /// </summary>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <param name="sqlParameters"></param>
        /// <returns></returns>
        private SqlCommand CreateCommand(string commandText, CommandType commandType, IEnumerable<SqlParameter> sqlParameters)
        {
            _sqlCommand = _sqlConnection.CreateCommand();
            _sqlCommand.CommandTimeout = ConfigSettings.SqlCommandTimeout;
            _sqlCommand.Parameters.Clear();
            if (sqlParameters != null)
            {
                foreach (var item in sqlParameters)
                {
                    _sqlCommand.Parameters.Add(item);
                }
            }
            _sqlCommand.CommandText = commandText;
            _sqlCommand.CommandType = commandType;
            return _sqlCommand;
        }

        private SqlCommand CreateCommand(SqlTransaction transaction, string commandText, CommandType commandType, IEnumerable<SqlParameter> sqlParameters)
        {
            _sqlCommand = transaction.Connection.CreateCommand();
            _sqlCommand.Transaction = transaction;
            _sqlCommand.CommandTimeout = ConfigSettings.SqlCommandTimeout;
            _sqlCommand.Parameters.Clear();
            if (sqlParameters != null)
            {
                foreach (var item in sqlParameters)
                {
                    _sqlCommand.Parameters.Add(item);
                }
            }
            _sqlCommand.CommandText = commandText;
            _sqlCommand.CommandType = commandType;
            return _sqlCommand;
        }

        public SqlCommand SetCommand(string commandText, CommandType commandType, IEnumerable<SqlParameter> sqlParameters)
        {
            return CreateCommand(commandText, commandType, sqlParameters);
        }

        public SqlCommand SetCommand(SqlTransaction transaction, string commandText, CommandType commandType, IEnumerable<SqlParameter> sqlParameters)
        {
            return CreateCommand(transaction, commandText, commandType, sqlParameters);
        }


        /// <summary>
        /// Create sql command
        /// </summary>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <param name="sqlParameters"></param>
        /// <returns></returns>
        public SqlCommand CreateCommand(string commandText, SqlProcedureParameterCollection sqlParameters)
        {
            _sqlCommand = _sqlConnection.CreateCommand();
            _sqlCommand.CommandTimeout = ConfigSettings.SqlCommandTimeout;
            _sqlCommand.Parameters.Clear();
            if (sqlParameters != null)
            {
                sqlParameters.Nullify();
                _sqlCommand.Parameters.AddRange(sqlParameters.ToArray());
            }
            _sqlCommand.CommandText = commandText;
            _sqlCommand.CommandType = CommandType.StoredProcedure;
            return _sqlCommand;
        }

        private SqlCommand CreateCommand(SqlTransaction transaction, string commandText, SqlProcedureParameterCollection sqlParameters)
        {
            _sqlCommand = transaction.Connection.CreateCommand();
            _sqlCommand.Transaction = transaction;
            _sqlCommand.CommandTimeout = ConfigSettings.SqlCommandTimeout;
            _sqlCommand.Parameters.Clear();
            if (sqlParameters != null)
            {
                sqlParameters.Nullify();
                _sqlCommand.Parameters.AddRange(sqlParameters.ToArray());
            }
            _sqlCommand.CommandText = commandText;
            _sqlCommand.CommandType = CommandType.StoredProcedure;
            return _sqlCommand;
        }



        #region Execute Procedure

        /// <summary>
        /// Fill Dataset by procedureName
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="dataSet"></param>
        /// <returns></returns>
        public DataSet ExecuteProcedure(string procedureName, ref DataSet dataSet)
        {
            using (OpenConnection())
            {
                using (CreateCommand(procedureName, CommandType.StoredProcedure, null))
                {
                    using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(_sqlCommand))
                    {
                        sqlDataAdapter.Fill(dataSet);
                    }
                }
            }
            return dataSet;
        }

        /// <summary>
        /// Fill dataTable by procedure name
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public DataTable ExecuteProcedure(string procedureName, ref DataTable dataTable)
        {
            using (OpenConnection())
            {
                using (CreateCommand(procedureName, CommandType.StoredProcedure, null))
                {
                    using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(_sqlCommand))
                    {
                        sqlDataAdapter.Fill(dataTable);
                    }
                }
            }
            return dataTable;
        }

        /// <summary>
        /// Fill Dataset by procedure name and parameter
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="sqlParameters"></param>
        /// <param name="dataSet"></param>
        /// <returns></returns>
        public DataSet ExecuteProcedure(string procedureName, IEnumerable<SqlParameter> sqlParameters, ref DataSet dataSet)
        {
            using (OpenConnection())
            {
                using (CreateCommand(procedureName, CommandType.StoredProcedure, sqlParameters))
                {
                    using (SqlDataAdapter sqlDatAdapter = new SqlDataAdapter(_sqlCommand))
                    {
                        sqlDatAdapter.Fill(dataSet);
                    }
                }
            }
            return dataSet;
        }

        /// <summary>
        /// Fill DataTable by procedure name and parameter
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="sqlParameters"></param>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public DataTable ExecuteProcedure(string procedureName, IEnumerable<SqlParameter> sqlParameters, ref DataTable dataTable)
        {
            using (OpenConnection())
            {
                using (CreateCommand(procedureName, CommandType.StoredProcedure, sqlParameters))
                {
                    using (SqlDataAdapter sqlDatAdapter = new SqlDataAdapter(_sqlCommand))
                    {
                        sqlDatAdapter.Fill(dataTable);
                    }
                }
            }
            return dataTable;
        }

        #endregion

        #region Execute Scalar

        /// <summary>
        /// Execute scalar command and return as object
        /// </summary>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public object ExecuteScalar(string commandText, CommandType commandType, SqlParameter[] parameters)
        {
            using (OpenConnection())
            {
                using (CreateCommand(commandText, commandType, parameters))
                {
                    return _sqlCommand.ExecuteScalar();
                }
            }
        }

        public object ExecuteScalar(string commandText, SqlProcedureParameterCollection parameters)
        {
            using (OpenConnection())
            {
                using (CreateCommand(commandText, parameters))
                {
                    _sqlCommand.Parameters.Add("@RETURN_VALUE", SqlDbType.DateTime).Direction = ParameterDirection.ReturnValue;
                    _sqlCommand.ExecuteNonQuery();
                    return _sqlCommand.Parameters["@RETURN_VALUE"].Value;
                }
            }
        }

        #endregion

        #region ExecuteNonQuery


        public int ExecuteNonQuery(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters)
        {
            using (OpenConnection())
            {
                using (CreateCommand(commandText, commandType, parameters))
                {
                    return _sqlCommand.ExecuteNonQuery();
                }
            }
        }

        public int ExecuteNonQuery(string procedureName, SqlProcedureParameterCollection parameters)
        {
            using (OpenConnection())
            {
                parameters.Repopulate(_sqlConnection, procedureName);
                using (CreateCommand(procedureName, parameters))
                {
                    return _sqlCommand.ExecuteNonQuery();
                }
            }
        }

        public int ExecuteNonQuery(SqlTransaction transaction, string procedureName, SqlProcedureParameterCollection parameters)
        {
            using (CreateCommand(transaction, procedureName, parameters))
            {
                return _sqlCommand.ExecuteNonQuery();
            }
        }

        public int ExecuteNonQuery(SqlTransaction transaction, string commandText, CommandType commandType, SqlParameter[] parameters)
        {
            using (CreateCommand(transaction, commandText, commandType, parameters))
            {
                return _sqlCommand.ExecuteNonQuery();
            }
        }

        #endregion

        #region Execute Reader

        /// <summary>
        /// Generic method to get IEnumerable<T>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procedureName"></param>
        /// <param name="selector"></param>
        /// <returns></returns>
        public IEnumerable<T> ExecuteReader<T>(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters, Func<SqlDataReader, T> selector) where T : new()
        {
            using (OpenConnection())
            {

                using (CreateCommand(commandText, commandType, parameters))
                {
                    using (SqlDataReader reader = _sqlCommand.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                yield return selector(reader);
                            }
                        }
                    }
                }
            }
        }


        /// <summary>
        /// Generic method to get SqlDataReader Record
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procedureName"></param>
        /// <param name="selector"></param>
        /// <returns></returns>
        public IEnumerable<IDataRecord> ExecuteReader(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters)
        {
            using (OpenConnection())
            {
                using (CreateCommand(commandText, commandType, parameters))
                {
                    using (var reader = _sqlCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            yield return reader;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Generic method to get SqlDataReader Record
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procedureName"></param>
        /// <param name="selector"></param>
        /// <returns></returns>
        public IEnumerable<IDataRecord> ExecuteReader(string procedureName, SqlProcedureParameterCollection parameters)
        {
            using (OpenConnection())
            {
                parameters.Repopulate(_sqlConnection, procedureName);
                using (CreateCommand(procedureName, parameters))
                {
                    using (var reader = _sqlCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            yield return reader;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Generic method to get SqlDataReader Record
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procedureName"></param>
        /// <param name="selector"></param>
        /// <returns></returns>
        public IEnumerable<IDataRecord> ExecuteReaderOnlyForNextResult(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters)
        {
            using (OpenConnection())
            {
                using (CreateCommand(commandText, commandType, parameters))
                {
                    using (var reader = _sqlCommand.ExecuteReader())
                    {
                        reader.NextResult();
                        while (reader.Read())
                        {
                            yield return reader;
                        }
                    }
                }
            }
        }

        public IEnumerable<T> ExecuteMultipleResults<T>(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters, Func<SqlDataReader, T> selector) where T : new()
        {
            using (OpenConnection())
            {

                using (CreateCommand(commandText, commandType, parameters))
                {
                    using (SqlDataReader reader = _sqlCommand.ExecuteReader())
                    {
                        do
                        {
                            while (reader.Read())
                            {
                                yield return selector(reader);
                            }
                        }
                        while (reader.NextResult());
                    }
                }
            }
        }

        public IEnumerable<IDataRecord> ExecuteMultipleResults(string procedureName, CommandType commandType, IEnumerable<SqlParameter> parameters)
        {
            using (OpenConnection())
            {
                using (CreateCommand(procedureName, commandType, parameters))
                {
                    using (SqlDataReader reader = _sqlCommand.ExecuteReader())
                    {
                        do
                        {
                            while (reader.Read())
                            {
                                yield return reader;
                            }
                        }
                        while (reader.NextResult());
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <param name="parameters"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="isCombinedList"> Optional parameter
        /// Usually required for list page functionality as you need to have contactId and outletid both.
        /// Note: contactid and outletId may criss cross so we need to provide extra field that determoned which is contact and which one belongs to outlet.
        /// </param>
        public void ExecuteCountReader(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters, int pageNo, int pageSize, bool isCombinedList = false)
        {
            using (OpenConnection())
            {
                using (CreateCommand(commandText, commandType, parameters))
                {
                    using (SqlDataReader reader = _sqlCommand.ExecuteReader())
                    {
                        IEnumerable<IDataRecord> countReader = reader.Cast<IDataRecord>().TakeRecordByPaging(pageSize, pageNo);
                        if (isCombinedList)
                        {
                            foreach (var item in countReader)
                            {
                                CombinedIds.Add(new KeyValuePair<string, string>(item.GetValue(0).ToString(), item.GetValue(1).ToString()));
                            }
                        }
                        else
                        {
                            foreach (var item in countReader)
                            {
                                PageIds.Add(item.GetValue(0).ToInt64());
                            }
                        }
                    }
                    _sqlCommand.CommandText = "Select @@ROWCOUNT";
                    _sqlCommand.CommandType = CommandType.Text;
                    var count = _sqlCommand.ExecuteScalar();
                    RecordCount = count.ToInt32();
                }
            }
        }

        /// <summary>
        /// Fill DataTable for inline query execution
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public DataTable ExecuteDataTable(string sql, CommandType commandType, IEnumerable<SqlParameter> parameters, ref DataTable dataTable)
        {
            using (OpenConnection())
            {
                using (CreateCommand(sql, commandType, parameters))
                {
                    using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(_sqlCommand))
                    {
                        sqlDataAdapter.Fill(dataTable);
                    }
                }
            }
            return dataTable;
        }


        public void InsertBulkRecords(string inlineQueryName, CommandType commandType, IEnumerable<SqlParameter> sqlParameters, DataTable dtValues)
        {
            using (OpenConnection())
            {
                using (SqlCommand sqlCommand = CreateCommand(inlineQueryName, commandType, sqlParameters))
                {
                    using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
                    {
                        using (SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter))
                        {
                            DataTable dataTable = new DataTable();
                            sqlDataAdapter.Fill(dataTable);
                            dataTable = dtValues.Copy();
                            sqlDataAdapter.InsertCommand = sqlCommandBuilder.GetInsertCommand();
                            sqlDataAdapter.Update(dataTable);
                        }
                    }
                }
            }
        }


        #endregion

        #region Dynamic Mapping of Db columns to the ORM Entity class.

        /// <summary>
        /// Nested struct for mapping sql column to class entity.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        struct DeserializerState<T>
        {
            public readonly Func<SqlDataReader, T> MapEntity;

            public DeserializerState(Func<SqlDataReader, T> func)
            {
                MapEntity = func;
            }
        }

        /// <summary>
        /// Execute reader and return object as IEnumerable mapping class property with the Sql column.
        /// </summary>
        public IEnumerable<T> ExecuteReader<T>(string sql,
                                                CommandType? commandType = null,
                                                object parametres = null,
                                                SqlTransaction transaction = null,
                                                bool buffered = false
                                              )
        {
            OpenConnection();
            var data = ExecuteQuery<T>(sql, parametres, transaction, commandType);
            return buffered ? data.ToList() : data;
        }

        /// <summary>
        /// Get Multiple results by dynamically mapping DB fields to the entity class
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="commandType"></param>
        /// <param name="parametres"></param>
        /// <returns></returns>
        public MultiGridReader ExecuteMultipleResults(string sql, CommandType? commandType = null, object parameters = null)
        {
            SqlConnection connection = OpenConnection();
            SqlCommand command = connection.CreateCommand();
            command.CommandText = sql;
            if (commandType.HasValue)
            {
                command.CommandType = commandType.Value;
            }
            if (parameters != null)
            {
                CreateParameters(parameters, command);
            }
            SqlDataReader reader = command.ExecuteReader();
            var result = new MultiGridReader(command, reader);
            return result;
        }


        /// <summary>
        /// Return a typed list of objects, reader is closed after the call
        /// For internal purpose.
        /// </summary>
        private IEnumerable<T> ExecuteQuery<T>(string sql, object parameters, SqlTransaction transaction, CommandType? commandType)
        {
            using (OpenConnection())
            {
                using (SqlCommand command = CreateCommand(sql, parameters, transaction, commandType))
                {
                    using (_sqlReader = command.ExecuteReader())
                    {
                        var entityMapper = new DeserializerState<T>(Mapper<T>(_sqlReader));
                        while (_sqlReader.Read())
                        {
                            yield return (T)entityMapper.MapEntity(_sqlReader);
                        }
                    }
                    if (command != null)
                    {
                        command.Dispose();
                    }
                }
            }
        }

        /// <summary>
        /// Map Entity with Sql Object using Reflection.Emit
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="reader"></param>
        /// <returns></returns>
        private Func<SqlDataReader, T> Mapper<T>(SqlDataReader reader)
        {
            DynamicMethod method = new DynamicMethod("DynamicCreateMapping", typeof(T), new Type[] { typeof(IDataRecord) }, typeof(T), true);
            ILGenerator generator = method.GetILGenerator();
            try
            {
                LocalBuilder result = generator.DeclareLocal(typeof(T));
                generator.Emit(OpCodes.Newobj, typeof(T).GetConstructor(Type.EmptyTypes));
                generator.Emit(OpCodes.Stloc, result);

                for (int i = 0; i < reader.FieldCount; i++)
                {
                    PropertyInfo propertyInfo = typeof(T).GetProperty(reader.GetName(i));
                    Label endIfLabel = generator.DefineLabel();

                    if (propertyInfo != null && propertyInfo.GetSetMethod() != null)
                    {
                        generator.Emit(OpCodes.Ldarg_0);
                        generator.Emit(OpCodes.Ldc_I4, i);
                        generator.Emit(OpCodes.Callvirt, IsDBNullMethod);
                        generator.Emit(OpCodes.Brtrue, endIfLabel);

                        generator.Emit(OpCodes.Ldloc, result);
                        generator.Emit(OpCodes.Ldarg_0);
                        generator.Emit(OpCodes.Ldc_I4, i);
                        generator.Emit(OpCodes.Callvirt, GetValueMethod);
                        if (propertyInfo.PropertyType.IsEnum || propertyInfo.PropertyType == typeof(Boolean))
                        {
                            generator.Emit(OpCodes.Unbox_Any, reader.GetFieldType(i));
                        }
                        else
                        {
                            generator.Emit(OpCodes.Call, GetConverterMethod(propertyInfo.PropertyType));
                        }
                        //generator.Emit(OpCodes.Unbox_Any, reader.GetFieldType(i));
                        generator.Emit(OpCodes.Callvirt, propertyInfo.GetSetMethod());

                        generator.MarkLabel(endIfLabel);
                    }
                }

                generator.Emit(OpCodes.Ldloc, result);
                generator.Emit(OpCodes.Ret);
            }
            catch
            {
            }

            return (Func<SqlDataReader, T>)method.CreateDelegate(typeof(Func<SqlDataReader, T>));
        }

        private MethodInfo GetConverterMethod(Type type)
        {
            switch (type.Name.ToUpper())
            {
                case "INT16":
                    return CreateConverterMethodInfo("ToInt16");
                case "INT32":
                    return CreateConverterMethodInfo("ToInt32");
                case "INT64":
                    return CreateConverterMethodInfo("ToInt64");
                case "SINGLE":
                    return CreateConverterMethodInfo("ToSingle");
                case "BOOLEAN":
                    return CreateConverterMethodInfo("ToBoolean");
                case "STRING":
                    return CreateConverterMethodInfo("ToString");
                case "DATETIME":
                    return CreateConverterMethodInfo("ToDateTime");
                case "DECIMAL":
                    return CreateConverterMethodInfo("ToDecimal");
                case "DOUBLE":
                    return CreateConverterMethodInfo("ToDouble");
                case "GUID":
                    return CreateConverterMethodInfo("ToGuid");
                case "BYTE[]":
                    return CreateConverterMethodInfo("ToBytes");
                case "BYTE":
                    return CreateConverterMethodInfo("ToByte");
                case "NULLABLE`1":
                    {
                        if (type == typeof(DateTime?))
                        {
                            return CreateConverterMethodInfo("ToDateTimeNull");
                        }
                        else if (type == typeof(Int32?))
                        {
                            return CreateConverterMethodInfo("ToInt32Null");
                        }
                        else if (type == typeof(Boolean?))
                        {
                            return CreateConverterMethodInfo("ToBooleanNull");
                        }
                        break;
                    }
            }
            return null;
        }

        /// <summary>
        /// Coverter method for sql column types matching to POCO objects.
        /// </summary>
        /// <param name="method"></param>
        /// <returns></returns>
        private MethodInfo CreateConverterMethodInfo(string method)
        {
            return typeof(Converter).GetMethod(method, new Type[] { typeof(object) });
        }

        /// <summary>
        /// Check for SqlDbType to add data type for parameter to the sqlCommand object
        /// </summary>
        internal static SqlDbType LookupType(Type type, string name)
        {
            SqlDbType sqlDbType;
            var nullUnderlyingType = Nullable.GetUnderlyingType(type);
            if (nullUnderlyingType != null) type = nullUnderlyingType;

            var lookupSqlDbType = LookupSqlDbType.Where(w => w.Value == type);
            if (lookupSqlDbType.Count() > 0)
            {
                sqlDbType = LookupSqlDbType.Where(w => w.Value == type).Select(s => s.Key).FirstOrDefault();
                return sqlDbType;
            }
            throw new NotSupportedException(string.Format("The member {0} of type {1} cannot be used as a parameter value", name, type));
        }

        /// <summary>
        /// Create SqlCommand object including parameters
        /// </summary>
        private SqlCommand CreateCommand(string sql, object parameter = null, SqlTransaction transaction = null, CommandType? commandType = null)
        {
            var sqlCommand = _sqlConnection.CreateCommand();
            if (transaction != null)
                sqlCommand.Transaction = transaction;
            sqlCommand.CommandText = sql;
            sqlCommand.CommandTimeout = ConfigSettings.SqlCommandTimeout;
            if (commandType.HasValue)
            {
                sqlCommand.CommandType = commandType.Value;
            }
            if (parameter != null)
            {
                CreateParameters(parameter, sqlCommand);
            }
            return sqlCommand;
        }

        /// <summary>
        /// Create Parameter for Sql Command.
        /// </summary>
        private void CreateParameters(object parameter, SqlCommand sqlCommand)
        {
            List<SqlParameter> sqlParameter = new List<SqlParameter>();
            if (parameter != null)
            {
                if (parameter.GetType() == typeof(SqlParameter[]))
                {
                    sqlCommand.Parameters.AddRange(parameter as SqlParameter[]);
                }
                else if (parameter.GetType() == typeof(SqlParameter))
                {
                    sqlCommand.Parameters.Add(parameter as SqlParameter);
                }
                else if (parameter.GetType() == typeof(List<SqlParameter>))
                {
                    sqlCommand.Parameters.AddRange((parameter as List<SqlParameter>).ToArray());
                }
                else //if anonymous type
                {
                    Type parameterType = parameter.GetType();
                    IEnumerable<PropertyInfo> props = parameterType.GetProperties(BindingFlags.Instance | BindingFlags.Public);// type.GetProperties().Where(p => p.GetIndexParameters().Length == 0).OrderBy(p => p.Name);
                    foreach (var prop in props)
                    {
                        SqlDbType sqlDbType = LookupType(prop.PropertyType, prop.Name);
                        SqlParameter anonymousParameter = sqlCommand.CreateParameter();
                        anonymousParameter.SqlDbType = sqlDbType;
                        anonymousParameter.ParameterName = "@" + prop.Name;
                        anonymousParameter.Value = prop.GetValue(parameter, null);
                        sqlCommand.Parameters.Add(anonymousParameter);
                    }
                }
            }
        }

        /// <summary>
        /// Look up dictionary for getting  SqlDbType by passing class property data type.
        /// </summary>
        private static readonly List<KeyValuePair<SqlDbType, Type>> LookupSqlDbType = new List<KeyValuePair<SqlDbType, Type>>
        {
            new KeyValuePair<SqlDbType,Type>(SqlDbType.BigInt, typeof (long)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.VarBinary, typeof (byte[])),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Bit, typeof (bool)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Bit, typeof (bool?)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Char, typeof (char)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.VarChar, typeof (string)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.DateTime, typeof (DateTime)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.DateTime, typeof (DateTime?)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Decimal, typeof (decimal)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Float, typeof (double)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Int, typeof (int)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Int, typeof (int?)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Real, typeof (float)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.UniqueIdentifier, typeof (Guid)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.SmallInt, typeof (short)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.TinyInt, typeof (byte)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Variant, typeof (object)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.Structured, typeof (DataTable)),
            new KeyValuePair<SqlDbType,Type>(SqlDbType.DateTimeOffset, typeof (DateTimeOffset))
        };

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            if (_sqlConnection != null && _sqlConnection.State == ConnectionState.Open)
            {
                _sqlConnection.Close();
                _sqlConnection.Dispose();
                _sqlConnection = null;

            }
            if (_sqlCommand != null)
            {
                _sqlCommand.Dispose();
                _sqlCommand = null;

            }
            if (_sqlReader != null)
            {
                _sqlReader.Close();
                _sqlReader.Dispose();
            }
        }

        #endregion

        #region Converter class for auto mapping POCO objects
        /// <summary>
        /// Converter class used for Auto Mapping Sql Query Columns with POCO objects.
        /// </summary>
        public class Converter
        {
            public static Int16 ToInt16(object value)
            {
                return ChangeType<Int16>(value);
            }

            public static Int32 ToInt32(object value)
            {
                return ChangeType<Int32>(value);
            }

            public static Int64 ToInt64(object value)
            {
                return ChangeType<Int64>(value);
            }

            public static Single ToSingle(object value)
            {
                return ChangeType<Single>(value);
            }

            public static Boolean ToBoolean(object value)
            {
                return ChangeType<Boolean>(value);
            }

            public static System.String ToString(object value)
            {
                return ChangeType<System.String>(value);
            }

            public static DateTime ToDateTime(object value)
            {
                return ChangeType<DateTime>(value);
            }

            public static Decimal ToDecimal(object value)
            {
                return ChangeType<Decimal>(value);
            }

            public static Double ToDouble(object value)
            {
                return ChangeType<Double>(value);
            }

            public static Guid ToGuid(object value)
            {
                return ChangeType<Guid>(value);
            }

            public static Byte ToByte(object value)
            {
                return ChangeType<Byte>(value);
            }

            public static Byte[] ToBytes(object value)
            {
                return ChangeType<Byte[]>(value);
            }
            public static DateTime? ToDateTimeNull(object value)
            {
                return ChangeType<DateTime?>(value);
            }

            public static System.Int32? ToInt32Null(object value)
            {
                return ChangeType<Int32?>(value);
            }

            public static Boolean? ToBooleanNull(object value)
            {
                return ChangeType<Boolean?>(value);
            }

            /// <summary>
            /// Generic method to change type including nullable types.
            /// </summary>
            /// <typeparam name="T"></typeparam>
            /// <param name="value"></param>
            /// <returns></returns>
            private static T ChangeType<T>(object value)
            {
                var t = typeof(T);

                if (t.IsGenericType && t.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
                {
                    if (value == null)
                    {
                        return default(T);
                    }

                    t = Nullable.GetUnderlyingType(t); ;
                }

                return (T)Convert.ChangeType(value, t);
            }
        }
        #endregion

        #region Multi Reader class using SqlDataReader
        /// <summary>
        /// MultiReader class
        /// </summary>
        public class MultiGridReader : IDisposable
        {
            private SqlDataReader reader;
            private SqlCommand command;
            private int gridIndex;
            private bool consumed;

            internal MultiGridReader(SqlCommand command, SqlDataReader reader)
            {
                this.command = command;
                this.reader = reader;
            }

            public IEnumerable<T> Read<T>(bool isBuffered = false)
            {
                SqlDataHelper dataHelper = new SqlDataHelper();
                var entityMapper = new DeserializerState<T>(dataHelper.Mapper<T>(reader));
                try
                {
                    while (reader.Read())
                    {
                        yield return (T)entityMapper.MapEntity(reader);
                    }
                }
                finally
                {
                    NextResult();
                }
            }


            private void NextResult()
            {
                if (reader.NextResult())
                {
                    gridIndex++;
                }
                else
                {
                    reader.Dispose();
                    reader = null;
                    command.Dispose();
                    command = null;
                    Dispose();
                }

            }

            public void Dispose()
            {
                if (reader != null)
                {
                    if (!reader.IsClosed && command != null) command.Cancel();
                    reader.Dispose();
                    reader = null;
                }
                if (command != null)
                {
                    command.Dispose();
                    command = null;
                }
            }
        }
        #endregion
    }
}
